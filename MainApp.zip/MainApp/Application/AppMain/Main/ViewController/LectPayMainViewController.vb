﻿Imports App.Common.Data.Model

Public Class LectPayMainViewController

    ''' <summary>
    ''' 対象年月度ロックサービス
    ''' </summary>
    Private _service As New YearMonthLockService

    ''' <summary>
    ''' 対象年月の強制ロック解除をします。
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function UnLockedTargetYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel

        Try
            model.NowYearMonth = AppState.TargetYearMonth
            result = _service.UnLockedTargetYearMonth(model)

        Catch ex As AppException
            result.SubStatus = False
            result.Exception = ex
            result.BusinessMessage = MessageIdConst.MSGID_E2011

        End Try

        Return result
    End Function

End Class
