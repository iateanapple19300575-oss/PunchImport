﻿Imports App.Common.Data.Dto
Imports App.Common.Data.Model

Public Class TargetYearMonthViewController

    ''' <summary>
    ''' 対象年月度ロックサービス
    ''' </summary>
    Private _service As New YearMonthLockService

    ''' <summary>
    ''' 対象年月のロックをします。
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function LockYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel

        model.NowYearMonth = AppState.TargetYearMonth
        result = _service.LockYearMonth(model)

        If result.SubStatus = 1 Then
            Dim resultData As YearMonthLockDto = result.ResponseData
            result.Meassage = String.Concat(
                    "選択した対象年月は現在使用中です", vbCrLf,
                    "使用者  =[", resultData.LockUser, "]", vbCrLf,
                    "使用PC  =[", resultData.LockPc, "]", vbCrLf,
                    "使用開始=[", resultData.LockDatetime, "]")
        End If

        Return result
    End Function

End Class
