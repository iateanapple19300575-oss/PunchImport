﻿Public Class TargetYearMonthDomain

End Class
