﻿Namespace MainApp.Data.Dto

    ''' <summary>
    ''' DTO。
    ''' </summary>
    Public Class CsvImportParameterDto

        ''' <summary>
        ''' CSVファイルパス
        ''' </summary>
        Public Property FilePath As String

        ''' <summary>
        ''' CSVタイプ
        ''' </summary>
        Public Property CsvType As Integer

        ''' <summary>
        ''' データタイプ名
        ''' </summary>
        Public Property DataName As String

        ''' <summary>
        ''' 取込フェーズ
        ''' </summary>
        Public Property Phase As Integer

        ''' <summary>
        ''' データタイプ
        ''' </summary>
        Public Property DataType As Integer

        ''' <summary>
        ''' コースタイプ
        ''' </summary>
        Public Property CourseType As Integer

        ''' <summary>
        ''' 対象年月度
        ''' </summary>
        Public Property TargetDate As Date

        ''' <summary>
        ''' 対象期間(年月度)
        ''' </summary>
        Public Property PeriodDates As New List(Of String)

    End Class

End Namespace
