﻿Imports System.Linq.Expressions

''' <summary>
''' ログ出力を行うためのサービスクラス。
''' 直接ログを書き込むメソッドと、プリセットを利用したログ出力メソッドを提供する。
''' </summary>
Public NotInheritable Class LogService

    ''' <summary>
    ''' 指定された情報を元にログを書き込む。
    ''' イベント名・メッセージをテンプレートに埋め込み、必要に応じてエラーコードも付与する。
    ''' </summary>
    ''' <param name="scrnName">画面名</param>
    ''' <param name="cntrlName">ログコントロール名</param>
    ''' <param name="evntName">ログイベント名</param>
    ''' <param name="message">ログメッセージ本文</param>
    ''' <param name="level">ログレベル（既定値は Info）</param>
    ''' <param name="errorCode">エラーコード（任意）</param>
    ''' <param name="template">
    ''' ログメッセージのテンプレート。
    ''' {EventName}, {Message} を置換して最終メッセージを構築する。
    ''' </param>
    Public Shared Sub Write(ByVal scrnName As String,
                            ByVal cntrlName As String,
                            ByVal evntName As String,
                            ByVal message As String,
                            Optional ByVal level As LogLevels = LogLevels.Info,
                            Optional ByVal errorCode As String = Nothing,
                            Optional ByVal template As String = "{Message}")

        Dim finalMessage As String = String.Concat(message, IIf(String.IsNullOrEmpty(errorCode), "", "(" & errorCode & ")"))
        Dim screenName As String = scrnName

    ' 実際のログ書き込み処理
    'DbLogger.Insert(screenName, cntrlName, evntName, finalMessage, level.ToString(), errorCode)
    DbLogger.InsertAsync(screenName, cntrlName, evntName, finalMessage, level.ToString(), errorCode)
  End Sub

    ''' <summary>
    ''' 指定されたプリセット名に基づいてログを書き込む。
    ''' プリセットに定義されたログレベル・エラーコード・テンプレートを使用する。
    ''' </summary>
    ''' <param name="screenName">画面名</param>
    ''' <param name="presetName">使用するログプリセット名</param>
    ''' <param name="eventName">ログイベント名</param>
    ''' <param name="message">ログメッセージ本文</param>
    ''' <exception cref="Exception">プリセットが見つからない場合に発生</exception>
    Public Shared Sub WriteWithPreset(ByVal screenName As String,
                                      ByVal presetName As String,
                                      ByVal eventName As String,
                                      ByVal message As String)

        ' プリセットを取得
        Dim preset As LogAttribute = LogPresetRegistry.GetPreset(presetName)
        If preset Is Nothing Then
            Throw New Exception("プリセットが見つかりません: " & presetName)
        End If

        ' プリセットの設定を使ってログを書き込む
        Write(screenName, eventName, message, preset.Level, preset.ErrorCode, preset.Template)
    End Sub
End Class
