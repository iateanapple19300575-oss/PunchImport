﻿#If 0 Then

Public Class MNSPM10Service

    Private MNSPM10Tran As MNSPM10Tran = New MNSPM10Tran()


End Class

#End If
