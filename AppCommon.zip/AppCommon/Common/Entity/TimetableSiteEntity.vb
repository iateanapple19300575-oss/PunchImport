Namespace MainApp.Data.Entity

    ''' <summary>
    ''' Model�B
    ''' </summary>
    Public Class TimetableSiteEntity

        ''' <summary>
        ''' �Ώ۔N
        ''' </summary>
        Public Property TargetYear As String

        ''' <summary>
        ''' ����
        ''' </summary>
        Public Property Division_KND As String

        ''' <summary>
        ''' �����R�[�h
        ''' </summary>
        Public Property Site_Code As String

    End Class

End Namespace
