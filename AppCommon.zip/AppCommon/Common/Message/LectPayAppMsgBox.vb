﻿Imports System.Windows.Forms

Public Class LectPayAppMsgBox

    Public Shared Sub ShowMessage(ByVal ex As BaseException)
        MessageBox.Show(ex.DeveloperMessage)
    End Sub

    Public Shared Sub ShowMessage(ByVal msg As String)
        MessageBox.Show(msg)
    End Sub

End Class
