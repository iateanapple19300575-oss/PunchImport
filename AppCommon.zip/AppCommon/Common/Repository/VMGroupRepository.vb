﻿Imports System.Data.SqlClient

Public Class VMGroupRepository
    Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' SELECT(標準)
    ''' </summary>
    Public Function GetAll() As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  Corporate_KND").Append(" ")
        SqlQuery.Append("  , Division_KND").Append(" ")
        SqlQuery.Append("  , Division_Name ").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  VM_Group ").Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")
        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  Corporate_KND ASC").Append(" ")
        SqlQuery.Append("  , Division_KND ASC").Append(" ")
        SqlQuery.Append(";")

        Return ExecuteDataTable(SqlQuery.ToString(), Nothing)
    End Function

End Class
