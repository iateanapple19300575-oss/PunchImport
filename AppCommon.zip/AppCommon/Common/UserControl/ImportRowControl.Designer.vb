﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ImportRowControl
    Inherits System.Windows.Forms.UserControl

    'UserControl1 は、コンポーネント一覧に後処理を実行するために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.lblDataType = New System.Windows.Forms.Label()
		Me.txtFilePath = New System.Windows.Forms.TextBox()
		Me.lblLastTime = New System.Windows.Forms.Label()
		Me.lblLastCount = New System.Windows.Forms.Label()
		Me.lblCurrentTime = New System.Windows.Forms.Label()
		Me.lblCurrentCount = New System.Windows.Forms.Label()
		Me.lblCurrentResult = New System.Windows.Forms.Label()
		Me.LastTimeTitle = New System.Windows.Forms.Label()
		Me.ThisTimeTitle = New System.Windows.Forms.Label()
		Me.btnBrowse = New System.Windows.Forms.Button()
		Me.btnImport = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'lblDataType
		'
		Me.lblDataType.AutoSize = True
		Me.lblDataType.Location = New System.Drawing.Point(10, 15)
		Me.lblDataType.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.lblDataType.Name = "lblDataType"
		Me.lblDataType.Size = New System.Drawing.Size(174, 17)
		Me.lblDataType.TabIndex = 0
		Me.lblDataType.Text = "精算金支払い(非課税)データ"
		'
		'txtFilePath
		'
		Me.txtFilePath.Location = New System.Drawing.Point(220, 8)
		Me.txtFilePath.Name = "txtFilePath"
		Me.txtFilePath.ReadOnly = True
		Me.txtFilePath.Size = New System.Drawing.Size(440, 28)
		Me.txtFilePath.TabIndex = 1
		Me.txtFilePath.TabStop = False
		'
		'lblLastTime
		'
		Me.lblLastTime.AutoSize = True
		Me.lblLastTime.Location = New System.Drawing.Point(270, 45)
		Me.lblLastTime.Name = "lblLastTime"
		Me.lblLastTime.Size = New System.Drawing.Size(100, 17)
		Me.lblLastTime.TabIndex = 5
		Me.lblLastTime.Text = "----/--/-- --:--"
		'
		'lblLastCount
		'
		Me.lblLastCount.AutoSize = True
		Me.lblLastCount.Location = New System.Drawing.Point(400, 45)
		Me.lblLastCount.Name = "lblLastCount"
		Me.lblLastCount.Size = New System.Drawing.Size(54, 17)
		Me.lblLastCount.TabIndex = 6
		Me.lblLastCount.Text = "--,---件"
		'
		'lblCurrentTime
		'
		Me.lblCurrentTime.AutoSize = True
		Me.lblCurrentTime.Location = New System.Drawing.Point(270, 75)
		Me.lblCurrentTime.Name = "lblCurrentTime"
		Me.lblCurrentTime.Size = New System.Drawing.Size(100, 17)
		Me.lblCurrentTime.TabIndex = 8
		Me.lblCurrentTime.Text = "----/--/-- --:--"
		'
		'lblCurrentCount
		'
		Me.lblCurrentCount.AutoSize = True
		Me.lblCurrentCount.Location = New System.Drawing.Point(400, 75)
		Me.lblCurrentCount.Name = "lblCurrentCount"
		Me.lblCurrentCount.Size = New System.Drawing.Size(54, 17)
		Me.lblCurrentCount.TabIndex = 9
		Me.lblCurrentCount.Text = "--,---件"
		'
		'lblCurrentResult
		'
		Me.lblCurrentResult.AutoSize = True
		Me.lblCurrentResult.Location = New System.Drawing.Point(472, 75)
		Me.lblCurrentResult.Name = "lblCurrentResult"
		Me.lblCurrentResult.Size = New System.Drawing.Size(34, 17)
		Me.lblCurrentResult.TabIndex = 10
		Me.lblCurrentResult.Text = "状態"
		'
		'LastTimeTitle
		'
		Me.LastTimeTitle.AutoSize = True
		Me.LastTimeTitle.Location = New System.Drawing.Point(220, 45)
		Me.LastTimeTitle.Name = "LastTimeTitle"
		Me.LastTimeTitle.Size = New System.Drawing.Size(47, 17)
		Me.LastTimeTitle.TabIndex = 4
		Me.LastTimeTitle.Text = "前回："
		'
		'ThisTimeTitle
		'
		Me.ThisTimeTitle.AutoSize = True
		Me.ThisTimeTitle.Location = New System.Drawing.Point(220, 75)
		Me.ThisTimeTitle.Name = "ThisTimeTitle"
		Me.ThisTimeTitle.Size = New System.Drawing.Size(47, 17)
		Me.ThisTimeTitle.TabIndex = 7
		Me.ThisTimeTitle.Text = "今回："
		'
		'btnBrowse
		'
		Me.btnBrowse.Location = New System.Drawing.Point(670, 8)
		Me.btnBrowse.Name = "btnBrowse"
		Me.btnBrowse.Size = New System.Drawing.Size(60, 28)
		Me.btnBrowse.TabIndex = 2
		Me.btnBrowse.Text = "参照..."
		Me.btnBrowse.UseVisualStyleBackColor = True
		'
		'btnImport
		'
		Me.btnImport.Location = New System.Drawing.Point(740, 8)
		Me.btnImport.Name = "btnImport"
		Me.btnImport.Size = New System.Drawing.Size(70, 28)
		Me.btnImport.TabIndex = 3
		Me.btnImport.Text = "取込"
		Me.btnImport.UseVisualStyleBackColor = True
		'
		'ImportRowControl
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.Controls.Add(Me.btnImport)
		Me.Controls.Add(Me.btnBrowse)
		Me.Controls.Add(Me.ThisTimeTitle)
		Me.Controls.Add(Me.LastTimeTitle)
		Me.Controls.Add(Me.lblCurrentResult)
		Me.Controls.Add(Me.lblCurrentCount)
		Me.Controls.Add(Me.lblCurrentTime)
		Me.Controls.Add(Me.lblLastCount)
		Me.Controls.Add(Me.lblLastTime)
		Me.Controls.Add(Me.txtFilePath)
		Me.Controls.Add(Me.lblDataType)
		Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "ImportRowControl"
		Me.Size = New System.Drawing.Size(820, 100)
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents lblDataType As Label
	Friend WithEvents txtFilePath As TextBox
	Friend WithEvents lblLastTime As Label
	Friend WithEvents lblLastCount As Label
	Friend WithEvents lblCurrentTime As Label
	Friend WithEvents lblCurrentCount As Label
	Friend WithEvents lblCurrentResult As Label
	Friend WithEvents LastTimeTitle As Label
	Friend WithEvents ThisTimeTitle As Label
	Friend WithEvents btnBrowse As Button
	Friend WithEvents btnImport As Button
End Class
