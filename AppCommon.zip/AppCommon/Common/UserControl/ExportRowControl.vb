﻿''' <summary>
''' エクスポート用ユーザコントロール
''' </summary>
Public Class ExportRowControl

  Public Event BrowseClicked(ByVal sender As Object, ByVal filePath As String)
  Public Event ExportRequested(ByVal sender As Object, ByVal filePath As String)
  Public Event DisplayRequested(ByVal sender As Object)

  ' 初期表示ファイル名
  Public Property InitFileName As String

  ' コントロール配置番号
  Public ReadOnly Property Id As Integer = 0

  ''' <summary>
  ''' データ種別
  ''' </summary>
  ''' <returns></returns>
  Public Property DataTypeLabel As String
    Get
      Return lblDataType.Text
    End Get
    Set(ByVal value As String)
      lblDataType.Text = value
    End Set
  End Property

  ''' <summary>
  ''' ファイルパス
  ''' </summary>
  ''' <returns></returns>
  Public Property FilePath As String
    Get
      Return txtFilePath.Text
    End Get
    Set(value As String)
      txtFilePath.Text = value
    End Set
  End Property


  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New(ByVal id As Integer, ByVal visible As Boolean)
    InitializeComponent()
    txtFilePath.ReadOnly = True
    btnDisplay.Visible = visible
    Me.Id = id
  End Sub

  ''' <summary>
  ''' [参照]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub BtnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
    RaiseEvent BrowseClicked(Me, "")
  End Sub

  ''' <summary>
  ''' [出力]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub BtnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click
    If txtFilePath.Text <> "" Then
      RaiseEvent ExportRequested(Me, txtFilePath.Text)
    End If
  End Sub

  ''' <summary>
  ''' [確認]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub BtnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
    RaiseEvent DisplayRequested(Me)
  End Sub
End Class
