﻿Imports System.Windows.Forms

Public Class ComboBoxHelper

	Public Shared Sub SetDataSource(ByRef combobox As ComboBox, ByVal dtTable As DataTable, ByVal name As String, ByVal id As String)
		Dim newRow As DataRow = dtTable.NewRow()
		newRow(name) = "(未選択)"
		newRow(id) = DBNull.Value
		dtTable.Rows.InsertAt(newRow, 0)

		With combobox
			.DataSource = dtTable
			.DisplayMember = name
			.ValueMember = id

			If .Items.Count > 0 Then
				.SelectedIndex = 0
			End If
		End With
	End Sub

End Class
