﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO

''' <summary>
''' CSV読み込み抽象クラス
''' </summary>
Public MustInherit Class CSVReaderAbstract

    Protected MustOverride Sub GetLineField(ByVal fields() As String)

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Function Reader(ByVal csvFileName As String) As Boolean

        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    GetLineField(fields)
                End While

            End Using

        Catch ex As Exception
            Throw

        Finally

        End Try

        Return CsvDataCounter
    End Function


End Class
