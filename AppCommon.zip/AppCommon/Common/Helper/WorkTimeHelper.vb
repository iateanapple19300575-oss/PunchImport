﻿Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class WorkTimeHelper

    ''' <summary>
    ''' 出講教室コードと交通費マスタの登録金額を取得する。
    ''' 勤怠関連チェック内で交通費マスト未登録チェックのために使用する。
    ''' </summary>
    ''' <param name="row">DataRow</param>
    ''' <param name="roomStart">教室コードの開始番地</param>
    ''' <param name="amountStart">交通費金額の開始番地</param>
    ''' <returns></returns>
    Private Function GetTranspoCostInfo(ByVal row As DataRow, ByVal roomStart As Integer, ByVal amountStart As Integer) As List(Of KeyValuePair(Of String, String))
        Dim cost As New List(Of KeyValuePair(Of String, String))()
        Dim room As String = ""
        Dim amount As String = ""
        Dim idx As Integer = 1

        For i As Integer = 0 To 6 - 1
            Dim koma As Integer = i + 1
            room = IIf(Not IsDBNull(row(roomStart + (i * 2))), row(roomStart + (i * 2)), "")
            amount = IIf(Not IsDBNull(row(amountStart + (i * 2))), row(amountStart + (i * 2)), "")
            If StringUtil.IsNullOrWhiteSpace(room) Then
                Exit For
            End If
            cost.Add(New KeyValuePair(Of String, String)(room, amount))
        Next

        Return cost
    End Function

    ''' <summary>
    ''' 打刻チェックのためのパラメタ情報収集 
    ''' </summary>
    ''' <param name="row"></param>
    ''' <returns></returns>
    Private Function RowToDto(ByVal row As DataRow, ByVal roomStart As Integer, ByVal amountStart As Integer) As PunchingTimeDto
        Return New PunchingTimeDto With {
            .JobStart = IIf(Not IsDBNull(row("出勤(打刻)")), row("出勤(打刻)"), ""),
            .JobEnd = IIf(Not IsDBNull(row("退勤(打刻)")), row("退勤(打刻)"), ""),
            .PunchCount = IIf(Not IsDBNull(row("打刻回数")), row("打刻回数"), ""),
            .ActStart = IIf(Not IsDBNull(row("開始(予定)")), row("開始(予定)"), ""),
            .ActEnd = IIf(Not IsDBNull(row("終了(予定)")), row("終了(予定)"), ""),
            .ReqStart = IIf(Not IsDBNull(row("開始(業務)")), row("開始(業務)"), ""),
            .ReqEnd = IIf(Not IsDBNull(row("終了(業務)")), row("終了(業務)"), ""),
            .WorkStart = IIf(Not IsDBNull(row("出勤(みなし)")), row("出勤(みなし)"), ""),
            .WorkEnd = IIf(Not IsDBNull(row("退勤(みなし)")), row("退勤(みなし)"), ""),
            .WorkTime = IIf(Not IsDBNull(row("業務時間(みなし)")), row("業務時間(みなし)"), 0),
            .Duplicates = IIf(Not IsDBNull(row("時間重複")), row("時間重複"), 0),
            .Costs = GetTranspoCostInfo(row, roomStart, amountStart)
        }
    End Function

    ''' <summary>
    ''' 勤怠ステータス取得（こっちが最新:SQLでみなし取得版）
    ''' </summary>
    ''' <param name="times"></param>
    ''' <returns></returns>
    Public Shared Function GetWorkTimeAllStatus(ByVal times As PunchingTimeDto) As List(Of KeyValuePair(Of String, String))
        Dim errorsInfo As New List(Of KeyValuePair(Of String, String))

        Dim jobStart, actStart, reqStart, jobEnd, actEnd, reqEnd, workStart, workEnd As DateTime
        Dim punchCount As Integer = times.PunchCount
        Dim hasJobStart = DateTime.TryParse(times.JobStart, jobStart)
        Dim hasActStart = DateTime.TryParse(times.ActStart, actStart)
        Dim hasReqStart = DateTime.TryParse(times.ReqStart, reqStart)
        Dim hasJobEnd = DateTime.TryParse(times.JobEnd, jobEnd)
        Dim hasActEnd = DateTime.TryParse(times.ActEnd, actEnd)
        Dim hasReqEnd = DateTime.TryParse(times.ReqEnd, reqEnd)
        Dim lateNight = jobEnd.Date.AddHours(22)

        Dim hasWorkStart = DateTime.TryParse(times.WorkStart, workStart)
        Dim hasWorkEnd = DateTime.TryParse(times.WorkEnd, workEnd)

        ' 授業と業務なし
        If Not hasActStart AndAlso Not hasReqStart Then
            If hasJobStart Or hasJobEnd Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講・業務届なし"))
            End If
        End If

        ' 打刻なし
        If (Not hasJobStart AndAlso Not hasJobEnd) OrElse punchCount = 0 Then
            ' 出退勤打刻なし
            errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "打刻なし(出勤・退勤)"))

        ElseIf Not hasJobStart Then
            ' 出勤打刻なし
            errorsInfo.Add(New KeyValuePair(Of String, String)("エラー", "打刻なし(出勤)"))

        ElseIf Not hasJobEnd Then
            ' 退勤打刻なし
            errorsInfo.Add(New KeyValuePair(Of String, String)("エラー", "打刻なし(退勤)"))
        End If

        ' 打刻回数3回以上
        If punchCount >= 3 Then
            errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "打刻回数3回以上"))
        End If

        ' 深夜勤務
        If jobEnd.ToShortTimeString() > lateNight.ToShortTimeString() Then
            errorsInfo.Add(New KeyValuePair(Of String, String)("情報", String.Format("深夜勤務発生({0}分)", (jobEnd - lateNight).TotalMinutes())))
        End If

        ' 交通費未登録あり
        For Each kv In times.Costs
            If Not String.IsNullOrEmpty(kv.Key) AndAlso String.IsNullOrEmpty(kv.Value) Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("情報", String.Format("交通費未登録区間あり({0})", kv.Key)))
            End If
        Next

        ' 期間重複有無
        If times.Duplicates > 0 Then
            errorsInfo.Add(New KeyValuePair(Of String, String)("エラー", "時間重複(授業時間・業務届)"))
        End If

        ' 授業開始あり 且つ 業務開始あり
        Dim startTime As DateTime
        If hasActStart AndAlso hasReqStart Then
            If actStart < reqStart Then
                'startTime = actStart.AddMinutes(deemedMinutes * (-1))
                startTime = workStart
                If jobStart < startTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
                ElseIf jobStart > actStart Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"))
                End If
            ElseIf actStart > reqStart Then
                'startTime = reqStart.AddMinutes(deemedMinutes * (-1))
                startTime = workStart
                If jobStart < startTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
                ElseIf jobStart > reqStart Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届遅刻(" & DifferentialTime(jobStart, reqStart).ToString() & "分)"))
                End If
            Else
            End If
            'Return Nothing
        End If

        ' 授業のみ 
        If hasActStart AndAlso Not hasReqStart Then
            'startTime = actStart.AddMinutes(deemedMinutes * (-1))
            startTime = workStart
            If jobStart < startTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
            ElseIf jobStart > actStart Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"))
            End If
        End If

        ' 業務届のみ 
        If Not hasActStart AndAlso hasReqStart Then
            'startTime = reqStart.AddMinutes(deemedMinutes * (-1))
            startTime = workStart
            If jobStart < startTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
            ElseIf jobStart > actStart Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"))
            End If
        End If


        ' 授業終了あり 且つ 業務終了あり
        Dim endTime As DateTime
        If hasActEnd AndAlso hasReqEnd Then
            If actEnd > reqEnd Then
                'endTime = actEnd.AddMinutes(deemedMinutes)
                endTime = workEnd
                If jobEnd > endTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
                ElseIf jobEnd < actEnd Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"))
                End If
            ElseIf actEnd < reqEnd Then
                'endTime = reqEnd.AddMinutes(deemedMinutes)
                endTime = workEnd
                If jobEnd > endTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
                ElseIf jobEnd < reqEnd Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届早退(" & DifferentialTime(jobEnd, reqEnd).ToString() & "分)"))
                End If
            Else
            End If
            'Return Nothing
        End If

        ' 授業のみ 
        If hasActEnd AndAlso Not hasReqEnd Then
            'endTime = actEnd.AddMinutes(deemedMinutes)
            endTime = workEnd
            If jobEnd > endTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
            ElseIf jobEnd < actEnd Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"))
            End If
        End If

        ' 業務届のみ 
        If Not hasActEnd AndAlso hasReqEnd Then
            'endTime = reqEnd.AddMinutes(deemedMinutes)
            endTime = workEnd
            If jobEnd > endTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
            ElseIf jobEnd < actEnd Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"))
            End If
        End If

        Return errorsInfo
    End Function

    ''' <summary>
    ''' 差分時間取得
    ''' </summary>
    ''' <param name="time1"></param>
    ''' <param name="time2"></param>
    ''' <returns></returns>
    Private Shared Function DifferentialTime(ByVal time1 As DateTime, ByVal time2 As DateTime) As Decimal
        If time1 > time2 Then
            Return (time1 - time2).Hours * 60 + (time1 - time2).Minutes
        Else
            Return (time2 - time1).Hours * 60 + (time2 - time1).Minutes
        End If
    End Function

    ''' <summary>
    ''' 授業給係数メッセージ生成
    ''' </summary>
    ''' <param name="errorsInfo"></param>
    ''' <param name="row"></param>
    Public Shared Sub CoefficientMessage(ByRef errorsInfo As List(Of KeyValuePair(Of String, String)), ByVal row As DataRow)

        Dim coefficient = IIf(Not IsDBNull(row("Lecture_Coefficient")), row("Lecture_Coefficient"), "")
        If Not String.IsNullOrEmpty(coefficient) Then
            Dim siteCode As String = IIf(Not IsDBNull(row("Site_Code")), row("Site_Code"), "")
            Dim grade As String = IIf(Not IsDBNull(row("Grade")), row("Grade"), "")
            Dim classCode As String = IIf(Not IsDBNull(row("Class_Code")), row("Class_Code"), "")
            Dim msg As String = String.Format("授業給係数発生({0}倍) {1} {2}年 {3}クラス", coefficient, siteCode, grade, Trim(classCode))
            errorsInfo.Add(New KeyValuePair(Of String, String)("情報", msg))
        End If

    End Sub









End Class
