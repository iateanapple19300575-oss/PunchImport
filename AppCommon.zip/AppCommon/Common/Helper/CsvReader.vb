﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO

''' <summary>
''' CSV読み込みクラス
''' </summary>
Public Class CsvReader
    Implements ICsvReader

    ''' <summary>
    ''' CSVファイル情報
    ''' </summary>
    ''' <returns></returns>
    Private Property CsvFileInfo As CsvAbstract


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="csvFileInfo"></param>
    Public Sub New(ByVal csvFileInfo As CsvAbstract)
        Me.CsvFileInfo = csvFileInfo
    End Sub

    ''' <summary>
    ''' CSVファイ名を返す。
    ''' </summary>
    ''' <returns></returns>
    Public Function FileName() As String Implements ICsvReader.FileName
        Return CsvFileInfo.FileName
    End Function

    ''' <summary>
    ''' CSVデータの項目数が正しいか確認する。
    ''' </summary>
    ''' <param name="filePath"></param>
    ''' <returns></returns>
    Public Function FormatValidation(ByVal filePath As String) As Boolean Implements ICsvReader.FormatValidation
        Try
            Using parser As New TextFieldParser(filePath, Encoding.GetEncoding("Shift_JIS"))
                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                Dim columns As String() = CsvFileInfo.Headers.ToArray()
                If Not parser.EndOfData Then
                    Dim fields As String() = parser.ReadFields()

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        Return False
                    End If

                    ' カラム名チェック
                    Dim headers() As String = CsvFileInfo.Headers().ToArray()
                    For i As Integer = 0 To fields.Length - 1
                        If Array.IndexOf(headers, fields(i)) < 0 Then
                            Return False
                        End If
                    Next
                End If
            End Using

        Catch ex As Exception

        End Try

        Return True
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="filePath"></param>
    ''' <returns></returns>

    Public Function Read(ByVal filePath As String) As List(Of Dictionary(Of String, String)) Implements ICsvReader.Read
        Return Reader(filePath)
    End Function

    Public Function Reader(ByVal csvFileName As String) As List(Of Dictionary(Of String, String))
        'Dim result As New CsvReaderResultData
        Dim csvDataDic As New List(Of Dictionary(Of String, String))
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                Dim columns As String() = CsvFileInfo.Headers.ToArray()

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    '' CSV項目数チェック
                    'If fields.Length <> columns.Count Then
                    '  result.FormarError = True
                    '  result.Success = False
                    '  Exit While
                    'End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    Dim row As New Dictionary(Of String, String)
                    For i As Integer = 0 To columns.Length - 1
                        row.Add(columns(i), fields(i))
                    Next
                    csvDataDic.Add(row)
                End While

            End Using

        Catch ex As Exception
            Throw

        Finally

        End Try

        Return csvDataDic
    End Function

    ''' <summary>
    ''' 内包するCSVインスタンスを返す。
    ''' </summary>
    ''' <returns></returns>
    Private Function GetCsvInstance() As ICsv Implements ICsvReader.GetCsvInstance
        Return CsvFileInfo
    End Function

    ''' <summary>
    ''' CSVファイルの内容をDataTableに詰めて返す。
    ''' </summary>
    ''' <param name="fileName"></param>
    ''' <param name="yearMonth"></param>
    ''' <returns></returns>
    Public Function ToDataTable(fileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable Implements ICsvReader.ToDataTable
        Return CsvFileInfo.Reader(fileName, yearMonth)
    End Function
End Class
