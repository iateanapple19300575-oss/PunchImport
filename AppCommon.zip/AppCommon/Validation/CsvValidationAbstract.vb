﻿Public MustInherit Class CsvValidationAbstract
    Implements ICsvValidation

    Private CSV_FIELD_COUNT_ERROR_MESSAGE As String = "CSVファイルのフォーマットエラーのため、処理を中止します。"


    Private Property ImportCsv As CsvAbstract

    ' CSVファイル名
    Protected Property CsvFileName As String

    ' ヘッダ名リスト
    Public Property ColumnNames As New List(Of String)

    Public Property HasError As Boolean = False

    ' エラーデータ
    Public Property ErrorDataTable As New DataTable

    ' バリデーションファクトリー
    Protected Property ValidatorFactory As ICsvValidationFactory

    'Private Property Validator As CsvValidationAbstract

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvInfo As CsvAbstract)
        Me.ImportCsv = csvInfo
        'Me.Validator = Validator
    End Sub

    '''' <summary>
    '''' コンストラクタ
    '''' </summary>
    '''' <param name="fileName">CSVファイル名</param>
    '''' <param name="csvInfo">CSV情報</param>
    'Public Sub New(ByVal fileName As String, ByVal csvInfo As CsvAbstract)
    '  Me.CsvFileName = fileName
    '  Me.ImportCsv = csvInfo
    'End Sub

    '''' <summary>
    '''' コンストラクタ
    '''' </summary>
    '''' <param name="csvInfo"></param>
    '''' <param name="rows"></param>
    'Public Sub New(ByVal csvInfo As CsvAbstract, ByVal rows As List(Of Dictionary(Of String, String)))
    '  Me.ImportCsv = csvInfo
    '  Me.ImportRows = rows
    'End Sub


    '''' <summary>
    '''' コンストラクタ
    '''' </summary>
    '''' <param name="fileName">CSVファイル名</param>
    '''' <param name="columns">ヘッダ名リスト</param>
    'Public Sub New(ByVal fileName As String, ByVal columns As List(Of String))
    '  Me.CsvFileName = fileName
    '  Me.ColumnNames = columns
    'End Sub


    ''' <summary>
    ''' CSVファイルのバリデーション
    ''' </summary>
    ''' <returns></returns>
    Public Function Validate(ByVal importRows As List(Of Dictionary(Of String, String))) As ImportResultInfo Implements ICsvValidation.Validate
        Dim result As New ImportResultInfo()

        ' バリデーションエラー情報
        Dim validationFileResult As New Dictionary(Of Integer, List(Of ValidationResult))

        Dim CsvDataCounter As Integer = 0

        ' ファイルの終端までループする
        For Each fields As Dictionary(Of String, String) In importRows
            ' カラム別の１行データ取得
            'Dim field As String() = parser.ReadFields()
            CsvDataCounter += 1

            ' CSV項目数チェック
            If fields.Count <> ImportCsv.ColumnsCount Then
                result.FormarError = True
                'result.Message = MessageIdConst.MSGID_E2002
                result.Success = False
                Exit For
            End If

            '' CSVヘッダスキップ
            'If (CsvDataCounter = 1) Then
            '  Continue For
            'End If

            ' バリデーション（１行全カラム）
            Dim isRowSuccess = True
            Dim rowResults As New List(Of ValidationResult)
            For i As Integer = 0 To ImportCsv.ColumnsCount - 1
                ' カラム別バリデーションの取得
                Dim resultValidate As New ValidationResult With {.Value = fields.Values(i)}
                Dim validator = Me.ValidatorFactory.CreateValidator(ImportCsv.Headers(i))

                ' チェック不要項目はスキップ
                If (validator Is Nothing) Then
                    rowResults.Add(resultValidate)
                    Continue For
                End If

                ' 対象カラムのバリデート
                resultValidate = validator.Validate(fields.Values(i))
                rowResults.Add(resultValidate)

                ' エラーの場合
                If (Not resultValidate.IsValid) Then
                    isRowSuccess = False
                    result.Success = False
                    HasError = True
                    result.ErrorCount += 1
                End If
            Next

            ' エラーカラムあり
            If (Not isRowSuccess) Then
                ' バリデーション結果１行分を格納
                validationFileResult.Add(CsvDataCounter - 1, rowResults)
            End If

        Next

        result.ValidationResultList = validationFileResult

        Return result
    End Function

    Public MustOverride Function CreateValidator(ByVal columnName As String) As IValidation
End Class
