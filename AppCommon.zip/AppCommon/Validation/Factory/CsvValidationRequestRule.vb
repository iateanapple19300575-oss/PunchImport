﻿Public Class CsvValidationRequestRule
    Implements ICsvValidationFactory

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
        Select Case columnName
            Case "教室"
                Return New RoomValidator(columnName, True)
            Case "科目"
                Return New SubjectsValidator(columnName, True)
            Case "講師名"
                Return Nothing
            Case "日付"
                Return New DateValidator(columnName, True)
            Case "業務名"
                Return Nothing
            Case "開始"
                Return New TimeValidator(columnName, True)
            Case "終了"
                Return New TimeValidator(columnName, True)
            Case "対象"
                Return Nothing
            Case "内容"
                Return Nothing
            Case "コード"
                Return New TeacherCodeValidator(columnName, True)
            Case "区分"
                Return New IntegerValidator(columnName, False)
            Case "実時間"
                Return New IntegerValidator(columnName, False)
            Case "＠"
                Return New AmountValidator(columnName, True)
            Case "乗数"
                Return New IntegerValidator(columnName, False)
            Case "みなし回数"
                Return New RealNumberValidator(columnName, False)
            Case "金額"
                Return New AmountValidator(columnName, True)
            Case "担当者"
                Return Nothing
            Case "リーダー"
                Return Nothing
            Case "教務室"
                Return Nothing
            Case Else
                Return Nothing
        End Select
    End Function

End Class
