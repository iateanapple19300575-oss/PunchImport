﻿Imports System.Drawing

''' <summary>
''' 日付バリデータ
''' </summary>
Public Class DateValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 日付データ長
    ''' </summary>
    Private Const DATE_LENGTH As Integer = 10
    'Private Const YEAR_LENGTH As Integer = 4
    'Private Const MONTH_LENGTH As Integer = 2
    'Private Const DAY_LENGTH As Integer = 2

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format(" yyyy/MM/dd 形式の半角文字({0}桁)で入力してください", DATE_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, DATE_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", DATE_LENGTH))
        End If

        ' 区切り文字
        Dim dateDelimiter As String = value.Substring(4, 1) & value.Substring(7, 1)
        If dateDelimiter <> "//" Then
            Return NewInvalidResult(value, "日付フォーマットが不正です")
        End If

        ' 年(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(0, 4)) Then
            Return NewInvalidResult(value, "年に半角数字以外の値があります")
        End If

        ' 月(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(5, 2)) Then
            Return NewInvalidResult(value, "月に半角数字以外の値があります")
        End If

        ' 日(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(8, 2)) Then
            Return NewInvalidResult(value, "日に半角数字以外の値があります")
        End If

        ' 日付チェック
        If Not ValidateChecker.IsValidDate(value) Then
            Return NewInvalidResult(value, "存在しない日付です")
        End If

        Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
