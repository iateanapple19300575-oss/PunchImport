﻿Imports System.Drawing

''' <summary>
''' 科目コードバリデータ
''' </summary>
Public Class SubjectsValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 科目コード長
    ''' </summary>
    Private Const CODE_LENGTH As Integer = 1

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = "１桁の半角英字(K, M, S, R, G)で入力してください"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, CODE_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", CODE_LENGTH))
        End If

        ' 字種(半角大文字英字)
        If Not ValidateChecker.IsHalfWidthAlphabetUpperOnly(value) Then
            Return NewInvalidResult(value, "半角英字(大文字)以外の値があります")
        End If

        ' 妥当性チェック(許容範囲の値)
        Dim referenceValues() As String = {"K", "M", "S", "R", "G"}
        If Not ValidateChecker.IsToleranceValue(value, referenceValues) Then
            Return NewInvalidResult(value, "範囲外の値です")
        End If

        Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
