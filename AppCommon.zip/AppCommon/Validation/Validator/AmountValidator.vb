﻿Imports System.Drawing

''' <summary>
''' 金額バリデータ
''' </summary>
Public Class AmountValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = "半角数字で入力してください"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        '' 桁チェック
        'If Not ValidateChecker.IsRangeCharacters(value, 7) Then
        '    Return New ValidationResult With {
        '        .IsValid = False,
        '        .SummaryMessage = GetMessage(),
        '        .ErrorMessage = String.Concat(DETAIL_PREFIX, String.Format("半角{0}桁以外です", 7), DETAIL_SUFFIX),
        '        .ErrorColor = Color.Red
        '    }
        'End If

        ' 数字
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, "半角数字以外の値があります")
        End If

        Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
