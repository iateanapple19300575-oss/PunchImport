﻿Imports System.Drawing

''' <summary>
''' 時間バリデータ
''' </summary>
Public Class TimeValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 時間長
    ''' </summary>
    Private Const TIME_LENGTH As Integer = 5
    Private Const HOUR_LENGTH As Integer = 2
    Private Const MINUTE_LENGTH As Integer = 2

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = " HH:mm 形式（00:00～23:59）の半角文字で入力してください"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, TIME_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", TIME_LENGTH))
        End If

        ' 区切り文字
        Dim timeDelimiter As String = value.Substring(2, 1)
        If timeDelimiter <> ":" Then
            Return NewInvalidResult(value, "時間フォーマットが不正です")
        End If

        ' 時(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(0, 2)) Then
            Return NewInvalidResult(value, "時に半角数字以外の値があります")
        End If

        ' 分(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(3, 2)) Then
            Return NewInvalidResult(value, "分に半角数字以外の値があります")
        End If

        ' 時間チェック
        If Not ValidateChecker.IsValidTime(value) Then
            Return NewInvalidResult(value, "存在しない時間です")
        End If

        Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function
End Class
