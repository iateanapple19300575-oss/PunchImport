﻿Imports System.Drawing

''' <summary>
''' 時間バリデータ
''' </summary>
Public Class TimeZeroSuppressValidator
	Inherits ValidatorAbstract

	''' <summary>
	''' 時間長
	''' </summary>
	Private Const TIME_LENGTH As Integer = 5
	Private Const HOUR_LENGTH As Integer = 2
	Private Const MINUTE_LENGTH As Integer = 2

	Private Const MIN_LENGTH As Integer = 4
	Private Const MAX_LENGTH As Integer = 5
	Private Const HOUR_MIN_LENGTH As Integer = 1
	Private Const HOUR_MAX_LENGTH As Integer = 2

	''' <summary>
	''' 概要メッセージ
	''' </summary>
	''' <returns></returns>
	Protected Overrides Property SummaryMessage As String = " H:mm 形式（0:00～23:59）の半角文字で入力してください"


	''' <summary>
	''' コンストラクタ
	''' </summary>
	''' <param name="columnName"></param>
	''' <param name="isRequired"></param>
	Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
		MyBase.New(columnName, isRequired)
	End Sub

	''' <summary>
	''' 検証
	''' </summary>
	''' <param name="value"></param>
	''' <returns></returns>
	Public Overrides Function Validate(ByVal value As String) As ValidationResult

		' 必須
		If ValidateChecker.IsNullOrWhiteSpace(value) Then
			If (MyBase.IsRequired) Then
				Return NewInvalidResult(value, "値なし[必須項目]")
			Else
				Return New ValidationResult With {.IsValid = True, .Value = value}
			End If
		End If

		' 半角
		If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
			Return NewInvalidResult(value, "全角文字の値があります")
		End If

		'' 桁数
		'If Not ValidateChecker.IsVariableByteLengthRange(value, MIN_LENGTH, MAX_LENGTH) Then
		'	Return NewInvalidResult(value, String.Format("半角{0}桁以外です", TIME_LENGTH))
		'End If

		' 区切り文字
		Dim splitTime() As String = value.Split(":")
		If splitTime.Length <> 2 Then
			Return NewInvalidResult(value, "時間フォーマットが不正です")
		End If

		' 時桁数
		If Not ValidateChecker.IsVariableByteLengthRange(splitTime(0), HOUR_MIN_LENGTH, HOUR_MAX_LENGTH) Then
			Return NewInvalidResult(value, String.Format("時は、半角{0}桁～{1}桁にしてください", HOUR_MIN_LENGTH, HOUR_MAX_LENGTH))
		End If

		' 分桁数
		If Not ValidateChecker.IsFixedByteLengthRange(splitTime(1), MINUTE_LENGTH) Then
			Return NewInvalidResult(value, String.Format("分は、半角{0}桁にしてください", MINUTE_LENGTH))
		End If


		' 時(数字)
		If Not ValidateChecker.IsHalfWidthNumberOnly(splitTime(0)) Then
			Return NewInvalidResult(value, "時に半角数字以外の値があります")
		End If

		' 分(数字)
		If Not ValidateChecker.IsHalfWidthNumberOnly(splitTime(1)) Then
			Return NewInvalidResult(value, "分に半角数字以外の値があります")
		End If

		' 時間チェック
		If Not ValidateChecker.IsValidTime(value) Then
			Return NewInvalidResult(value, "存在しない時間です")
		End If

		Return New ValidationResult With {.IsValid = True, .Value = value}
	End Function
End Class
