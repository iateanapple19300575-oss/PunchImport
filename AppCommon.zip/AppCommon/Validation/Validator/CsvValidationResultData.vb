﻿Imports System.Drawing

''' <summary>
''' バリデーション結果クラス
''' </summary>
Public Class CsvImportResultDto

  ''' <summary>
  ''' 処理日
  ''' </summary>
  ''' <returns></returns>
  Public Property ExecutionDate As Date = Nothing

  ''' <summary>
  ''' 処理日
  ''' </summary>
  ''' <returns></returns>
  Public Property ExecutionCount As Integer = 0

  ''' <summary>
  ''' データタイプ
  ''' </summary>
  ''' <returns></returns>
  Public Property DataType As Integer = 0

  ''' <summary>
  ''' 処理結果
  ''' </summary>
  ''' <returns></returns>
  Public Property Success As Boolean = True

  ''' <summary>
  ''' エラー発生有無（True：発生／False：未発生）
  ''' </summary>
  ''' <returns></returns>
  Public ReadOnly Property HasError As Boolean
    Get
      Return Success = False
    End Get
  End Property

  ''' <summary>
  ''' データフォーマットエラー
  ''' </summary>
  ''' <returns></returns>
  Public Property FormarError As Boolean = False

  ''' <summary>
  ''' エラーメッセージ
  ''' </summary>
  Public Property Message As String = ""

  ''' <summary>
  ''' エラー件数
  ''' </summary>
  ''' <returns></returns>
  Public ReadOnly Property ErrorCount As Integer
    Get
      Return ValidationResultList.Count
    End Get
  End Property

  ''' <summary>
  ''' CSVバリデーションエラー情報
  ''' </summary>
  ''' <returns></returns>
  Public Property ValidationResultList As New Dictionary(Of Integer, List(Of ValidationResult))

End Class
