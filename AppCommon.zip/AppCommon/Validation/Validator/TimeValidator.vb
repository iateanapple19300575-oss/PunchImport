﻿Imports System.Drawing
Imports System.Text.RegularExpressions

''' <summary>
''' 時間バリデータ
''' </summary>
Public Class ShortTimeValidator
  Inherits ValidatorAbstract

  ''' <summary>
  ''' 時間長
  ''' </summary>
  Private Const TIME_MIN_LENGTH As Integer = 4
  Private Const TIME_MAX_LENGTH As Integer = 5
  Private Const HOUR_LENGTH As Integer = 2
  Private Const MINUTE_LENGTH As Integer = 2

  ''' <summary>
  ''' 概要メッセージ
  ''' </summary>
  ''' <returns></returns>
  Protected Overrides Property SummaryMessage As String = " HH:mm 形式（00:00～23:59）の半角文字で入力してください"


  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="columnName"></param>
  ''' <param name="isRequired"></param>
  Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
    MyBase.New(columnName, isRequired)
  End Sub

  ''' <summary>
  ''' 検証
  ''' </summary>
  ''' <param name="value"></param>
  ''' <returns></returns>
  Public Overrides Function Validate(ByVal value As String) As ValidationResult

    ' 必須
    If ValidateChecker.IsNullOrWhiteSpace(value) Then
      If (MyBase.IsRequired) Then
        Return NewInvalidResult(value, "値なし[必須項目]")
      Else
        Return New ValidationResult With {.IsValid = True, .Value = value}
      End If
    End If

    ' 半角
    If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
      Return NewInvalidResult(value, "全角文字の値があります")
    End If

    ' 桁数
    If Not ValidateChecker.IsVariableByteLengthRange(value, TIME_MIN_LENGTH, TIME_MAX_LENGTH) Then
      Return NewInvalidResult(value, String.Format("半角{0}桁又は{1}以外です", TIME_MIN_LENGTH, TIME_MAX_LENGTH))
    End If

    ' 区切り文字
    ' 正規表現パターン:
    ' ^         → 文字列の先頭
    ' ([0-9]|[0-1][0-9]|2[0-3]) → 時 (0〜9, 00〜19, 20〜23)
    ' :         → コロン
    ' [0-5][0-9] → 分 (00〜59)
    ' $         → 文字列の末尾
    Dim pattern As String = "^([0-9]|[0-1][0-9]|2[0-3]):[0-5][0-9]$"
    If Not Regex.IsMatch(value, pattern) Then
      Return NewInvalidResult(value, "時間フォーマットが不正です")
    End If

    Dim times() As String = value.Split(":")

    ' 時(数字)
    If Not ValidateChecker.IsHalfWidthNumberOnly(times(0)) Then
      Return NewInvalidResult(value, "時に半角数字以外の値があります")
    End If

    ' 分(数字)
    If Not ValidateChecker.IsHalfWidthNumberOnly(times(1)) Then
      Return NewInvalidResult(value, "分に半角数字以外の値があります")
    End If

    ' 時間チェック
    If Not ValidateChecker.IsValidTime(value) Then
      Return NewInvalidResult(value, "存在しない時間です")
    End If

    Return New ValidationResult With {.IsValid = True, .Value = value}
  End Function
End Class
