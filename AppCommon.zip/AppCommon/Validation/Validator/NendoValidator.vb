﻿Imports System.Drawing

''' <summary>
''' 年度バリデータ
''' </summary>
Public Class NendoValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 年度データ長
    ''' </summary>
    Private Const NENDO_LENGTH As Integer = 4

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format(" yyyy 形式の半角数字({0}桁)で入力してください", NENDO_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, NENDO_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", NENDO_LENGTH))
        End If

        ' 数字
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, "半角数字以外の値があります")
        End If

        Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
