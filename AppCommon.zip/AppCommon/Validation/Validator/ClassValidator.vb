﻿Imports System.Drawing

''' <summary>
''' クラスコードバリデータ
''' </summary>
Public Class ClassValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' クラスコード長
    ''' </summary>
    Private Const CODE_LENGTH As Integer = 2

	''' <summary>
	''' クラスコード最小桁数
	''' </summary>
	Private Const MIN_LENGTH As Integer = 1

	''' <summary>
	''' クラスコード最大桁数
	''' </summary>
	Private Const MAX_LENGTH As Integer = 4

	''' <summary>
	''' 概要メッセージ
	''' </summary>
	''' <returns></returns>
	Protected Overrides Property SummaryMessage As String = String.Format("{0}桁～{1}桁の半角英数字で入力してください", MIN_LENGTH, MAX_LENGTH)


	''' <summary>
	''' コンストラクタ
	''' </summary>
	''' <param name="columnName"></param>
	''' <param name="isRequired"></param>
	Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

		' 桁数
		If Not ValidateChecker.IsVariableByteLengthRange(value, MIN_LENGTH, MAX_LENGTH) Then
			Return NewInvalidResult(value, String.Format("{0}桁～{1}桁の半角英数字で入力してください", MIN_LENGTH, MAX_LENGTH))
		End If

		' 属性(英字大文字)
		If Not ValidateChecker.IsHalfWidthAlphabetOrNumberOnly(value) Then
			Return NewInvalidResult(value, "半角英字(大文字)以外の値があります")
		End If

		Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
