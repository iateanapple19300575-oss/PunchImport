﻿''' <summary>
''' 代行実績CSVバリデーションクラス
''' </summary>
Public Class DelegationCsvValidation
    Inherits CsvValidationAbstract

    '''' <summary>
    '''' CSV項目名リスト
    '''' </summary>
    'Public Shared ReadOnly csvColumns As New List(Of String) _
    '            ({
    '                "日付", "曜日", "コマ", "教室", "クラス", "担当", "出講名", "科目", "テキスト回", "ピンチ", "入力日"
    '            })


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationDelegationRule()
    End Sub

    '''' <summary>
    '''' CSV項目名リスト
    '''' </summary>
    'Public Overrides Function Headers() As List(Of String)
    '    Return New List(Of String) _
    '            ({
    '                "日付", "曜日", "コマ", "教室", "クラス", "担当", "出講名", "科目", "テキスト回", "ピンチ", "入力日"
    '            })
    'End Function

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
        Select Case columnName
            Case "日付"
                Return New DateValidator(columnName, True)
            Case "曜日"
                Return New DayOfWeekValidator(columnName, True)
            Case "コマ"
                Return New KomaValidator(columnName, True)
            Case "教室"
                Return New RoomValidator(columnName, True)
            Case "クラス"
                Return New GradeAndClasseValidator(columnName, True)
            Case "担当"
                Return New TeacherCodeValidator(columnName, True)
            Case "出講名"
                Return New LectureNameValidator(columnName, False)
            Case "科目"
                Return New SubjectsValidator(columnName, False)
            Case "テキスト回"
                Return New TextTimesValidator(columnName, True)
            Case "ピンチ"
                Return New PinchValidator(columnName, True)
            Case "入力日"
                Return New DateTimeValidator(columnName, False)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
