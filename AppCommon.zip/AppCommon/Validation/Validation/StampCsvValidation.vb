﻿''' <summary>
''' 打刻データCSVバリデーションクラス
''' </summary>
Public Class StampCsvValidation
  Inherits CsvValidationAbstract

  Private TagetDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationStampRule()
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv, ByVal targetDate As Date)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationStampRule(targetDate)
        Me.TagetDate = targetDate
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
    Select Case columnName
      Case "(年月日)"
        Return New DateAndTargetMonthValidator(columnName, True, TagetDate)
      Case "姓"
        Return Nothing
      Case "名"
        Return Nothing
      Case "姓名"
        Return New NormalStringValidator(columnName, True)
      Case "スタッフコード"
        Return New TeacherCodeValidator(columnName, True)
      Case "スタッフ種別"
        Return Nothing
      Case "所属グループコード"
        Return Nothing
      Case "所属グループ名"
        Return Nothing
      Case "打刻場所"
        Return Nothing
      Case "出勤時刻"
        Return New TimeZeroSuppressValidator(columnName, False)
      Case "退勤時刻"
        Return New TimeZeroSuppressValidator(columnName, False)
      Case "出勤実時刻"
        Return New TimeZeroSuppressValidator(columnName, False)
      Case "退勤実時刻"
        Return New TimeZeroSuppressValidator(columnName, False)
      Case "休憩時間"
        Return New RealNumberValidator(columnName, False)
      Case Else
        Return Nothing
    End Select
  End Function

End Class
