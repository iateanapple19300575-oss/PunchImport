﻿Imports MainApp.Data.Dto

Public Class CsvValidationFactory

    ''' <summary>
    ''' データタイプ
    ''' </summary>
    ''' <returns></returns>
    Private Property DataType As Integer = 0

    ''' <summary>
    ''' CSVファイル名
    ''' </summary>
    ''' <returns></returns>
    Private Property FileName As String

    ''' <summary>
    ''' 対象年月度
    ''' </summary>
    ''' <returns></returns>
    Private Property YearMonth As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal dataType As Integer, ByVal fileName As String, ByVal yearMonth As Date)
        Me.DataType = dataType
        Me.FileName = fileName
        Me.YearMonth = yearMonth
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal dataType As Integer, ByVal fileName As String)
        Me.DataType = dataType
        Me.FileName = fileName
        Me.YearMonth = Nothing
    End Sub

    ''' <summary>
    ''' バリデーションルールの
    ''' </summary>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal param As CsvImportParameterDto) As ICsvValidation
        Select Case DataType
            Case TableImportHistoryConst.TYPE_TIME_PATTERN
                Return New TimePatternCsvValidation(New TimePatternCsv(param.FilePath))
            Case TableImportHistoryConst.TYPE_TIME_TABLE_SITE
                Return New TimeTableSiteCsvValidation(New TimeTableSiteCsv(param.FilePath))
            Case TableImportHistoryConst.TYPE_TIME_TABLE_CLASS
                Return New TimeTableClassCsvValidation(New TimeTableClassCsv(param.FilePath))
            Case TableImportHistoryConst.TYPE_TEACHER_WAGE
                Return New TeacherWageCsvValidation(New TeacherWageCsv(param.FilePath))
            Case TableImportHistoryConst.TYPE_T_STAMP
                Return New StampCsvValidation(New StampCsv(param.FilePath))
            Case TableImportHistoryConst.TYPE_LECTURE_REGULAR
                Return New PlanCsvValidation(New PlanCsv(param.FilePath))
            Case TableImportHistoryConst.TYPE_BUSINESS_PUNCH
                Return New RequestCsvValidation(New RequestCsv(param.FilePath))
            Case TableImportHistoryConst.TYPE_T_DELEGATION
                Return New DelegationCsvValidation(New DelegationCsv(param.FilePath))
            Case Else
                Return Nothing
        End Select
    End Function
End Class
