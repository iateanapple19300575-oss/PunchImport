﻿''' <summary>
''' 講師給与単価CSVバリデーションクラス
''' </summary>
Public Class TeacherWageCsvValidation
	Inherits CsvValidationAbstract

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationTimeTableSiteRule()
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
		Select Case columnName
			Case "Teacher_Code"
				Return New TeacherCodeValidator(columnName, True)
			Case "Effective_Date"
				Return New DateValidator(columnName, True)
			Case "Lecture_Rate"
				Return New RateValidator(columnName, True)
			Case "Hourly_Rate"
				Return New RateValidator(columnName, False)
			Case Else
				Return Nothing
		End Select
	End Function

End Class
