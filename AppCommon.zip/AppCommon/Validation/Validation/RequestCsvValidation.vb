﻿''' <summary>
''' 業務依頼CSVバリデーションクラス
''' </summary>
Public Class RequestCsvValidation
    Inherits CsvValidationAbstract

    '''' <summary>
    '''' CSV項目名リスト
    '''' </summary>
    'Public Shared ReadOnly csvColumns As New List(Of String) _
    '            ({
    '                "教室", "科目", "講師名", "日付", "業務名", "開始", "終了", "対象", "内容", "コード",
    '                "区分", "実時間", "＠", "乗数", "みなし回数", "金額", "担当者", "リーダー", "教務室"
    '            })

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationRequestRule()
    End Sub

    '''' <summary>
    '''' CSV項目名リスト
    '''' </summary>
    'Public Overrides Function Headers() As List(Of String)
    '    Return New List(Of String) _
    '            ({
    '                "教室", "科目", "講師名", "日付", "業務名", "開始", "終了", "対象", "内容", "コード",
    '                "区分", "実時間", "＠", "乗数", "みなし回数", "金額", "担当者", "リーダー", "教務室"
    '            })
    'End Function

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
        Select Case columnName
            Case "教室"
                Return New RoomValidator(columnName, True)
            Case "科目"
                Return New SubjectsValidator(columnName, True)
            Case "講師名"
                Return Nothing
            Case "日付"
                Return New DateValidator(columnName, True)
            Case "業務名"
                Return Nothing
            Case "開始"
                Return New TimeValidator(columnName, True)
            Case "終了"
                Return New TimeValidator(columnName, True)
            Case "対象"
                Return Nothing
            Case "内容"
                Return Nothing
            Case "コード"
                Return New TeacherCodeValidator(columnName, True)
            Case "区分"
                Return New IntegerValidator(columnName, False)
            Case "実時間"
                Return New IntegerValidator(columnName, False)
            Case "＠"
                Return New AmountValidator(columnName, True)
            Case "乗数"
                Return New IntegerValidator(columnName, False)
            Case "みなし回数"
                Return New RealNumberValidator(columnName, False)
            Case "金額"
                Return New AmountValidator(columnName, True)
            Case "担当者"
                Return Nothing
            Case "リーダー"
                Return Nothing
            Case "教務室"
                Return Nothing
            Case Else
                Return Nothing
        End Select
    End Function
End Class
