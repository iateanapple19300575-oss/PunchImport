﻿''' <summary>
''' 時間パターンCSVバリデーションクラス
''' </summary>
Public Class TimePatternCsvValidation
    Inherits CsvValidationAbstract

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationTimePatternRule()
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
        Select Case columnName
            Case "年度"
                Return New NendoValidator(columnName, True)
            Case "年月日"
                Return New DateValidator(columnName, True)
            Case "曜日"
                Return New DayOfWeekJValidator(columnName, True)
            Case "曜日区分"
                Return New DayOfWeekPatternValidator(columnName, True)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
