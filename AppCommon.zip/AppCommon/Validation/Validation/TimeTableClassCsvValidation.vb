﻿''' <summary>
''' クラス時間割CSVバリデーションクラス
''' </summary>
Public Class TimeTableClassCsvValidation
	Inherits CsvValidationAbstract

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationTimeTableClassRule()
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
		Select Case columnName
            Case "Setting_Category"
                Return New ApplicablePeriodValidator(columnName, True)
			Case "Site_Code"
				Return New RoomValidator(columnName, True)
			Case "Target_Period"
				Return New PeriodDateValidator(columnName, True)
			Case "Grade"
				Return New GradeValidator(columnName, True)
			Case "Class_Code"
				Return New ClassValidator(columnName, True)
            Case "Koma_Seq"
                Return New KomaValidator(columnName, True)
			Case "Start_Time"
				Return New TimeValidator(columnName, True)
			Case "End_Time"
				Return New TimeValidator(columnName, True)
			Case Else
				Return Nothing
		End Select
	End Function

End Class
