﻿Namespace Generated

''' <summary>
''' Entity: C_Closing_Management
''' C_Closing_Management
''' </summary>
Public Class C_Closing_ManagementEntity
    Inherits C_Closing_ManagementDto

    ''' <summary>
    ''' 新規作成かどうか
    ''' </summary>
    Public Property IsNew As Boolean

    ''' <summary>
    ''' 変更済みかどうか
    ''' </summary>
    Public Property IsDirty As Boolean

    ''' <summary>
    ''' 変更フラグを立てる
    ''' </summary>
    Public Sub MarkDirty()
        Me.IsDirty = True
    End Sub

    ''' <summary>
    ''' 簡易バリデーション
    ''' </summary>
    Public Function Validate() As Boolean
        Return True
    End Function

End Class

End Namespace
