﻿Imports System.Data.SqlClient

Public Class AttendanceDao
  Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 打刻外業務給講師１日データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function LoadOneDayData(ByVal param As DaoParameter) As DataTable
    Dim S = Tables.ntb_Site
    Dim L = Tables.LectureActual
    Dim B = Tables.BusinessActual

    Dim sqlString As String =
    $"SELECT
        CONCAT(
          LA.{L.Site_Code}
          , ':'
          , REPLACE (L.{S.Site_Name}, '　', '') COLLATE Japanese_CS_AS_KS_WS
        ) As {S.Site_Name}
        , Case WHEN LA.{L.Koma_Seq} < 100 Then Convert(Char (2), LA.{L.Koma_Seq}) ELSE '' END As {L.Koma_Seq}
        , Convert(Char (5), LA.{L.Start_Time}) As {L.Start_Time}
        , Convert(Char (5), LA.{L.End_Time}) As {L.End_Time}
        , LA.{L.Pinch_Type}
        , LA.{L.Data_Type}
        , LA.{L.Grade}
        , LA.{L.Class_Code}
        , BA.{B.Business_Name}
        , BA.{B.Contents}
      FROM
        {L.TableName} LA 
        LEFT JOIN(
          SELECT 
            {S.Site_Code}, {S.Site_Name} 
          FROM
            {S.TableName}
        ) L 
          ON ( 
            LA.{L.Site_Code} = L.{S.Site_Code} COLLATE Japanese_CS_AS_KS_WS
          ) 

        LEFT JOIN (
            SELECT 
                    {B.Lecture_Date}
                    , {B.Site_Code}
                    , {B.Teacher_Code}
                    , {B.Subject}
                    , {B.Business_Name}
                    , {B.Target}
                    , {B.Contents}
                    , {B.Start_Time}
                    , {B.End_Time}
                    , {B.Category}
                    , {B.Working_Time}
            FROM 
                {B.TableName}
              WHERE 1=1 
                AND {B.Lecture_Date} = @{L.Lecture_Date}
        ) BA
            ON (
                LA.{L.Lecture_Date} = BA.{B.Lecture_Date}
                AND LA.{L.Site_Code} = BA.{B.Site_Code}
                AND LA.{L.Teacher_Code} = BA.{B.Teacher_Code}
                AND LA.{L.Start_Time} = BA.{B.Start_Time}
            )

      WHERE 1=1 
        AND LA.{L.Phase} = @{L.Phase}
        AND LA.{L.Teacher_Code} = @{L.Teacher_Code}
        AND LA.{L.Lecture_Date} = @{L.Lecture_Date}
      ORDER BY
          LA.{L.Start_Time} ASC;
    " ' SQL String End

    Return SqlUtil.ExecuteDataTable(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{L.Phase}", .Value = 2},
        New SqlParameter() With {.ParameterName = $"@{L.Teacher_Code}", .Value = param.TeacherCode},
        New SqlParameter() With {.ParameterName = $"@{L.Lecture_Date}", .Value = param.TargetDate}
      )
  End Function
End Class
