﻿Imports System.Data.SqlClient

Public Class AttendancePunchDao
  Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' ある日の講師の打刻情報を取得する。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetOneDayByLectureDateAndTeacher(ByVal TargetDate As Date, ByVal param As DaoParameter) As DataTable
    Dim SD = Tables.StampData
    Dim TE = Tables.TranspoExpenses

    ' TODO:後で正しい値を設定する
    Dim sqlString As String = DailyChecksQuery.SelectSql(TargetDate, param)
    '$"
    '" ' SQL String End

    Return SqlUtil.ExecuteDataTable(sqlString.ToString(), Nothing)
  End Function

  ''' <summary>
  ''' ある月の打刻情報を取得する。
  ''' </summary>
  ''' <returns></returns>
  Public Function GetMonthlyPunchData(ByVal TargetDate As Date, ByVal param As DaoParameter) As DataTable
    Dim SD = Tables.StampData
    Dim TE = Tables.TranspoExpenses

    ' TODO:後で正しい値を設定する
    Dim sqlString As String = DailyChecksQuery.SelectSql(TargetDate, param)
    '$"
    '" ' SQL String End

    Return SqlUtil.ExecuteDataTable(sqlString.ToString(), Nothing)
  End Function



End Class
