﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class RequsttNoPunchCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.RequsttNoPunch

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.RequsttNoPunch

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.RequsttNoPunch

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub


    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
                ({
                    "講師コード", "勤務日", "業務名", "教室コード", "開始時間", "終了時間", "備考", "交通費支給対象"
                })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
                ({
                    DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleRight
                })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            CsvDataTable.Columns.Add("Business_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("Contents", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Transp_Expens_Flag", Type.GetType("System.Byte"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim checkdate As String = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnStamp.日付)))
                If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(checkdate, yearMonth) = False) Then
                    Continue For
                End If

                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequestNoPunch.講師コード)))
                addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDate(rowData(Headers(CsvColumnRequestNoPunch.勤務日)))
                addRowData.Item("Business_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequestNoPunch.業務名)))
                addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequestNoPunch.教室コード)))
                addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnRequestNoPunch.開始時間)))
                addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnRequestNoPunch.終了時間)))
                addRowData.Item("Contents") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequestNoPunch.備考)))
                addRowData.Item("Transp_Expens_Flag") = ConvertNullToDBNullWithByte(rowData(Headers(CsvColumnRequestNoPunch.交通費支給対象)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    ' 対象年月以外は、捨てる
                    If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(fields(CsvColumnRequestNoPunch.勤務日), yearMonth) = False) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(fields(CsvColumnRequestNoPunch.講師コード))
                    addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnRequestNoPunch.勤務日))
                    addRowData.Item("Business_Name") = ConvertNullToDBNullWithString(fields(CsvColumnRequestNoPunch.業務名))
                    addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(fields(CsvColumnRequestNoPunch.教室コード))
                    addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnRequestNoPunch.開始時間))
                    addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnRequestNoPunch.終了時間))
                    addRowData.Item("Contents") = ConvertNullToDBNullWithString(fields(CsvColumnRequestNoPunch.備考))
                    addRowData.Item("Transp_Expens_Flag") = ConvertNullToDBNullWithDecimal(fields(CsvColumnRequestNoPunch.交通費支給対象))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
            New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
            New SqlBulkCopyColumnMapping("Business_Name", "Business_Name"),
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time"),
            New SqlBulkCopyColumnMapping("Contents", "Contents"),
            New SqlBulkCopyColumnMapping("Transp_Expens_Flag", "Transp_Expens_Flag")
        }
    End Function

End Class
