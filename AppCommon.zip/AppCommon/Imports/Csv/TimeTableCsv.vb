﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class TimeTableSiteCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.TimeTableSite

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.TimeTableSite

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.TimeTableSite

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub


    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
            ({
              "Year", "Site_Code", "Day_Pattern", "Koma", "Start_Time", "End_Time"
            })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
            ({
              DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleLeft _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter
            })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Year", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Schedule_Pattern", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Koma_Seq", Type.GetType("System.Byte"))
            CsvDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Year") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableSite.年)))
                addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableSite.教室コード)))
                addRowData.Item("Schedule_Pattern") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableSite.日程パターン)))
                addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithByte(rowData(Headers(CsvColumnTimeTableSite.コマ)))
                addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnTimeTableSite.開始時間).Substring(11)))
                addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnTimeTableSite.終了時間).Substring(11)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Year") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableSite.年))
                    addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableSite.教室コード))
                    addRowData.Item("Schedule_Pattern") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableSite.日程パターン))
                    addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithByte(fields(CsvColumnTimeTableSite.コマ))
                    addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnTimeTableSite.開始時間))
                    addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnTimeTableSite.終了時間))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Year", "Year"),
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Schedule_Pattern", "Schedule_Pattern"),
            New SqlBulkCopyColumnMapping("Koma_Seq", "Koma_Seq"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time")
        }
    End Function

End Class
