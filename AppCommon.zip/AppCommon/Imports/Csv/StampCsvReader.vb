﻿Public Class StampCsvReader
    Inherits CsvReader

	Public Sub New()
	End Sub

End Class
