﻿Public Class CsvReaderResultData

    ''' <summary>
    ''' 処理結果（True：正常／False：異常）
    ''' </summary>
    ''' <returns></returns>
    Public Property Success As Boolean = True

    ''' <summary>
    ''' データフォーマットエラー
    ''' </summary>
    ''' <returns></returns>
    Public Property FormarError As Boolean = False

End Class
