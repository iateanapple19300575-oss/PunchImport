﻿Imports System.Data.SqlClient

Public MustInherit Class CsvAbstract
    Implements ICsv

    ''' <summary>
    ''' CSVファイル名
    ''' </summary>
    ''' <returns></returns>
    Public Property FileName As String Implements ICsv.FileName

    ''' <summary>
    ''' CSVタイプ
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property CsvType As Integer Implements ICsv.CsvType

    ''' <summary>
    ''' カテゴリ
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property Ccategory As String Implements ICsv.Ccategory

    ''' <summary>
    ''' データの種類を表す名称
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property DataName As String Implements ICsv.DataName

    ''' <summary>
    ''' CSVファイルのヘッダカラム名のリストをサブクラスで実装する。
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Function Headers() As List(Of String) Implements ICsv.Headers

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        Me.FileName = fileName
    End Sub

    ''' <summary>
    ''' CSVのカラム数を返す。
    ''' </summary>
    ''' <returns></returns>
    Public Function ColumnsCount() As Integer Implements ICsv.ColumnsCount
        Return Headers().Count
    End Function

    Public Overridable Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping) Implements ICsv.BuckCopyMapping
        Throw New NotImplementedException()
    End Function

    Protected Function ConvertNullToDBNullWithDate(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, Date.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithDateTime(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, DateTime.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithTimeSpan(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, TimeSpan.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithByte(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, Byte.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithInt16(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, Int16.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithInt32(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, Int32.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithDecimal(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, Decimal.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithDouble(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, Double.Parse(value))
    End Function

    Protected Function ConvertNullToDBNullWithString(ByVal value As String) As Object
        Return If(String.IsNullOrEmpty(value), DBNull.Value, value)
    End Function

    ' 
    Public MustOverride Function ContentAlign() As List(Of Integer)
    Public MustOverride Function CreateTableDefinition() As DataTable
    Public MustOverride Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional ByVal yearMonth As Date = Nothing) As DataTable
    Public MustOverride Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
End Class
