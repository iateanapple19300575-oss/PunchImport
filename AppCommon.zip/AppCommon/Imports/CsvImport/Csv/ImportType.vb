﻿Public Class ImportType

    ''' <summary>
    ''' カテゴリ
    ''' </summary>
    Public NotInheritable Class ImportCcategory
        ''' <summary>時間パターン</summary>
        Public Shared ReadOnly TimePattern As String = "M"
        ''' <summary>教室時間割</summary>
        Public Shared ReadOnly TimeTableSite As String = "M"
        ''' <summary>クラス別時間割</summary>
        Public Shared ReadOnly TimeTableClass As String = "M"
        ''' <summary>講師単価設定</summary>
        Public Shared ReadOnly TeacherUnitPrice As String = "M"
        ''' <summary>打刻データ</summary>
        Public Shared ReadOnly PunchData As String = "T"
        ''' <summary>出講データ</summary>
        Public Shared ReadOnly LecturePlan As String = "T"
        ''' <summary>出講データ（講習）</summary>
        Public Shared ReadOnly LectureCourse As String = "T"
        ''' <summary>代講実績</summary>
        Public Shared ReadOnly PinchActual As String = "T"
        ''' <summary>業務届</summary>
        Public Shared ReadOnly RequestActual As String = "T"
        ''' <summary>打刻外業務給</summary>
        Public Shared ReadOnly RequsttNoPunch As String = "T"
    End Class

    ''' <summary>
    ''' CSV種類
    ''' </summary>
    Public Enum ImportCsvType
        Non = 0
        ''' <summary>時間パターン</summary>
        TimePattern = 11
        ''' <summary>教室時間割</summary>
        TimeTableSite = 12
        ''' <summary>クラス別時間割</summary>
        TimeTableClass = 13
        ''' <summary>打刻データ</summary>
        PunchData = 101
        ''' <summary>出講データ</summary>
        LecturePlan = 102
        ''' <summary>出講データ（講習）</summary>
        LectureCourse = 10
        ''' <summary>代講実績</summary>
        PinchActual = 104
        ''' <summary>業務届</summary>
        RequestActual = 105
        ''' <summary>打刻外業務給</summary>
        RequsttNoPunch = 106
        ''' <summary>講師単価設定</summary>
        TeacherUnitPrice = 201
    End Enum

    ''' <summary>
    ''' データタイプ
    ''' </summary>
    Public Enum ImportDataType
        Non = 0
        ''' <summary>時間パターン</summary>
        TimePattern = 0
        ''' <summary>教室時間割</summary>
        TimeTableSite = 0
        ''' <summary>クラス別時間割</summary>
        TimeTableClass = 0
        ''' <summary>打刻データ</summary>
        PunchData = 1
        ''' <summary>出講データ</summary>
        LecturePlan = 1
        ''' <summary>出講データ（講習）</summary>
        LectureCourse = 1
        ''' <summary>代講実績</summary>
        PinchActual = 1
        ''' <summary>業務届</summary>
        RequestActual = 2
        ''' <summary>打刻外業務給</summary>
        RequsttNoPunch = 2
        ''' <summary>講師単価設定</summary>
        TeacherUnitPrice = 201
    End Enum

End Class

''' <summary>
''' カテゴリ
''' </summary>
Public NotInheritable Class ImportDataName
    ''' <summary>時間パターン</summary>
    Public Shared ReadOnly TimePattern As String = "時間パターン"
    ''' <summary>教室時間割</summary>
    Public Shared ReadOnly TimeTableSite As String = "教室時間割"
    ''' <summary>クラス別時間割</summary>
    Public Shared ReadOnly TimeTableClass As String = "クラス別時間割"
    ''' <summary>講師単価設定</summary>
    Public Shared ReadOnly TeacherUnitPrice As String = "講師単価設定"
    ''' <summary>打刻データ</summary>
    Public Shared ReadOnly PunchData As String = "打刻データ"
    ''' <summary>出講データ</summary>
    Public Shared ReadOnly LecturePlan As String = "出講データ"
    ''' <summary>出講データ（講習）</summary>
    Public Shared ReadOnly LectureCourse As String = "出講データ（講習）"
    ''' <summary>代講実績データ</summary>
    Public Shared ReadOnly PinchActual As String = "代講実績データ"
    ''' <summary>業務届データ</summary>
    Public Shared ReadOnly RequestActual As String = "業務届データ"
    ''' <summary>打刻外業務給</summary>
    Public Shared ReadOnly RequsttNoPunch As String = "打刻外業務給"
End Class

''' <summary>
''' エラータイプ
''' </summary>
Public Enum ImportDataErrorType
    ''' <summary>正常</summary>
    Success = 0

    ''' <summary>データ無し(0件)</summary>
    DataNotFound = 1

    ''' <summary>フォーマットエラー</summary>
    FormatError = 2

    ''' <summary>フォーマットエラー</summary>
    DuplicateError = 3

    ''' <summary>対象あり（対象外データ含む）</summary>
    IncludingNonEligible = 4

    ''' <summary>対象無し（対象外データのみ）</summary>
    OnlyNonEligible = 5

    ''' <summary>その他エラー</summary>
    OtherError = 99

End Enum


Public Module MasterImportTypes
    Public Const TimePattern As String = "TimePattern"
    Public Const TimeTableSite As String = "TimeTableSite"
    Public Const TimeTableClass As String = "TimeTableClass"
    Public Const Lecturer As String = "Lecturer"
End Module

Public Module TranDataImportTypes
    Public Const PunchData As String = "PunchData"
    Public Const LecturePlan As String = "LecturePlan"
    Public Const LectureCourse As String = "LectureCourse"
    Public Const PinchActual As String = "PinchActual"
    Public Const RequestActual As String = "RequestActual"
    Public Const RequestNoPunch As String = "RequestNoPunch"
End Module


Public Module MasterImportTable
    Public Const TIME_PATTERN As String = "M_Time_Pattern"
    Public Const TIMETABLE_SITE As String = "M_Timetable_Site"
    Public Const TIMETABLE_CLASS As String = "M_Timetable_Class"
    Public Const TEACHER_WAGE_WORK As String = "W_Teacher_Wage"
    Public Const TEACHER_WAGE As String = "M_Teacher_Wage"
End Module

Public Module TranDataImportTable
    Public Const PUNCH_DATA As String = "W_Stamp_Data"
    Public Const LECTURE_PLAN As String = "W_Lecture_Plan"
    Public Const LECTURE_COURSE As String = "W_Lecture_Plan"
    Public Const PINCH_ACTUAL As String = "W_Pinch_Actual"
    Public Const REQUEST_ACTUAL As String = "W_Request_Actual"
    Public Const REQUEST_NOPUNCH As String = "W_Business_No_Punch"
End Module
