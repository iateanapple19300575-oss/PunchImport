﻿''' <summary>
''' CSV を読み込み、RawImportRow のリストに変換する Strategy。
''' </summary>
Public Interface ICsvReader

    ''' <summary>
    ''' CSVファイル名を返す。
    ''' </summary>
    Function FileName() As String

    ''' <summary>
    ''' CSV ファイルを読み込み、DTO のリストに変換する。
    ''' </summary>
    Function Read(ByVal filePath As String) As List(Of Dictionary(Of String, String))

  ''' <summary>
  ''' CSVフォーマットのバリデーションを行う。
  ''' </summary>
  ''' <param name="filePath"></param>
  ''' <returns></returns>
  Function FormatValidation(ByVal filePath As String) As Boolean

    ''' <summary>
    ''' 内包するCSVインスタンスを返す。
    ''' </summary>
    ''' <returns></returns>
    Function GetCsvInstance() As ICsv

    ''' <summary>
    ''' CSVファイルの内容をDataTableに詰めて返す。
    ''' </summary>
    ''' <param name="fileName"></param>
    ''' <param name="yearMonth"></param>
    ''' <returns></returns>
    Function ToDataTable(fileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable

End Interface