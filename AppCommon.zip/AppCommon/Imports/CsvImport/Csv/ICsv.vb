﻿Imports System.Data.SqlClient
''' <summary>
''' 
''' </summary>
Public Interface ICsv
    Property FileName As String
    Property CsvType As Integer
    Property Ccategory As String
    Property DataName As String
    Function Headers() As List(Of String)
    Function ColumnsCount() As Integer
    Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
End Interface