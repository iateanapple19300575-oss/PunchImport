﻿Public Class BulkCopyResult
    Inherits ResultInfoData

    ''' <summary>
    ''' ファイル名
    ''' </summary>
    ''' <returns></returns>
    Public Property FileName As String = ""

    ''' <summary>
    ''' 対象年月
    ''' </summary>
    ''' <returns></returns>
    Public Property YearMonth As Date

End Class
