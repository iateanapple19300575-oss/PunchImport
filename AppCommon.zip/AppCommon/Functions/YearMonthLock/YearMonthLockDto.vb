﻿Namespace App.Common.Data.Dto

    ''' <summary>
    ''' DTO: T_Year_Month_Lock
    ''' 対象年度ロック
    ''' </summary>
    Public Class YearMonthLockDto

        ''' <summary>
        ''' 対象年月度
        ''' </summary>
        Public Property YearMonth As String

        ''' <summary>
        ''' ロック状態
        ''' </summary>
        Public Property LockStatus As String

        ''' <summary>
        ''' ロック開始ユーザー
        ''' </summary>
        Public Property LockUser As String

        ''' <summary>
        ''' ロック開始PC
        ''' </summary>
        Public Property LockPc As String

        ''' <summary>
        ''' ロック開始時間
        ''' </summary>
        Public Property LockDatetime As DateTime

        ''' <summary>
        ''' ロック解除ユーザー
        ''' </summary>
        Public Property UnlockUser As String

        ''' <summary>
        ''' ロック解除PC
        ''' </summary>
        Public Property UnlockPc As String

        ''' <summary>
        ''' ロック解除時間
        ''' </summary>
        Public Property UnlockDatetime As Nullable(Of DateTime)

        ''' <summary>
        ''' 作成日
        ''' </summary>
        Public Property CreateDate As DateTime

        ''' <summary>
        ''' 作成者
        ''' </summary>
        Public Property CreateUser As String

        ''' <summary>
        ''' 更新日
        ''' </summary>
        Public Property UpdateDate As Nullable(Of DateTime)

        ''' <summary>
        ''' 更新者
        ''' </summary>
        Public Property UpdateUser As String

    End Class

End Namespace
