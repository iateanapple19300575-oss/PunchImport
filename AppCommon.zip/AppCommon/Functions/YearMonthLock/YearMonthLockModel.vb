﻿Imports App.Common.Data.Dto
Imports App.Common.Data.Entity

Namespace App.Common.Data.Model

    ''' <summary>
    '''  TargetYearMonth Model
    ''' </summary>
    Public Class YearMonthLockModel

        '---------------
        ' 要求
        '---------------

        ''' <summary>
        ''' ロック要求しる対象年月度
        ''' </summary>
        Public Property NewYearMonth As String

        ''' <summary>
        ''' ロック要求しる対象年月度
        ''' </summary>
        Public Property NowYearMonth As Date


        '---------------
        ' 応答
        '---------------

        ''' <summary>
        ''' 処理結果（True:OK / False:NG）
        ''' </summary>
        ''' <returns></returns>
        Public Property Success As Boolean

        ''' <summary>
        ''' 結果詳細
        ''' 1: 他ユーザロック中
        ''' </summary>
        ''' <returns></returns>
        Public Property SubStatus As Integer

        ''' <summary>
        ''' メッセージ
        ''' </summary>
        ''' <returns></returns>
        Public Property Meassage As String

        ''' <summary>
        ''' ロック情報
        ''' </summary>
        ''' <returns></returns>
        Public Property ResponseData As YearMonthLockDto


        '---------------
        ' 例外
        '---------------

        ''' <summary>
        ''' 例外オブジェクト
        ''' </summary>
        ''' <returns></returns>
        Public Property Exception As Exception

        ''' <summary>
        ''' 業務メッセージ
        ''' </summary>
        ''' <returns></returns>
        Public Property BusinessMessage As String


        ''' <summary>
        ''' コンストラクタ
        ''' </summary>
        Public Sub New()
            Success = False
            SubStatus = 0
            Meassage = ""
            ResponseData = New YearMonthLockDto
        End Sub


        ''' <summary>
        ''' Model から DTO へ変換
        ''' </summary>
        Public Function ToEntity() As YearMonthLockEntity
            Dim entity As New YearMonthLockEntity()
            entity.NewYearMonth = Me.NewYearMonth
            entity.NowYearMonth = Me.NowYearMonth

            Return entity
        End Function

        ''' <summary>
        ''' Entity から Model を生成
        ''' </summary>
        Public Sub FromEntity(entity As YearMonthLockEntity)
            Me.Success = entity.Success
            Me.SubStatus = entity.SubStatus
            Me.ResponseData = entity.ResponseData
        End Sub

    End Class

End Namespace
