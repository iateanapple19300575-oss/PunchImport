﻿Imports App.Common.Data.Dto
Imports App.Common.Data.Entity

Public Class YearMonthLockDomain

    ''' <summary>
    ''' ロック状態
    ''' </summary>
    Private Const YEAR_MONTH_LOCKED As String = "L"

    ''' <summary>
    ''' ロック解除状態
    ''' </summary>
    Private Const YEAR_MONTH_UNLOCKED As String = "U"

    '''' <summary>
    '''' 対象年月ロックトラン
    '''' </summary>
    Private _tran As YearMonthLockRepository


    ''' <summary>
    ''' トランザクション管理なしのコンストラクタ
    ''' </summary>
    Public Sub New()
        _tran = New YearMonthLockRepository()
    End Sub

    ''' <summary>
    ''' トランザクション管理ありのコンストラクタ
    ''' </summary>
    Public Sub New(ByVal uow As DbTransactionScope)
        _tran = New YearMonthLockRepository(uow)
    End Sub

    ''' <summary>
    ''' ロック解除(自分自身)
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function UnlockingYourself(ByVal entity As YearMonthLockEntity) As Integer
        Dim cnount As Integer = 0

        ' 現在の対象年月度ロック解除
        If Not DateUtil.IsNullOrEmpty(entity.NowYearMonth) Then
            Dim newYearMonth As String = DateUtil.DateToFormatString(entity.NewYearMonth)
            cnount = _tran.UnLock(newYearMonth)
            Return cnount
        End If

        Return cnount
    End Function

    ''' <summary>
    ''' ロック
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function LockYourself(ByVal entity As YearMonthLockEntity) As YearMonthLockEntity
        Dim result As New YearMonthLockEntity
        Dim cnount As Integer = 0
        Dim newYearMonth As String = DateUtil.DateToFormatString(entity.NewYearMonth)

        ' 年月のロック情報取得
        Dim resultData As New List(Of YearMonthLockDto)
        resultData = _tran.GetTargetDateInUse(newYearMonth)

        ' 今回の対象年度ロック処理
        If resultData.Count <= 0 Then
            ' 未登録(新規)
            cnount = _tran.LockForInsert(newYearMonth)
        Else
            ' 他ユーザロック中
            Dim resultDtoItem As YearMonthLockDto = resultData(0)
            If IsLocked(resultDtoItem) Then
                ' 他ユーザロック中
                result.SubStatus = 1
                result.ResponseData = resultDtoItem
            Else
                ' 解除中または、自端末ロック中
                cnount = _tran.LockForUpdate(newYearMonth)
            End If
        End If
        result.Success = True

        Return result
    End Function

    ''' <summary>
    ''' 強制解除
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function ForceUnlock(ByVal entity As YearMonthLockEntity) As YearMonthLockEntity
        Dim result As New YearMonthLockEntity
        Dim nowYearMonth As String = DateUtil.DateToFormatString(entity.NowYearMonth)

        ' 年月度ロック解除
        If Not DateUtil.IsNullOrEmpty(entity.NowYearMonth) Then
            result.Count = _tran.ForcedRelease(nowYearMonth)
        End If
        result.Success = True

        Return result
    End Function

    ''' <summary>
    ''' 他ユーザロック中判定
    ''' </summary>
    ''' <param name="dto"></param>
    ''' <returns></returns>
    Private Function IsLocked(ByVal dto As YearMonthLockDto) As Boolean
        If dto.LockStatus = YEAR_MONTH_LOCKED AndAlso
          (Not dto.LockUser = Environment.UserName OrElse
           Not dto.LockPc = Environment.MachineName) Then
            Return True
        End If

        Return False
    End Function

End Class
