﻿Imports App.Common.Data.Entity
Imports App.Common.Data.Model

''' <summary>
''' [YearMonthLock] 用Service
''' </summary>
Public Class YearMonthLockService

    ''' <summary>
    ''' ロック状態
    ''' </summary>
    Private Const YEAR_MONTH_LOCKED As String = "L"

    ''' <summary>
    ''' ロック解除状態
    ''' </summary>
    Private Const YEAR_MONTH_UNLOCKED As String = "U"


    '''' <summary>
    '''' 対象年月度ロック Domain
    '''' </summary>
    Private _domain As YearMonthLockDomain


    ''' <summary>
    ''' 年月度ロック処理
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function LockYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel
        Dim entity As New YearMonthLockEntity

        ' トランザクション管理
        Using uow As New DbTransactionScope()

            Try
                ' Domain Service生成
                Dim param As New YearMonthLockEntity
                param = model.ToEntity()
                _domain = New YearMonthLockDomain(uow)

                ' 自分自身をロック解除
                _domain.UnlockingYourself(param)

                ' 自分自身のロック
                entity = _domain.LockYourself(param)

                ' コミット
                uow.CommitTransaction()
                result.FromEntity(entity)
                result.Success = True

            Catch ex As Exception
                ' ロールバック
                uow.RollbackTransaction()
                result.Success = False
                result.Success = False
                Throw New AppException("対象年月度のロックが取得できませんでした")

            Finally
                result.FromEntity(entity)

            End Try
        End Using

        Return result
    End Function

    ''' <summary>
    ''' ロック強制解除
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function UnLockedTargetYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel
        Dim entity As New YearMonthLockEntity

        Try
            ' Domain Service生成
            Dim param As New YearMonthLockEntity
            param = model.ToEntity()
            _domain = New YearMonthLockDomain()

            ' ロック強制解除
            entity = _domain.ForceUnlock(param)
            entity.Success = True

        Catch ex As Exception
            entity.Success = False
            Throw New AppException(MessageIdConst.MSGID_E9001, "ロック解除ができませんでした", ex.InnerException)

        Finally
            result.FromEntity(entity)

        End Try

        Return result
    End Function

End Class
