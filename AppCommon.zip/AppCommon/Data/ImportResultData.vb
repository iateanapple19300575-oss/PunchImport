﻿Public Class ImportResultData
  Inherits ResultData

  ''' <summary>
  ''' 対象年月
  ''' </summary>
  ''' <returns></returns>
  Public Property TargetYearMonth As Date

    '''' <summary>
    '''' 対象年月
    '''' </summary>
    '''' <returns></returns>
    'Public Property ProcessDateTime As Date

    ''' <summary>
    ''' CSVバリデーション結果情報
    ''' </summary>
    ''' <returns></returns>
    Public Property ValidationResult As ImportResultInfo

    '''' <summary>
    '''' CSVインポート結果情報
    '''' </summary>
    '''' <returns></returns>
    Public Property ImportResult As BulkCopyResult

  ''' <summary>
  ''' CSVインポート履歴情報
  ''' </summary>
  ''' <returns></returns>
  Public Property ImportHistoryResult As New DataTable

End Class
