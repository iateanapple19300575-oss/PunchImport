﻿Imports System.Data.SqlClient

Public Class RequestNoPunchRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("DELETE").Append(" ")
        SqlQuery.Append("  FROM").Append(" ")
        SqlQuery.Append("    ").Append(DBTableConst.TABLE_NAME_BUSINESS_NO_PUNCH).Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1=1").Append(" ")
        SqlQuery.Append("  AND Lecture_Date >= " & "@期間開始日" & " ")
        SqlQuery.Append("  AND Lecture_Date <= " & "@期間終了日" & " ")
        SqlQuery.Append(";")

        Return ExecuteNonQuery(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
        )
    End Function

End Class
