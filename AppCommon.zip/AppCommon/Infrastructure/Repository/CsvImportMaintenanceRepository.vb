﻿'Imports System.Data.SqlClient
'Imports MainApp.Data.Dto
'Imports MainApp.Data.Entity

'Public Class CsvImportMaintenanceRepository
'  Implements ICsvImportMaintenanceRepository

'  Private historyRepo As New HistoryImportRepository
'  Private stampDataRepo As New StampDataRepository
'  Private lecturePlanRepo As New LecturePlanRepository
'  Private requestPlanRepo As New RequestPlanRepository
'  Private pinchActualRepo As New PinchActualRepository

'  Private timePatternRepo As New TimePatternRepository
'  Private timeTableSiteRepo As New TimeTableSiteRepository
'  Private timeTableClassRepo As New TimeTableClassRepository
'  Private teacherWageRepo As New TeacherWageRepository

'  Private ReadOnly _connection As SqlConnection

'  Public Sub New(conn As SqlConnection)
'    _connection = conn
'  End Sub

'  ''' <summary>
'  ''' 対象データ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Public Function DeleteSwapData(param As CsvImportParameterDto, tran As SqlTransaction) As Integer _
'    Implements ICsvImportMaintenanceRepository.DeleteSwapData

'    Select Case param.CsvType

'      Case TableImportHistoryConst.TYPE_T_STAMP
'        Return stampDataRepo.DeleteSwapData(param.TargetDate)
'      Case TableImportHistoryConst.TYPE_LECTURE_REGULAR
'        Return lecturePlanRepo.DeleteSwapData(param.TargetDate)
'      Case TableImportHistoryConst.TYPE_LECTURE_SEASONAL
'        Return timeTableClassRepo.DeleteSwapData(param.TargetDate)
'      Case TableImportHistoryConst.TYPE_T_DELEGATION
'        Return pinchActualRepo.DeleteSwapData(param.TargetDate)
'      Case TableImportHistoryConst.TYPE_BUSINESS_PUNCH
'        Return requestPlanRepo.DeleteSwapData(param.TargetDate)
'      Case TableImportHistoryConst.TYPE_TIME_PATTERN
'        Return timePatternRepo.DeleteSwapData(param.PeriodDates)
'      Case TableImportHistoryConst.TYPE_TIME_TABLE_SITE
'        Return timeTableSiteRepo.DeleteSwapData(param.TargetDate)
'      Case TableImportHistoryConst.TYPE_TIME_TABLE_CLASS
'        Return timeTableClassRepo.DeleteSwapData(param.TargetDate)
'      Case TableImportHistoryConst.TYPE_TEACHER_WAGE
'        Return 0
'      Case Else
'        Throw New Exception("未対応の CSV 種類です。")

'    End Select

'  End Function

'  ''' <summary>
'  ''' 過去対象期間：出講データ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Private Function DeleteSwapDataForStampData(param As CsvImportParameterDto, tran As SqlTransaction) As Integer Implements ICsvImportMaintenanceRepository.DeleteSwapDataForStampData
'    Return stampDataRepo.DeleteSwapData(param.TargetDate)
'  End Function

'  ''' <summary>
'  ''' 過去対象期間：出講データ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Private Function DeleteSwapDataForLecturePlan(param As CsvImportParameterDto, tran As SqlTransaction) As Integer Implements ICsvImportMaintenanceRepository.DeleteSwapDataForLecturePlan
'    Return lecturePlanRepo.DeleteSwapData(param.TargetDate)
'  End Function

'  ''' <summary>
'  ''' 過去対象期間：代講実績データ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Public Function DeleteSwapDataForPinchActual(param As CsvImportParameterDto, tran As SqlTransaction) As Integer Implements ICsvImportMaintenanceRepository.DeleteSwapDataForPinchActual
'    Return pinchActualRepo.DeleteSwapData(param.TargetDate)
'  End Function

'  ''' <summary>
'  ''' 過去対象期間：業務届データ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Public Function DeleteSwapDataForRequestPlan(param As CsvImportParameterDto, tran As SqlTransaction) As Integer Implements ICsvImportMaintenanceRepository.DeleteSwapDataForRequestPlan
'    Return requestPlanRepo.DeleteSwapData(param.TargetDate)
'  End Function

'  ''' <summary>
'  ''' 過去対象期間：時間パターンデータ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Public Function DeleteSwapDataForTimePattern(param As CsvImportParameterDto, tran As SqlTransaction) As Integer Implements ICsvImportMaintenanceRepository.DeleteSwapDataForTimePattern
'    Return timePatternRepo.DeleteSwapData(param.PeriodDates)
'  End Function


'  ''' <summary>
'  ''' 過去対象期間：教室時間割データ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Public Function DeleteSwapDataForTimeTableSite(param As CsvImportParameterDto, tran As SqlTransaction) As Integer Implements ICsvImportMaintenanceRepository.DeleteSwapDataForTimeTableSite
'    Return timeTableSiteRepo.DeleteSwapData(param.TargetDate)
'  End Function


'  ''' <summary>
'  ''' 過去対象期間：クラス別時間割データ削除
'  ''' </summary>
'  ''' <param name="param"></param>
'  ''' <param name="tran"></param>
'  ''' <returns></returns>
'  Public Function DeleteSwapDataForTimeTableClass(param As CsvImportParameterDto, tran As SqlTransaction) As Integer Implements ICsvImportMaintenanceRepository.DeleteSwapDataForTimeTableClass
'    Return timeTableClassRepo.DeleteSwapData(param.TargetDate)
'  End Function


'    ''' <summary>
'    ''' 取込履歴追加
'    ''' </summary>
'    ''' <param name="sqlDb"></param>
'    ''' <param name="entity"></param>
'    ''' <returns></returns>
'    Public Function InsertHistory(sqlDb As DbTransactionScope, entity As HistoryImportEntity) As Integer Implements ICsvImportMaintenanceRepository.InsertHistory
'        Return historyRepo.Insert(sqlDb, entity)
'    End Function
'End Class