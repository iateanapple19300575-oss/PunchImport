﻿Imports System.Data.SqlClient
Imports MainApp.Data.Entity
Imports Nts.Freamwork.Common.Utilities

Public Class TimetableClassRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' クラス別時間割テーブル [M_Timetable_Class]
    ''' </summary>
    ''' <returns></returns>
    Public Function SelectPivotMonth(ByVal entity As TimetableClassEntity) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  VS.Division_KND").Append(" ")
        SqlQuery.Append("  , MTC.Setting_Category").Append(" ")
        SqlQuery.Append("  , CASE ").Append(" ")
        SqlQuery.Append("    WHEN MTC.Setting_Category = 1 ").Append(" ")
        SqlQuery.Append("      THEN '年度設定' ").Append(" ")
        SqlQuery.Append("    WHEN MTC.Setting_Category = 2 ").Append(" ")
        SqlQuery.Append("      THEN '月設定' ").Append(" ")
        SqlQuery.Append("    WHEN MTC.Setting_Category = 3 ").Append(" ")
        SqlQuery.Append("      THEN '日設定' ").Append(" ")
        SqlQuery.Append("    ELSE '(範囲外)' ").Append(" ")
        SqlQuery.Append("    END As Category_Name").Append(" ")
        SqlQuery.Append("  , CASE ").Append(" ")
        SqlQuery.Append("    WHEN LEN(MTC.Target_Period) = 4 ").Append(" ")
        SqlQuery.Append("      THEN Target_Period ").Append(" ")
        SqlQuery.Append("    WHEN LEN(MTC.Target_Period) = 6 ").Append(" ")
        SqlQuery.Append("      THEN CONCAT( ").Append(" ")
        SqlQuery.Append("      SUBSTRING(MTC.Target_Period, 1, 4)").Append(" ")
        SqlQuery.Append("      , '/'").Append(" ")
        SqlQuery.Append("      , SUBSTRING(MTC.Target_Period, 5, 2)").Append(" ")
        SqlQuery.Append("    ) ").Append(" ")
        SqlQuery.Append("    WHEN LEN(MTC.Target_Period) = 8 ").Append(" ")
        SqlQuery.Append("      THEN CONCAT( ").Append(" ")
        SqlQuery.Append("      SUBSTRING(MTC.Target_Period, 1, 4)").Append(" ")
        SqlQuery.Append("      , '/'").Append(" ")
        SqlQuery.Append("      , SUBSTRING(MTC.Target_Period, 5, 2)").Append(" ")
        SqlQuery.Append("      , '/'").Append(" ")
        SqlQuery.Append("      , SUBSTRING(MTC.Target_Period, 7, 2)").Append(" ")
        SqlQuery.Append("    ) ").Append(" ")
        SqlQuery.Append("    ELSE '(範囲外)' ").Append(" ")
        SqlQuery.Append("    END As Target_Period").Append(" ")
        SqlQuery.Append("  , MTC.Site_Code").Append(" ")
        SqlQuery.Append("  , MAX(VS.Site_Name) As Site_Name").Append(" ")
        SqlQuery.Append("  , MTC.Grade").Append(" ")
        SqlQuery.Append("  , MTC.Class_Code").Append(" ")

        For i As Integer = 1 To 9
            SqlQuery.Append("  , CONVERT(VARCHAR (5), MAX(Start_Time_" & i.ToString() & "), 108) AS Start_Time_" & i.ToString()).Append(" ")
            SqlQuery.Append("  , CONVERT(VARCHAR (5), MAX(End_Time_" & i.ToString() & "), 108) AS End_Time_" & i.ToString()).Append(" ")
        Next

        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  ( ").Append(" ")
        SqlQuery.Append("    SELECT").Append(" ")
        SqlQuery.Append("      Setting_Category").Append(" ")
        SqlQuery.Append("      , Site_Code").Append(" ")
        SqlQuery.Append("      , Target_Period").Append(" ")
        SqlQuery.Append("      , Grade").Append(" ")
        SqlQuery.Append("      , Class_Code").Append(" ")
        SqlQuery.Append("      , Koma_Seq").Append(" ")

        For i As Integer = 1 To 9
            SqlQuery.Append("      , CASE ").Append(" ")
            SqlQuery.Append("          WHEN Koma_Seq = '" & i.ToString() & "' AND Start_Time IS NOT NULL THEN Start_Time").Append(" ")
            SqlQuery.Append("            ELSE NULL ").Append(" ")
            SqlQuery.Append("            END As Start_Time_" & i.ToString()).Append(" ")
            SqlQuery.Append("      , CASE ").Append(" ")
            SqlQuery.Append("          WHEN Koma_Seq = '" & i.ToString() & "' AND End_Time IS NOT NULL THEN End_Time").Append(" ")
            SqlQuery.Append("            ELSE NULL ").Append(" ")
            SqlQuery.Append("            END As End_Time_" & i.ToString()).Append(" ")
        Next

        SqlQuery.Append("    FROM").Append(" ")
        SqlQuery.Append("      M_Timetable_Class").Append(" ")
        SqlQuery.Append("  ) As MTC ").Append(" ")
        SqlQuery.Append("  LEFT JOIN VM_Site VS ").Append(" ")
        SqlQuery.Append("    ON ( ").Append(" ")
        SqlQuery.Append("      MTC.Site_Code = VS.Site_Code COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("    ) ").Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")

        If StringUtil.IsNotNullOrWhiteSpace(entity.Division_KND) Then
            SqlQuery.Append("  AND VS.Division_KND = @Division_KND").Append(" ")
        End If
        If StringUtil.IsNotNullOrWhiteSpace(entity.FirstYear) Then
            SqlQuery.Append("  AND (").Append(" ")
            SqlQuery.Append("           Target_Period LIKE @対象年1").Append(" ")
            SqlQuery.Append("        OR Target_Period LIKE @対象年2").Append(" ")
            SqlQuery.Append("      )").Append(" ")
        End If

        If StringUtil.IsNotNullOrWhiteSpace(entity.Site_Code) Then
            SqlQuery.Append("  AND MTC.Site_Code = @Site_Code").Append(" ")
        End If

        If entity.Grade.HasValue Then
            SqlQuery.Append("  AND MTC.Grade = @Grade").Append(" ")
        End If

        If StringUtil.IsNotNullOrWhiteSpace(entity.Class_Code) Then
            SqlQuery.Append("  AND MTC.Class_Code = @Class_Code").Append(" ")
        End If

        SqlQuery.Append("GROUP BY").Append(" ")
        SqlQuery.Append("  VS.Division_KND").Append(" ")
        SqlQuery.Append("  , MTC.Setting_Category").Append(" ")
        SqlQuery.Append("  , MTC.Site_Code").Append(" ")
        SqlQuery.Append("  , MTC.Target_Period").Append(" ")
        SqlQuery.Append("  , MTC.Grade").Append(" ")
        SqlQuery.Append("  , MTC.Class_Code").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        If StringUtil.IsNotNullOrWhiteSpace(entity.Division_KND) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Division_KND", .Value = entity.Division_KND})
        End If
        If StringUtil.IsNotNullOrWhiteSpace(entity.FirstYear) Then
            params.Add(New SqlParameter() With {.ParameterName = "@対象年1", .Value = entity.FirstYear & "%"})
            params.Add(New SqlParameter() With {.ParameterName = "@対象年2", .Value = entity.LastYear & "01%"})
        End If
        If StringUtil.IsNotNullOrWhiteSpace(entity.Site_Code) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = entity.Site_Code})
        End If
        If entity.Grade.HasValue Then
            params.Add(New SqlParameter() With {.ParameterName = "@Grade", .Value = entity.Grade})
        End If
        If StringUtil.IsNotNullOrWhiteSpace(entity.Class_Code) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Class_Code", .Value = entity.Class_Code})
        End If

        Return ExecuteDataTable(SqlQuery.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="targetKey"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetKey As DeleteTargetData) As Integer
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("DELETE").Append(" ")
        SqlQuery.Append("  FROM").Append(" ")
        SqlQuery.Append("    ").Append(DBTableConst.TABLE_NAME_TIMETABLE_CLASS).Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1=1").Append(" ")
        SqlQuery.Append("  AND Setting_Category = @Setting_Category").Append(" ")
        SqlQuery.Append("  AND Site_Code = @Site_Code").Append(" ")
        SqlQuery.Append("  AND Target_Period = @Target_Period").Append(" ")
        SqlQuery.Append("  AND Grade = @Grade").Append(" ")
        SqlQuery.Append("  AND Class_Code = @Class_Code").Append(" ")
        SqlQuery.Append(";")

        Return ExecuteNonQuery(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@Setting_Category", .Value = targetKey.Setting_Category},
            New SqlParameter() With {.ParameterName = "@Site_Code", .Value = targetKey.Site_Code},
            New SqlParameter() With {.ParameterName = "@Target_Period", .Value = targetKey.Target_Period},
            New SqlParameter() With {.ParameterName = "@Grade", .Value = targetKey.Grade},
            New SqlParameter() With {.ParameterName = "@Class_Code", .Value = targetKey.Class_Code}
        )
    End Function

End Class

Public Class DeleteTargetData
    Public Property Setting_Category As String
    Public Property Site_Code As String
    Public Property Target_Period As String
    Public Property Grade As String
    Public Property Class_Code As String
End Class
