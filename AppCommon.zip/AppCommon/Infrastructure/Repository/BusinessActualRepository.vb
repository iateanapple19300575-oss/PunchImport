﻿Imports System.Data.SqlClient

Public Class BusinessActualRepository
    Inherits TransactionBase

    Private exec As New SqlExecutor


    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 業務依頼データ作成
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function RequestActualToBusinessActual(ByVal targetDate As Date) As Integer

        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO ").Append(DBTableConst.TABLE_NAME_BUSINESS_ACTUAL).Append(" ")
        sqlString.Append("  (").Append(" ")
        sqlString.Append("    Lecture_Date").Append(" ")
        sqlString.Append("    , Site_Code").Append(" ")
        sqlString.Append("    , Subject").Append(" ")
        sqlString.Append("    , Teacher_Code").Append(" ")
        sqlString.Append("    , Business_Name").Append(" ")
        sqlString.Append("    , Target").Append(" ")
        sqlString.Append("    , Contents").Append(" ")
        sqlString.Append("    , Start_Time").Append(" ")
        sqlString.Append("    , End_Time").Append(" ")
        sqlString.Append("    , Category").Append(" ")
        sqlString.Append("    , Real_Time").Append(" ")
        sqlString.Append("  )").Append(" ")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("    BR.Lecture_Date").Append(" ")
        sqlString.Append("    , BR.Site_Code").Append(" ")
        sqlString.Append("    , BR.Subject").Append(" ")
        sqlString.Append("    , BR.Teacher_Code").Append(" ")
        sqlString.Append("    , BR.Business_Name").Append(" ")
        sqlString.Append("    , BR.Target").Append(" ")
        sqlString.Append("    , BR.Contents").Append(" ")
        sqlString.Append("    , BR.Start_Time").Append(" ")
        sqlString.Append("    , BR.End_Time").Append(" ")
        sqlString.Append("    , BR.Category").Append(" ")
        sqlString.Append("    , BR.Real_Time").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_REQUEST_ACTUAL).Append(" BR").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("    1=1").Append(" ")
        sqlString.Append("    AND BR.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("    AND BR.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("    BR.Lecture_Date").Append(" ")
        sqlString.Append("    , BR.Teacher_Code").Append(" ")
        sqlString.Append("    , BR.Start_Time").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
        New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
    )
    End Function

    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer

        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE FROM " & DBTableConst.TABLE_NAME_BUSINESS_ACTUAL & " ")
        sqlString.Append("WHERE ")
        sqlString.Append("    1 = 1 ")
        sqlString.Append("    AND Lecture_Date >= @期間開始日 ")
        sqlString.Append("    AND Lecture_Date <= @期間終了日 ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
        New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
    )
    End Function

End Class
