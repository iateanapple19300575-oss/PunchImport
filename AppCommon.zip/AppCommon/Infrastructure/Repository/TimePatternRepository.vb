﻿Imports System.Data.SqlClient

Public Class TimePatternRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="deleteMonth"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal deleteMonth As String) As Integer
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("DELETE").Append(" ")
        SqlQuery.Append("  FROM").Append(" ")
        SqlQuery.Append("    ").Append(DBTableConst.TABLE_NAME_TIME_PATTERN).Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1=1").Append(" ")
        SqlQuery.Append("  AND Lecture_Date LIKE @Lecture_Date")
        SqlQuery.Append(";")

        Return ExecuteNonQuery(SqlQuery.ToString(),
                New SqlParameter() With {.ParameterName = "@Lecture_Date", .Value = deleteMonth & "%"}
            )
    End Function

End Class
