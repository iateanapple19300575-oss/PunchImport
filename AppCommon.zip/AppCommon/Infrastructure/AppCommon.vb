﻿Imports System.Drawing
Imports System.Windows.Forms

Namespace LecturePay.Common.Infrastructure

  Public Class AppCommon

    ''' <summary>
    ''' メイン画面タイトル：アプリケーション名
    ''' </summary>
    Public Shared Function ApplicationName() As String
      Return $"" + AppState.ApplicationName + ""
    End Function

    ''' <summary>
    ''' メイン画面タイトル：年月度タイトル取得
    ''' </summary>
    Public Shared Function GetTargetYearMonth() As String
      Return $"選択年月度：" +
          IIf(Not DateUtil.IsNullOrEmpty(AppState.TargetYearMonth),
            String.Format("{0}年{1}月", AppState.TargetYearMonth.Year, AppState.TargetYearMonth.Month),
            "")
    End Function

    ''' <summary>
    ''' メイン画面タイトル：ロック状態取得
    ''' </summary>
    Public Shared Function GetLockStatus() As String
      Return $"状態：" + IIf(AppState.LockStatus, "ロック中　", "")
    End Function

    ''' <summary>
    ''' メイン画面タイトル：ロック状態取得
    ''' </summary>
    Public Shared Function GetUser() As String
      Return $"ユーザー名：" + AppState.CurrentUserName
    End Function

    ''' <summary>
    ''' 現在日付取得
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SystemDate() As Date
      Return AppState.SystemDate
    End Function

    Public Shared Sub UpdateEnvPunchingInOut(ByVal value As String)
      My.Settings.PunchingInOut = value
    End Sub

    Public Shared Sub UpdateEnvPunchingInEarly(ByVal value As String)
      My.Settings.PunchingInEarly = value
    End Sub

    Public Shared Sub UpdateEnvPunchingInLate(ByVal value As String)
      My.Settings.PunchingInLate = value
    End Sub

    Public Shared Sub UpdateEnvPunchingOutLate(ByVal value As String)
      My.Settings.PunchingOutLate = value
    End Sub

    Public Shared Sub UpdateEnvPunchingOutEarly(ByVal value As String)
      My.Settings.PunchingOutEarly = value
    End Sub

    Public Shared Function GetLectureCategory() As DataTable
      Return GetLectureCategorys()
    End Function

    Public Shared Function GetTranspExpSubject() As DataTable
      Return GetTranspExpSubjects()
    End Function

    Public Shared Function GetSystemEnvData() As SystemEnvData
      Dim env As New SystemEnvData
      env.BaseUnitPrice = 0
      env.TimeSpan = 0
      env.PunchingInOut = My.Settings.PunchingInOut
      env.PunchingInEarly = My.Settings.PunchingInEarly
      env.PunchingInLate = My.Settings.PunchingInLate
      env.PunchingOutLate = My.Settings.PunchingOutLate
      env.PunchingOutEarly = My.Settings.PunchingOutEarly
      env.LectureCategorys = GetLectureCategorys()
      Return env
    End Function

    Public Shared Function GetLectureCategorys() As DataTable
      Dim dt As New DataTable()
      dt.Columns.Add("ID", GetType(Integer))
      dt.Columns.Add("Name", GetType(String))
      Dim terms() As String = My.Settings.LectureCategorys.Split(",")
      For Each term As String In terms
        Dim items() As String = term.Split(":")
        dt.Rows.Add(Integer.Parse(items(0)), items(1))
      Next
      Return dt
    End Function

    Public Shared Function GetTranspExpSubjects() As DataTable
      Dim dt As New DataTable()
      dt.Columns.Add("ID", GetType(String))
      dt.Columns.Add("Name", GetType(String))
      Dim terms() As String = My.Settings.Transp_Exp_Subjects.Split(",")
      For Each term As String In terms
        Dim items() As String = term.Split(":")
        dt.Rows.Add(items(0), items(1))
      Next
      Return dt
    End Function

    Public Shared Function GetSiteGroups() As DataTable
      Dim dt As New DataTable()
      dt.Columns.Add("ID", GetType(String))
      dt.Columns.Add("Name", GetType(String))
      Dim terms() As String = My.Settings.Site_Group.Split(",")
      For Each term As String In terms
        Dim items() As String = term.Split(":")
        dt.Rows.Add(items(0), items(1))
      Next
      Return dt
    End Function





    Private Function AppSettingToDataTable(ByVal dataItemKey As String) As DataTable
      Dim dt As New DataTable()
      dt.Columns.Add("ID", GetType(Integer))
      dt.Columns.Add("Name", GetType(String))
      Dim terms() As String = My.Settings.Transp_Exp_Subjects.Split(",")
      For Each term As String In terms
        Dim items() As String = term.Split(":")
        dt.Rows.Add(Integer.Parse(items(0)), items(1))
      Next
      Return dt
    End Function







        Public Shared Function SetComboForHalfYear(ByRef combo As ComboBox) As DataTable
            Dim dt As DataTable = AppCommon.GetLectureCategory()
            combo.DataSource = dt
            combo.DisplayMember = "Name"
            combo.ValueMember = "ID"
            Return dt
        End Function

        ' TODO:一旦コメントアウト
#If 0 Then
        ''' <summary>
        ''' 全データの最古年を取得し、その年までを取得対象とする。
        ''' </summary>
        ''' <param name="combo"></param>
        ''' <returns></returns>
        Public Shared Function SetComboForYear(ByRef combo As ComboBox) As DataTable
      Dim dt As New DataTable()
      dt.Columns.Add("ID", GetType(Integer))
      dt.Columns.Add("Name", GetType(String))

            Dim dao As New LectureWagePercentageDao
            Dim min As Integer = dao.GetOldestDataYear()
      Dim currentYear As Integer = DateTime.Now.Year
      Dim startYear As Integer = currentYear + 1
      For i As Integer = 0 To 100
        Dim targetYear As Integer = startYear - i
        If targetYear < min Then
          Exit For
        End If
        dt.Rows.Add(targetYear, targetYear)
      Next

      'Dim newRow As DataRow
      'newRow = dt.NewRow()
      'newRow("ID") = 0
      'newRow("Name") = "(未選択)"
      'dt.Rows.InsertAt(newRow, 0)

      combo.DataSource = dt
      combo.DisplayMember = "Name"
      combo.ValueMember = "ID"
      Return dt
    End Function

#End If

    End Class
End Namespace
