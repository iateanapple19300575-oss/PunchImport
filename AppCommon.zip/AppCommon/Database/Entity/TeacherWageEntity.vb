﻿Public NotInheritable Class TeacherWageEntity
    Public ReadOnly Name As String = "W_Teacher_Wage"
    Public ReadOnly Columns As New Dictionary(Of String, ColumnInfo)()
    Public Sub New()
        Columns.Add("Teacher_Code", New ColumnInfo("Teacher_Code"))
        Columns.Add("Effective_Date", New ColumnInfo("Effective_Date"))
        Columns.Add("Lecture_Unit_Price", New ColumnInfo("Lecture_Unit_Price"))
        Columns.Add("Task_Unit_Price", New ColumnInfo("Task_Unit_Price"))
        Columns.Add("Create_Date", New ColumnInfo("Create_Date"))
        Columns.Add("Create_User", New ColumnInfo("Create_User"))
        Columns.Add("Update_Date", New ColumnInfo("Update_Date"))
        Columns.Add("Update_User", New ColumnInfo("Update_User"))
    End Sub
End Class
