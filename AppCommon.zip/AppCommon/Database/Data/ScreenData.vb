﻿Public Class ScreenData
    Inherits ResultInfoData
    Implements IData

End Class
