﻿Public Class DailyStatementParam

	''' <summary>
	''' 講師コード
	''' </summary>
	''' <returns></returns>
	Public Property TeacherCode As String

	''' <summary>
	''' 講師名
	''' </summary>
	''' <returns></returns>
	Public Property TeacherName As String

	''' <summary>
	''' 日付
	''' </summary>
	''' <returns></returns>
	Public Property LectureDate As String

	''' <summary>
	''' 講師コード
	''' </summary>
	''' <returns></returns>
	Public Property AttendanceStatus As String

	''' <summary>
	''' 出勤時間
	''' </summary>
	''' <returns></returns>
	Public Property ArrivingTime As String

	''' <summary>
	''' 退勤時間
	''' </summary>
	''' <returns></returns>
	Public Property LeavingTime As String

	''' <summary>
	''' 開始時間
	''' </summary>
	''' <returns></returns>
	Public Property StartTime As String

	''' <summary>
	''' 終了時間
	''' </summary>
	''' <returns></returns>
	Public Property FinishTime As String

	Public Property dataRow As DataRow

End Class
