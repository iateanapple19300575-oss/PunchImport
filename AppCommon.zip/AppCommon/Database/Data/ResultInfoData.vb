﻿''' <summary>
''' 処理結果情報クラス
''' </summary>
Public Class ResultInfoData
    Implements IResultInfoData

	''' <summary>
	''' 処理結果（True：正常／False：異常）
	''' </summary>
	''' <returns></returns>
	Public Property Success As Boolean = True Implements IResultInfoData.Success

  '''' <summary>
  '''' 排他エラー（True：発生／False：未発生）
  '''' </summary>
  '''' <returns></returns>
  'Public Property Exclusive As Boolean = False Implements IResultInfoData.Exclusive

  ''' <summary>
  ''' 汎用処理結果
  ''' </summary>
  ''' <returns></returns>
  Public Property SubStatus As Integer = False Implements IResultInfoData.SubStatus

	''' <summary>
	''' エラーコード
	''' </summary>
	''' <returns></returns>
	Public Property ErrorCode As Integer = 0 Implements IResultInfoData.ErrorCode

    ''' <summary>
    ''' エラーナンバー
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorNumber As Integer = 0 Implements IResultInfoData.ErrorNumber

	''' <summary>
	''' エラーナンバー
	''' </summary>
	''' <returns></returns>
	Public Property ErrorDescription As String = "" Implements IResultInfoData.ErrorDescription

	''' <summary>
	''' 例外エラー
	''' </summary>
	''' <returns></returns>
	Public Property ExceptionEx As Exception = Nothing Implements IResultInfoData.ExceptionEx

    ''' <summary>
    ''' メッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property Message As String = "" Implements IResultInfoData.Message

    ''' <summary>
    ''' 処理件数
    ''' </summary>
    ''' <returns></returns>
    Public Property DataCount As Integer = 0 Implements IResultInfoData.DataCount

    ''' <summary>
    ''' 処理日時
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessDateTime As DateTime Implements IResultInfoData.ProcessDateTime

End Class
