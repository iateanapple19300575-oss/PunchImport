﻿''' <summary>
''' 処理結果インターフェース
''' </summary>
Public Interface IResultInfoData

    ''' <summary>
    ''' 処理結果
    ''' </summary>
    ''' <returns></returns>
    Property Success As Boolean

  '''' <summary>
  '''' 排他エラー
  '''' </summary>
  '''' <returns></returns>
  'Property Exclusive As Boolean

  ''' <summary>
  ''' 汎用処理結果
  ''' </summary>
  ''' <returns></returns>
  Property SubStatus As Integer

	''' <summary>
	''' エラーコード
	''' </summary>
	''' <returns></returns>
	Property ErrorCode As Integer

    ''' <summary>
    ''' エラーナンバー
    ''' </summary>
    ''' <returns></returns>
    Property ErrorNumber As Integer

	''' <summary>
	''' エラー概要説明
	''' </summary>
	''' <returns></returns>
	Property ErrorDescription As String

	''' <summary>
	''' 例外エラー
	''' </summary>
	''' <returns></returns>
	Property ExceptionEx As Exception

    ''' <summary>
    ''' メッセージ
    ''' </summary>
    ''' <returns></returns>
    Property Message As String

    ''' <summary>
    ''' 件数
    ''' </summary>
    ''' <returns></returns>
    Property DataCount As Integer

    ''' <summary>
    ''' 処理日時
    ''' </summary>
    ''' <returns></returns>
    Property ProcessDateTime As DateTime

End Interface
