﻿Imports System.Drawing

Public Class SystemEnvData
  Implements IData

  Public Property BaseUnitPrice As Double
  Public Property TimeSpan As Integer
  Public Property LectureCategorys As DataTable

  Public Property PunchingInOut As String
  Public Property PunchingInEarly As String
  Public Property PunchingInLate As String
  Public Property PunchingOutLate As String
  Public Property PunchingOutEarly As String

  Public Function PunchingInOutColor() As Color
    Return Color.FromName(PunchingInOut)
  End Function

  Public Function PunchingInEarlyColor() As Color
    Return Color.FromName(PunchingInEarly)
  End Function

  Public Function PunchingInLateColor() As Color
    Return Color.FromName(PunchingInLate)
  End Function

  Public Function PunchingOutLateColor() As Color
    Return Color.FromName(PunchingOutLate)
  End Function

  Public Function PunchingOutEarlyColor() As Color
    Return Color.FromName(PunchingOutEarly)
  End Function
End Class
