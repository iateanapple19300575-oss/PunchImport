﻿Public Class LectureWagePercentageData
  Inherits DaoParamDataBase

  Public Property Year As String = ""
  Public Property Half_Year As String = ""
  Public Property Site_Code As String = ""
  Public Property Grade As String = ""
  Public Property Class_Code As String = ""
  Public Property Lecture_Coefficient As String = ""
  Public Property Remarks As String = ""
  Public Property Create_Date As String = ""
  Public Property Create_User As String = ""
  Public Property Update_Date As String = ""
  Public Property Update_User As String = ""
End Class
