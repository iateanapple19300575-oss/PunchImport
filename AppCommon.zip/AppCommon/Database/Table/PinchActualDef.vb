﻿Public Class PinchActualDef
  Public ReadOnly TableName As String = "W_Pinch_Actual"

  Public ReadOnly Lecture_Date As String = "Lecture_Date"
  Public ReadOnly Youbi As String = "Youbi"
  Public ReadOnly Koma_Seq As String = "Koma_Seq"
  Public ReadOnly Site_Code As String = "Site_Code"
  Public ReadOnly Class_Code As String = "Class_Code"
  Public ReadOnly Teacher_Code As String = "Teacher_Code"
  Public ReadOnly Lecture_Name As String = "Lecture_Name"
  Public ReadOnly Subject As String = "Subject"
  Public ReadOnly Number_Of_Text As String = "Number_Of_Text"
  Public ReadOnly Pinch_Type As String = "Pinch_Type"
  Public ReadOnly Input_Date As String = "Input_Date"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
