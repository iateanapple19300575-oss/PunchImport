﻿Public Class LectureWagePercentageDef
  Public ReadOnly TableName As String = "M_Lecture_Wage_Percentage"

  Public ReadOnly ID As String = "ID"
  Public ReadOnly Year As String = "Year"
  Public ReadOnly Half_Year As String = "Half_Year"
  Public ReadOnly Site_Code As String = "Site_Code"
  Public ReadOnly Grade As String = "Grade"
  Public ReadOnly Class_Code As String = "Class_Code"
  Public ReadOnly Lecture_Coefficient As String = "Lecture_Coefficient"
  Public ReadOnly Remarks As String = "Remarks"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
