﻿''' <summary>
''' 取込履歴テーブル定数
''' </summary>
Public Class TableImportHistoryConst

	''' <summary>
	''' 時間パターン
	''' </summary>
	Public Const TYPE_TIME_PATTERN As Integer = 1

	''' <summary>
	''' 教室時間割
	''' </summary>
	Public Const TYPE_TIME_TABLE_SITE As Integer = 2

	''' <summary>
	''' クラス時間割
	''' </summary>
	Public Const TYPE_TIME_TABLE_CLASS As Integer = 3

	''' <summary>
	''' 講師単価
	''' </summary>
	Public Const TYPE_TEACHER_WAGE As Integer = 4

	''' <summary>
	''' 打刻
	''' </summary>
	Public Const TYPE_T_STAMP As Integer = 101

	''' <summary>
	''' 出講データ(通常)
	''' </summary>
	Public Const TYPE_LECTURE_REGULAR As Integer = 102

	''' <summary>
	''' 出講データ(期講習)
	''' </summary>
	Public Const TYPE_LECTURE_SEASONAL As Integer = 103

	''' <summary>
	''' 代行実績
	''' </summary>
	Public Const TYPE_T_DELEGATION As Integer = 104

	''' <summary>
	''' 業務依頼(打刻あり)
	''' </summary>
	Public Const TYPE_BUSINESS_PUNCH As Integer = 105

	''' <summary>
	''' 業務依頼(打刻なし)
	''' </summary>
	Public Const TYPE_BUSINESS_NO_PUNCH As Integer = 106

	''' <summary>
	''' 取込元区分：データベーステーブル
	''' </summary>
	Public Const IMPORT_DATA_TYPE_DB_TABLE As String = "DATABASE_TABLE"

    ''' <summary>
    ''' 取込元区分：CSVファイル
    ''' </summary>
    Public Const IMPORT_DATA_TYPE_CSV_FILE As String = "CSV_FILE"



    ''' <summary>
    ''' 時間パターン
    ''' </summary>
    Public Const TYPE_TIME_PATTERN_NAME As String = "時間パターン"

    ''' <summary>
    ''' 教室時間割
    ''' </summary>
    Public Const TYPE_TIME_TABLE_NAME As String = "教室時間割マスタ"

	''' <summary>
	''' クラス時間割
	''' </summary>
	Public Const TYPE_CLASS_TIME_TABLE_NAME As String = "クラス時間割マスタ"

	''' <summary>
	''' コマ単価
	''' </summary>
	Public Const TYPE_KOMA_PRICE_TABLE_NAME As String = "コマ単価マスタ"

	''' <summary>
	''' 打刻
	''' </summary>
	Public Const TYPE_T_STAMP_NAME As String = "打刻データ"

    ''' <summary>
    ''' 出講予定
    ''' </summary>
    Public Const TYPE_T_PLAN_NAME As String = "出講予定データ"

    ''' <summary>
    ''' 業務依頼
    ''' </summary>
    Public Const TYPE_T_REQUEST_NAME As String = "業務依頼データ"

    ''' <summary>
    ''' 代行実績
    ''' </summary>
    Public Const TYPE_T_DELEGATION_NAME As String = "代行実績データ"

End Class
