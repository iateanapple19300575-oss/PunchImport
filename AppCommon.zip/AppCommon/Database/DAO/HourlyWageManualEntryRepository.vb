﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto

Public Class HourlyWageManualEntryRepository
    Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 打刻外業務給講師１日データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function LoadOneDayData(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Site_Name2").Append(" ")
        sqlString.Append("  , H.Start_Time As Start_Time").Append(" ")
        sqlString.Append("  , H.End_Time As End_Time").Append(" ")
        sqlString.Append("  , H.Contents").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  W_Hourly_Wage_Manual_Entry H").Append(" ")
        sqlString.Append("  LEFT JOIN VM_Site S").Append(" ")
        sqlString.Append("    On H.Site_Code = S.Site_Code").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1 ").Append(" ")
        sqlString.Append("  AND H.Teacher_Code = @Teacher_Code").Append(" ")
        sqlString.Append("  AND H.Lecture_Date = @Lecture_Date").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  H.Start_Time ASC").Append(" ")
        sqlString.Append(";")

        Return SqlUtil.ExecuteDataTable(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = param.TeacherCode},
        New SqlParameter() With {.ParameterName = "@Lecture_Date", .Value = param.LectureDate}
      )
    End Function
End Class
