﻿Imports System.Data.SqlClient

Public Class LectureWagePercentageDao
  Inherits TransactionBase

  Public Const KEY_ID As String = "ID"
  Public Const KEY_YEAR As String = "Year"
  Public Const KEY_HALF_YEAR As String = "Half_Year"
  Public Const KEY_SITE_CODE As String = "Site_Code"
  Public Const KEY_GRADE As String = "Grade"
  Public Const KEY_CLASS_CODE As String = "Class_Code"
  Public Const KEY_LECTURE_COEFFICIENT As String = "Lecture_Coefficient"
  Public Const KEY_REMARKS As String = "Remarks"

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 取得（条件なし）
    ''' </summary>
    ''' <returns></returns>
    Public Function GetAll(ByVal param As DaoParameter) As DataTable
    Dim LWP = Tables.LectureWagePercentage

    Dim sqlString As String =
$"SELECT
      {LWP.ID}
    , {LWP.Year}
    , {LWP.Half_Year}
    , {LWP.Site_Code}
    , {LWP.Grade}
    , {LWP.Class_Code}
    , {LWP.Lecture_Coefficient}
    , {LWP.Remarks}
  FROM
    {LWP.TableName}
  WHERE
    1=1
  ORDER BY
    {LWP.Year} ASC
    ,{LWP.Half_Year} ASC
    ,{LWP.Site_Code} ASC
    ,{LWP.Grade} ASC
    ,{LWP.Class_Code} ASC
" ' SQL String End

    Return SqlUtil.ExecuteDataTable(sqlString.ToString(), Nothing)
  End Function

  '''' <summary>
  '''' 取得（条件なし）
  '''' </summary>
  '''' <returns></returns>
  'Public Function GetDate(ByVal param As DaoParameter) As DataTable
  '  Dim LWP = Tables.LectureWagePercentage

  '  Dim sqlString As New System.Text.StringBuilder
  '  sqlString.Length = 0
  '  sqlString.Append(
  '    $"SELECT
  '          {HW.Effective_Date}
  '        , {HW.Task_Base_Unit_Price}
  '        , {HW.Deemed_Time_Before}
  '        , {HW.Deemed_Time_After}
  '      FROM
  '        {HW.TableName}
  '      WHERE
  '    "
  '  ).Append(" ")

  '  If param Is Nothing OrElse String.IsNullOrEmpty(param.Value(KEY_EFFECTIVE_DATE)) Then
  '    sqlString.Append("1=1")
  '  Else
  '    sqlString.Append(
  '    $"{HW.Effective_Date} = @{HW.Effective_Date}")
  '  End If

  '  sqlString.Append(" ")
  '  sqlString.Append(
  '    $"ORDER BY
  '        {HW.Effective_Date} ASC;
  '    "
  '  )

  '  Return SqlUtil.ExecuteDataTable(sqlString.ToString(),
  '      New SqlParameter() With {.ParameterName = $"@{HW.Effective_Date}", .Value = param.CurrentUser}
  '    )
  'End Function

  ''' <summary>
  ''' 追加
  ''' </summary>
  ''' <returns></returns>
  Public Function Add(ByVal data As LectureWagePercentageData) As Integer
    Dim LWP = Tables.LectureWagePercentage

    Dim sqlString As String =
$"INSERT INTO 
    {LWP.TableName}
  (
      {LWP.Year}
    , {LWP.Half_Year}
    , {LWP.Site_Code}
    , {LWP.Grade}
    , {LWP.Class_Code}
    , {LWP.Lecture_Coefficient}
    , {LWP.Remarks}
    , {LWP.Create_Date}
    , {LWP.Create_User}
    , {LWP.Update_Date}
    , {LWP.Update_User}
  )
  VALUES
  (
      @{LWP.Year}
    , @{LWP.Half_Year}
    , @{LWP.Site_Code}
    , @{LWP.Grade}
    , @{LWP.Class_Code}
    , @{LWP.Lecture_Coefficient}
    , @{LWP.Remarks}
    , GETDATE()
    , @{LWP.Create_User}
    , NULL
    , NULL
  )
" ' SQL String End

    Return SqlUtil.ExcuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{LWP.Year}", .Value = data.Year},
        New SqlParameter() With {.ParameterName = $"@{LWP.Half_Year}", .Value = data.Half_Year},
        New SqlParameter() With {.ParameterName = $"@{LWP.Site_Code}", .Value = data.Site_Code},
        New SqlParameter() With {.ParameterName = $"@{LWP.Grade}", .Value = data.Grade},
        New SqlParameter() With {.ParameterName = $"@{LWP.Class_Code}", .Value = data.Class_Code},
        New SqlParameter() With {.ParameterName = $"@{LWP.Lecture_Coefficient}", .Value = data.Lecture_Coefficient},
        New SqlParameter() With {.ParameterName = $"@{LWP.Remarks}", .Value = data.Remarks},
        New SqlParameter() With {.ParameterName = $"@{LWP.Create_User}", .Value = data.CurrentUser}
      )
  End Function

  '' <summary>
  '' 更新
  '' </summary>
  '' <returns></returns>
  Public Function Update(ByVal param As DaoParameter, ByVal data As LectureWagePercentageData) As Integer
    Dim LWP = Tables.LectureWagePercentage

    Dim sqlString As String =
$"UPDATE
      {LWP.TableName}
    SET
      {LWP.Site_Code}=@{LWP.Site_Code}
      , {LWP.Grade}=@{LWP.Grade}
      , {LWP.Class_Code}=@{LWP.Class_Code}
      , {LWP.Lecture_Coefficient}=@{LWP.Lecture_Coefficient}
      , {LWP.Remarks}=@{LWP.Remarks}
      , {LWP.Update_Date}=GETDATE() 
      , {LWP.Update_User}={LWP.Update_User}
    WHERE 1=1
      AND {LWP.ID}=@{LWP.ID}
  " ' SQL String End

    Return SqlUtil.ExcuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{LWP.ID}", .Value = param.ID},
        New SqlParameter() With {.ParameterName = $"@{LWP.Site_Code}", .Value = data.Site_Code},
        New SqlParameter() With {.ParameterName = $"@{LWP.Grade}", .Value = data.Grade},
        New SqlParameter() With {.ParameterName = $"@{LWP.Class_Code}", .Value = data.Class_Code},
        New SqlParameter() With {.ParameterName = $"@{LWP.Lecture_Coefficient}", .Value = data.Lecture_Coefficient},
        New SqlParameter() With {.ParameterName = $"@{LWP.Remarks}", .Value = data.Remarks},
        New SqlParameter() With {.ParameterName = $"@{LWP.Create_User}", .Value = data.CurrentUser}
      )
  End Function

  ''' <summary>
  ''' 削除
  ''' </summary>
  ''' <returns></returns>
  Public Function Delete(ByVal param As DaoParameter) As Integer
    Dim LWP = Tables.LectureWagePercentage

    Dim sqlString As String =
$"DELETE FROM
    {LWP.TableName}
  WHERE 1=1
    AND {LWP.ID}=@{LWP.ID}
" ' SQL String End

    Return SqlUtil.ExcuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{LWP.ID}", .Value = param.Value(KEY_ID)}
      )
  End Function




  ''' <summary>
  ''' 最古年取得
  ''' </summary>
  ''' <returns></returns>
  Public Function GetOldestDataYear() As Integer
    Dim LWP = Tables.LectureWagePercentage

    Dim sqlString As String =
$"SELECT
      MIN({LWP.Year}) As {LWP.Year}
  FROM
    {LWP.TableName}
  " ' SQL String End

    Return SqlUtil.ExecuteScalar(sqlString.ToString(), Nothing)
  End Function


End Class
