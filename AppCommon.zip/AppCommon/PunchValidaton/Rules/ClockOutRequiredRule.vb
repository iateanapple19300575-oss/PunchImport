﻿''' <summary>
''' 退勤時刻が入力されていない場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(1)>
Public Class ClockOutRequiredRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1020"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If (Not model.PunchEndTime.HasValue AndAlso model.PunchStartTime.HasValue) AndAlso
           (model.LectureStart.HasValue OrElse model.LectureEnd.HasValue OrElse
            model.TaskStart.HasValue OrElse model.TaskEnd.HasValue) Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.ClockOutRequiredRule,
                .IsError = True,
                .Level = ValidationLevel.ErrorLevel,
                .Message = "打刻なし(退勤)",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class