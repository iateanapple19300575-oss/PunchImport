﻿''' <summary>
''' 業務給単価(講師別)がない場合、業務給標準単価を業務給単価とする。
''' </summary>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(14)>
Public Class TaskUnitPriceRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D014"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.LectureUnitPrice.HasValue Then
            model.LectureUnitPrice = model.TaskBaseUnitPrice
        End If

        Return Nothing
    End Function

End Class
