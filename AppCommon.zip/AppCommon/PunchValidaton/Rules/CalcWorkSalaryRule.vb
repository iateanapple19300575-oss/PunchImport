﻿Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 業務給を算出する。
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(2)>
Public Class CalcWorkSalaryRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D014"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Try

            Dim tsWork As TimeSpan

            If model.DeemedHours.HasValue Then
                tsWork = model.DeemedHours
                model.WorkSalary = tsWork.Hours * model.TaskUnitPrice
            End If

            ' 授業コマ数
            model.LectureCount = KomaCount(model.LectureWorkItems)

            ' 授業給
            model.LectureFee = model.LectureCount * model.LectureUnitPrice

            ' 業務給
            If model.DeemedHours Is Nothing Then
                tsWork = TimeSpan.Zero
            Else
                tsWork = model.DeemedHours
            End If

            Dim hourValue As Decimal = Math.Round(tsWork.TotalHours, 2, MidpointRounding.AwayFromZero) * model.TaskUnitPrice
            model.WorkSalary = Math.Round(hourValue, 2, MidpointRounding.AwayFromZero)

            ' 報酬日額
            model.DailyRewards = model.WorkSalary + model.LectureFee
        Catch ex As Exception

        End Try

        Return Nothing
    End Function

    ''' <summary>
    ''' コマ件数を取得する。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Private Function KomaCount(ByVal list As List(Of LectureWorkItem)) As Integer
        Dim count As Integer = 0
        For Each item As LectureWorkItem In list
            If StringUtil.IsNotNullOrWhiteSpace(item.SiteCode) Then
                count += 1
            End If
        Next
        Return count
    End Function
End Class
