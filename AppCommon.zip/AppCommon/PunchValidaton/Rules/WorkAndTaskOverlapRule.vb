﻿''' <summary>
''' 授業時間・業務届に重複している場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(8)>
Public Class WorkAndTaskOverlapRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2010"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.OverlapLectTask.HasValue AndAlso model.OverlapLectTask > 0 Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.WorkAndTaskOverlapRule,
                .IsError = True,
                .Level = ValidationLevel.WarningLevel,
                .Message = "時間重複(授業時間・業務届)",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class
