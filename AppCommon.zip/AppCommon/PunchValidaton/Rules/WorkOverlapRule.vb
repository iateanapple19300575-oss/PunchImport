﻿''' <summary>
''' 出講時間が重複している場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(8)>
Public Class WorkOverlapRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1050"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.OverlapLecture.HasValue AndAlso model.OverlapLecture > 0 Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.WorkOverlapRule,
                .IsError = True,
                .Level = ValidationLevel.ErrorLevel,
                .Message = "時間重複(複数授業)",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class
