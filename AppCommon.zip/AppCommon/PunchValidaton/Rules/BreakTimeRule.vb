﻿''' <summary>
''' 休憩時間が発生ている場合の警告
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(6)>
Public Class BreakTimeRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D3010"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If model.PunchStartTime.HasValue AndAlso model.PunchEndTime.HasValue Then
            Dim ts As TimeSpan = model.PunchEndTime - model.PunchStartTime
            Dim minutes As Integer = 0
            If ts.TotalHours >= 8 Then
                minutes = 60
            ElseIf ts.TotalHours >= 6 Then
                minutes = 45
            Else
                Return Nothing
            End If
            model.TaskUnBreakTime = TimeSpan.FromMinutes(minutes)

            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.BreakTimeRule,
                .IsError = False,
                .Level = ValidationLevel.InformationLevel,
                .Message = "休憩発生(" & minutes.ToString() & ")分",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class
