﻿''' <summary>
''' 講師単価未登録がある場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(14)>
Public Class InstructorUnitPriceRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1060"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.LectureUnitPrice.HasValue Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.InstructorUnitPriceRule,
                .IsError = True,
                .Level = ValidationLevel.ErrorLevel,
                .Message = "講師単価未登録",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class
