﻿'''' <summary>
'''' 授業給を算出する。
'''' </summary>
'<RuleSet(ValidationRuleSet.MonthlyCheck)>
'<RulePriority(14)>
'Public Class CalcLectureFeeRule
'    Implements IValidationRule

'    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
'        Get
'            Return "D014"
'        End Get
'    End Property

'    Public Property Priority As Integer Implements IValidationRule.Priority

'    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
'        Implements IValidationRule.Validate

'        model.LectureFee = model.LectureCount * model.LectureUnitPrice

'        Return Nothing
'    End Function

'End Class
