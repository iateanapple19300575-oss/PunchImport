﻿Imports Nts.Freamwork.Common.Utilities
''' <summary>
''' 交通費未登録区間があるの場合の警告
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(10)>
Public Class TranspExpensesRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2020"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        For Each item As KomaInfoItem In model.KomaInfoItems
            If Not item.Amount.HasValue Then
                Return New ValidationRuleResult With {
                    .Priority = PunchValidatePriority.TranspExpensesRule,
                    .IsError = True,
                    .Level = ValidationLevel.WarningLevel,
                    .Message = "交通費未登録区間あり",
                    .RuleId = Me.RuleId
                }
            End If
        Next

        Return Nothing
    End Function

End Class
