﻿''' <summary>
''' 打刻回数3回以上の場合の警告
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(18)>
Public Class NumberOfPunchedRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2080"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If model.NumberOfPunched.HasValue AndAlso model.NumberOfPunched >= 3 Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.NumberOfPunchedRule,
                .IsError = True,
                .Level = ValidationLevel.WarningLevel,
                .Message = "打刻回数3回以上",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class