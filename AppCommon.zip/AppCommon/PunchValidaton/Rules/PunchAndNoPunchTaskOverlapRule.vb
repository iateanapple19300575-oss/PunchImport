﻿''' <summary>
''' 出講時間と業務届時間が重複している場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(8)>
Public Class PunchAndNoPunchTaskOverlapRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1040"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.OverlapOther.HasValue AndAlso model.OverlapOther > 0 Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.PunchAndNoPunchTaskOverlapRule,
                .IsError = True,
                .Level = ValidationLevel.ErrorLevel,
                .Message = "時間重複(ジョブカン打刻・打刻外業務給)",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class
