﻿''' <summary>
''' 授業給係数発生している場合の情報
''' </summary>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(4)>
Public Class LectureCoefficientRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D3040"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Dim result As New List(Of ValidationRuleResult)
        If model.KomaInfoItems.Count > 0 Then
            For Each item As KomaInfoItem In model.KomaInfoItems
                If Not item.LectureCoefficient.HasValue Then
                    result.Add(New ValidationRuleResult With {
                            .Priority = PunchValidatePriority.LectureCoefficientRule,
                            .IsError = True,
                            .Level = ValidationLevel.InformationLevel,
                            .Message = "授業給係数発生(" & item.LectureCoefficient & "倍)" &
                                            " " & item.Site_Code &
                                            " " & item.Grade & "年" &
                                            " " & item.Class_Code & "クラス",
                            .RuleId = Me.RuleId
                        }
                    )
                End If
            Next
        End If

        Return Nothing
    End Function

End Class
