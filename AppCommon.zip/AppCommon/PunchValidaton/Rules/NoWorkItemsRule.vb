﻿''' <summary>
''' 出講も業務届もないのに打刻している場合の警告
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(16)>
Public Class NoWorkItemsRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2070"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If (model.PunchStartTime.HasValue OrElse model.PunchEndTime.HasValue) AndAlso
           (Not model.LectureStart.HasValue AndAlso Not model.LectureEnd.HasValue AndAlso
            Not model.TaskStart.HasValue AndAlso Not model.TaskEnd.HasValue) Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.NoWorkItemsRule,
                .IsError = False,
                .Level = ValidationLevel.WarningLevel,
                .Message = "出講・業務届なし",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class
