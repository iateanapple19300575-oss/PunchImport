﻿''' <summary>
''' コマに関する情報を保持する。
''' </summary>
Public Class KomaInfoItem

    '''
    ''' 教室コード
    Public Property Site_Code As String = ""

    ''' <summary>
    ''' 学年
    ''' </summary>
    Public Property Grade As Byte

    ''' <summary>
    ''' クラスコード
    ''' </summary>
    Public Property Class_Code As String = ""

    ''' <summary>
    ''' コマ
    ''' </summary>
    Public Property Koma_Seq As String = ""

    ''' <summary>
    ''' 開始時間
    ''' </summary>
    Public Property Start_Time As TimeSpan?

    ''' <summary>
    ''' 終了時間
    ''' </summary>
    Public Property End_Time As TimeSpan?

    ''' <summary>
    ''' 実績ピンチ
    ''' </summary>
    Public Property Pinch_Type As String = ""

    ''' <summary>
    ''' 交通費
    ''' </summary>
    Public Property Amount As Decimal?

    ''' <summary>
    ''' 授業給係数。
    ''' </summary>
    Public Property LectureCoefficient As Decimal?

End Class