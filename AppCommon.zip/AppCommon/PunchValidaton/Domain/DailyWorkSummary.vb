﻿''' <summary>
''' 1 日分の労働時間集計結果
''' </summary>
Public Class DailyWorkSummary

    ''' <summary>対象日</summary>
    Public Property TargetDate As Date

    ''' <summary>勤務時間時間</summary>>
    Public Property WorkingHours As TimeSpan?

    ''' <summary>実働開始時間</summary>>
    Public Property WorkStart As TimeSpan?

    ''' <summary>実働終了時間</summary>>
    Public Property WorkEnd As TimeSpan?




    ''' <summary>総労働時間（実績 WorkItems の合計）</summary>
    Public Property TotalWorkTime As TimeSpan

    ''' <summary>休憩時間（ExtraTasks の合計）</summary>
    Public Property BreakTime As TimeSpan

    ''' <summary>残業時間（総労働時間 - 計画労働時間）</summary>
    Public Property OverTime As TimeSpan

    ''' <summary>計画労働時間（PlanItems の合計）</summary>
    Public Property PlannedWorkTime As TimeSpan

    ''' <summary>深夜残業（22:00～翌5:00）</summary>
    Public Property DeepNightTime As TimeSpan

End Class