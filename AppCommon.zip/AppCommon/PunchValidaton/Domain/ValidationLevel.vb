﻿''' <summary>
''' バリデーション結果の重要度を表すレベル。
''' エラーは処理を継続できない重大な問題、
''' 警告は処理は可能だが注意が必要な状態を示す。
''' </summary>
Public Enum ValidationLevel

    ''' <summary>
    ''' 重大なエラー。
    ''' 入力データが不正であり、処理を続行できない状態。
    ''' </summary>
    ErrorLevel = 1

    ''' <summary>
    ''' 警告レベル。
    ''' 入力データに注意が必要だが、処理は継続可能。
    ''' </summary>
    WarningLevel = 2

    ''' <summary>
    ''' 警告レベル。
    ''' 入力データに注意が必要だが、処理は継続可能。
    ''' </summary>
    InformationLevel = 3

End Enum


Public Enum RuleIdEnum

    ''' <summary>
    ''' 打刻なし(出勤)
    ''' </summary>

    ClockInRequiredRule = 1010
    ''' <summary>
    ''' 打刻なし(退勤)
    ''' </summary>

    ClockOutRequiredRule = 1020
    ''' <summary>
    ''' 時間重複(複数授業)
    ''' </summary>

    WorkOverlapRule = 1030
    ''' <summary>
    ''' 時間重複(ジョブカン打刻・打刻外業務給)
    ''' </summary>

    PunchAndNoPunchTaskOverlapRule = 1040
    ''' <summary>
    ''' 講師単価未登録
    ''' </summary>

    InstructorUnitPriceRule = 1050
    ''' <summary>
    ''' 時間重複(授業時間・業務届)
    ''' </summary>

    WorkAndTaskOverlapRule = 2010
    ''' <summary>
    ''' 打刻なし(出勤・退勤)
    ''' </summary>

    ClockInAfterClockOutRule = 2020
    ''' <summary>
    ''' 授業遅刻(20分)
    ''' </summary>

    WorkLeavingEarlyRule = 2030
    ''' <summary>
    ''' 授業早退(20分)
    ''' </summary>

    WorkBehindTimeRule = 2040
    ''' <summary>
    ''' 出勤早(20分)
    ''' </summary>

    WorkTooEarlyRule = 2050
    ''' <summary>
    ''' 退勤遅(20分)
    ''' </summary>

    WorkTooLateRule = 2060
    ''' <summary>
    ''' 出講・業務届なし
    ''' </summary>

    NoWorkItemsRule = 2070
    ''' <summary>
    ''' 打刻回数3回以上
    ''' </summary>

    NumberOfPunchedRule = 2080
    ''' <summary>
    ''' 交通費未登録区間あり(AA)
    ''' </summary>

    TranspExpensesRule = 2090
    ''' <summary>
    ''' 休憩発生(60分)
    ''' </summary>

    BreakTimeRule = 3010
    ''' <summary>
    ''' 深夜勤務発生(30分)
    ''' </summary>

    LateNightShiftRule = 3020
    ''' <summary>
    ''' 残業手当発生(1時間10分)
    ''' </summary>

    OvertimeAllowanceRule = 3030
    ''' <summary>
    ''' 授業給係数発生(1.65倍)EA6年A1クラス
    ''' </summary>

    LectureCoefficientRule = 3040

End Enum
