﻿''' <summary>
''' バリデーションルールを分類するためのルールセット。
''' 出勤時チェック、退勤時チェック、1 日締めチェックなど、
''' 実行タイミングに応じてルールをグループ化する。
''' </summary>
Public Enum ValidationRuleSet

    ''' <summary>
    ''' 日次で実行するチェック。
    ''' </summary>
    DailyCheck = 1

    ''' <summary>
    ''' 月次で実行するチェック。
    ''' </summary>
    MonthlyCheck = 2

    ''' <summary>
    ''' チェック。
    ''' </summary>
    XxxxxCheck = 3

End Enum