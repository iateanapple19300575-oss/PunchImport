﻿Imports System.Reflection
Imports System.Windows.Forms

''' <summary>
''' WinForms の内部イベント構造（EventKey と EventHandlerList.Item）にアクセスするための
''' リフレクション結果をキャッシュするユーティリティクラス。
''' </summary>
Public NotInheritable Class EventReflectionCache

	''' <summary>
	''' イベント名と EventKey(Object) のマッピングをキャッシュする辞書。
	''' EventKeyは、Controlクラス内部の"EventXxx"という非公開静的フィールドに格納されている。
	''' </summary>
	Private Shared ReadOnly _eventKeyCache As New Dictionary(Of String, Object)()

	''' <summary>
	''' EventHandlerList のインデクサ(Itemプロパティ)をキャッシュするためのPropertyInfo。
	''' </summary>
	Private Shared _eventListItemProp As PropertyInfo

	''' <summary>
	''' 指定された EventInfo に対応する EventKey を取得する。
	''' </summary>
	''' <param name="ev">対象のEventInfo</param>
	''' <returns>EventKey(Object)。存在しない場合は、Nothing。</returns>
	''' <remarks>
	''' EventKeyは、Controlクラス内部の"Event{EventName}"という非公開静的フィールドから取得される。
	''' 一度取得した EventKey はキャッシュし、次回以降で使用する。
	''' </remarks>
	Public Shared Function GetEventKey(ev As EventInfo) As Object
		Dim key As Object = Nothing

		' 既にキャッシュ済みなら即返却
		If _eventKeyCache.TryGetValue(ev.Name, key) Then
			Return key
		End If

		' Controlクラスの非公開静的フィールド"EventXxx"を取得
		Dim keyField As FieldInfo = GetType(Control).GetField("Event" & ev.Name, BindingFlags.NonPublic Or BindingFlags.Static Or BindingFlags.FlattenHierarchy)

		' 対応する EventKey が存在しない場合、Nothinを返却
		If keyField Is Nothing Then
			Return Nothing
		End If

		' EventKeyを取得
		key = keyField.GetValue(Nothing)

		' キャッシュに保存
		_eventKeyCache(ev.Name) = key

		Return key
	End Function

	''' <summary>
	''' EventHandlerListのインデクサ(Itemプロパティ)を取得する。
	''' </summary>
	''' <param name="eventList">Control.Events から取得した EventHandlerList オブジェクト</param>
	''' <returns>Item プロパティの PropertyInfo</returns>
	''' <remarks>
	''' EventHandlerList.Item(key)により、特定イベントのデリゲートを取得できる。
	''' 一度取得した PropertyInfo はキャッシュされる。
	''' </remarks>
	Public Shared Function GetEventListItemProperty(eventList As Object) As PropertyInfo

		' 既に取得済みならキャッシュを返す
		If _eventListItemProp IsNot Nothing Then
			Return _eventListItemProp
		End If

		' EventHandlerList の非公開/公開インデクサ "Item" を取得
		_eventListItemProp = eventList.GetType().GetProperty(
			"Item",
			BindingFlags.NonPublic Or BindingFlags.Public Or BindingFlags.Instance)

		Return _eventListItemProp
	End Function
End Class