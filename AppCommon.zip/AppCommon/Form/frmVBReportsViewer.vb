﻿Imports AdvanceSoftware.VBReport8

Public Class frmVBReportsViewer
    Private Sub CellReport_Error(ByVal sender As Object, ByVal e As AdvanceSoftware.VBReport8.ReportErrorEventArgs) Handles CellReport1.Error
        'CellReportでフォーマットファイルが開けないなどのエラー発生時、Exception発生せず処理が進む
        '何かあったときに調査がしづらいのでErrorイベントで捕まえてExceptionを投げる
        If TypeOf sender Is AdvanceSoftware.VBReport8.CellReport Then
            Throw New Exception("VB-Reportでエラーが発生しました。：" & CType(sender, AdvanceSoftware.VBReport8.CellReport).ErrorMessage)
        End If
    End Sub

    Private Sub ViewerControl1_Error(sender As Object, e As ReportErrorEventArgs) Handles ViewerControl1.Error
        'ViewerControl1エラー発生時、Exception発生せず処理が進む
        '何かあったときに調査がしづらいのでErrorイベントで捕まえてExceptionを投げる
        If TypeOf sender Is AdvanceSoftware.VBReport8.ViewerControl Then
            Throw New Exception("VB-Reportでエラーが発生しました。：" & CType(sender, AdvanceSoftware.VBReport8.ViewerControl).ErrorMessage)
        End If
    End Sub

    Private Sub CellReport1_RunPageStart(sender As Object, e As RunPageStartEventArgs) Handles CellReport1.RunPageStart
        CellReport1.Page.Attr.Size(AdvanceSoftware.VBReport8.PageOrientation.Landscape, System.Drawing.Printing.PaperKind.A2)

    End Sub
End Class