﻿Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Windows.Forms

Public Class BaseForm
    Inherits System.Windows.Forms.Form

    ''' <summary>
    ''' 画面名
    ''' </summary>
    ''' <returns></returns>
    Private Property WindowTitle As String = ""

    Protected _wrapper As FormEventWrapper

    ' 初期表示処理中判定フラグ
    Protected Property IsImportComplete = False

    Private Property AutoEventLog As Boolean = False

#Region "コンストラクタ"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New()
        IsImportComplete = True
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="windowTitle"></param>
    Public Sub New(ByVal windowTitle As String, Optional ByVal autoEventLog As Boolean = True)
        MyBase.New()
        Me.WindowTitle = windowTitle.Split("　"c)(0)
        Me.AutoEventLog = autoEventLog
        IsImportComplete = True
    End Sub

#End Region



#Region "イベントフック"
#If 0 Then

  ''' <summary>
  ''' メインメニューボタンイベントフック
  ''' </summary>
  ''' <param name="ctrl"></param>
  Private Sub HookMainMenuButtonEvents(ByVal ctrl As Control)
		For Each c As Control In ctrl.Controls
			If TypeOf c.ContextMenuStrip Is ContextMenuStrip Then
				Dim cms As ContextMenuStrip = CType(c.ContextMenuStrip, ContextMenuStrip)
				For Each item As ToolStripItem In cms.Items
					If TypeOf item Is ToolStripMenuItem Then
						AddHandler item.Click, AddressOf ContextMenu_Click_logger
					End If
				Next
			End If

			If c.HasChildren Then
				HookMainMenuButtonEvents(c)
			End If
		Next
	End Sub

	''' <summary>
	''' サブメニューボタンイベントフック
	''' </summary>
	''' <param name="parentItem"></param>
	Private Sub HookSubMenuButtonEvents(ByVal parentItem As ToolStripMenuItem)
		For Each subItem As ToolStripMenuItem In parentItem.DropDownItems
			If TypeOf subItem Is ToolStripMenuItem Then
				Dim menuItem As ToolStripMenuItem = CType(subItem, ToolStripMenuItem)
				AddHandler menuItem.Click, AddressOf ContextMenuItem_Click_logger
				HookSubMenuButtonEvents(subItem)
			End If
		Next
	End Sub

	''' <summary>
	''' コントロールイベントフック
	''' </summary>
	''' <param name="parent"></param>
	Private Sub HookAllControl(ByVal parent As Control)
		For Each c As Control In parent.Controls
			' Buttonクリック
			If TypeOf c Is Button Then
				Dim btn As Button = CType(c, Button)
				If Not btn.Tag Is Nothing AndAlso btn.Tag.ToString() = "NoLog" Then
					Continue For
				End If
				AddHandler CType(c, Button).Click, AddressOf Button_Handle_Click
			End If

			' ComboBox選択変更
			If TypeOf c Is ComboBox Then
				AddHandler CType(c, ComboBox).SelectedIndexChanged, AddressOf ComboBox_Handle_SelectedIndexChanged
				AddHandler CType(c, ComboBox).TextChanged, AddressOf ComboBox_Handle_TextChanged
			End If

			' TextBox入力変更
			If TypeOf c Is TextBox Then
				AddHandler CType(c, TextBox).TextChanged, AddressOf TextBox_Handle_TextChanged
			End If

			' CheckBoxクリック
			If TypeOf c Is CheckBox Then
				AddHandler CType(c, CheckBox).CheckedChanged, AddressOf CheckBox_Handle_CheckedChanged
			End If

			' RadioButtonクリック
			If TypeOf c Is RadioButton Then
				AddHandler CType(c, RadioButton).CheckedChanged, AddressOf RadioButton_Handle_CheckedChanged
			End If

			' 子階層再帰処理
			If c.HasChildren Then
				HookAllControl(c)
			End If
		Next
	End Sub
#End If

#End Region

#Region "画面表示関連：表示／終了出力"

    ''' <summary>
    ''' OnLoadイベントログ
    ''' </summary>
    ''' <param name="e"></param>
    Protected Overrides Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)

        AddHandler StateDispatcher.UiStateChanged, AddressOf OnUiStateChanged

        Dim currentX As Integer = IIf(Me.Location.X < 0, 0, Me.Location.X)
        Dim currentY As Integer = IIf(Me.Location.Y < 0, 0, Me.Location.Y)
        Me.Location = New Point(currentX, currentY)

        If TypeOf Me Is IDisableEventWrap Then
            If DirectCast(Me, IDisableEventWrap).DisableEventWrap Then
                Return
            End If
        End If

        _wrapper = New FormEventWrapper(Me)
        _wrapper.Start()

        IsImportComplete = False
    End Sub

    '''' <summary>
    '''' OnFormClosingイベントログ
    '''' </summary>
    '''' <param name="e"></param>
    'Protected Overrides Sub OnFormClosing(e As FormClosingEventArgs)
    '	LogEvent(WindowTitle, "▲画面終了(Close)", "")
    '	MyBase.OnFormClosing(e)
    'End Sub

    ''' <summary>
    ''' フォームクローズ時に購読解除（メモリリーク防止）。
    ''' </summary>
    Protected Overrides Sub OnFormClosed(e As FormClosedEventArgs)
        'LogEvent(WindowTitle, "▲画面終了(Close)", "")
        RemoveHandler StateDispatcher.UiStateChanged, AddressOf OnUiStateChanged
        MyBase.OnFormClosed(e)
    End Sub

    ''' <summary>
    ''' GlobalState の変更を UI スレッドで受け取る。
    ''' 派生フォームで UI 更新処理を実装する。
    ''' </summary>
    Public Overridable Sub OnUiStateChanged(key As String, value As Object)
        ' 派生フォームで実装
    End Sub

#End Region

#Region "画面内コントロール：操作ログ"

#If 0 Then

  ''' <summary>
  ''' [ボタンクリック]イベントログ
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Protected Sub Button_Handle_Click(sender As Object, e As EventArgs)
		If IsImportComplete Then
			Return
		End If

		Dim btn As Button = CType(sender, Button)

		If Not IsNoLogOutput(btn) Then
			LogEvent(WindowTitle, "　[" & btn.Text & "](" & btn.Name & ")" & "ボタン", "クリック")
		End If
		If IsScreenCloseEvent(btn) Then
			Me.Close()
		End If
		If Not IsScreenOpeningEvent(btn) Then
		End If

	End Sub

	''' <summary>
	''' [コンボボックス選択変更]イベントログ
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Protected Sub ComboBox_Handle_SelectedIndexChanged(sender As Object, e As EventArgs)
		Dim cmb As ComboBox = CType(sender, ComboBox)
		Dim selectedText As String = If(cmb.SelectedItem IsNot Nothing, cmb.SelectedItem.ToString(), "未選択")
		If cmb.SelectedIndex > 0 Then
			If Not IsNoLogOutput(cmb) Then
				LogEvent(WindowTitle, "・" & "[" & cmb.Name & "]" & "コンボボックス(" & cmb.Text & ")" & "選択", "")
			End If
		End If
	End Sub

	''' <summary>
	''' [コンボボックス入力変更]イベントログ
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Protected Sub ComboBox_Handle_TextChanged(sender As Object, e As EventArgs)
		Dim cmb As ComboBox = CType(sender, ComboBox)
		Dim selectedText As String = If(cmb.SelectedItem IsNot Nothing, cmb.SelectedItem.ToString(), "未選択")
		If cmb.SelectedIndex > 0 Then
			If cmb.Tag Is Nothing OrElse Not cmb.Tag Is Nothing AndAlso Not cmb.Tag.ToString().Contains("NoLog") Then
				LogEvent(WindowTitle, "・" & "[" & cmb.Name & "]" & "コンボボックス(" & cmb.Text & ")" & "選択", "")
			End If
		End If
	End Sub

	''' <summary>
	''' [テキストボックス入力変更]イベントログ
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Protected Sub TextBox_Handle_TextChanged(sender As Object, e As EventArgs)
		'Dim txt As TextBox = CType(sender, TextBox)
		'If Not IsNoLogOutput(txt) Then
		'	LogEvent(WindowTitle, "　テキストボックス(" & txt.Name & ")" & "値変更", txt.Text)
		'End If
	End Sub

	''' <summary>
	''' チェックボックスイベントログ
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Protected Sub CheckBox_Handle_CheckedChanged(sender As Object, e As EventArgs)
		Dim chk As CheckBox = CType(sender, CheckBox)
		If Not IsNoLogOutput(chk) Then
			Dim status As String = IIf(chk.Checked, "ON", "OFF")
			LogEvent(WindowTitle, "　[" & chk.Text & "] " & "チェックボックス(" & chk.Name & ")" & "選択(" & status & ")", "")
		End If
	End Sub

	''' <summary>
	''' ラジオボタンイベントログ
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub RadioButton_Handle_CheckedChanged(sender As Object, e As EventArgs)
		Dim rbt As RadioButton = CType(sender, RadioButton)
		If rbt.Checked Then
			If Not IsNoLogOutput(rbt) Then
				LogEvent(WindowTitle, "　[" & rbt.Text & "]" & "ラジオボタン押下", "")
			End If
		End If
	End Sub
#End If

#End Region

#If 1 Then

#Region "メニュー関連：操作ログ出力"


    ''' <summary>
    ''' メインメニューボタンイベントログ
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub ContextMenu_Click_logger(sender As Object, e As EventArgs)
        Dim btn As Button = CType(sender, Button)
        'LogEvent(WindowTitle, "メインメニュー：" & "[" & btn.Text & "]ボタン", "クリック")
    End Sub

    ''' <summary>
    ''' サブメニューボタンイベントログ
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub ContextMenuItem_Click_logger(sender As Object, e As EventArgs)
        Dim btn As Button = CType(sender, Button)
        'LogEvent(WindowTitle, "　サブメニュー：" & "[" & btn.Text & "]ボタン", "クリック")
    End Sub

#End Region

    ''' <summary>
    ''' 画面名取得
    ''' </summary>
    ''' <param name="title"></param>
    ''' <returns></returns>
    Private Function GetWinTitle(ByVal title As String) As String
        Return title & "画面"
    End Function

    ''' <summary>
    ''' 処理起動イベントログ
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub ProcessStartLog(sender As Object, e As EventArgs, Optional ByVal message As String = "")
        'Dim btn As Button = CType(sender, Button)
        'LogEvent(WindowTitle, "　[" & btn.Text & "](" & btn.Name & ")" & "ボタン", message)
    End Sub

    ''' <summary>
    ''' 操作詳細ログ出力
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub OperationDetailsLog(sender As Object, e As EventArgs, Optional ByVal message As String = "")
        Dim btn As Button = CType(sender, Button)
        LogEvent(WindowTitle, "　[" & btn.Text & "](" & btn.Name & ")" & "ボタン", message)
    End Sub

#Region "ログ出力処理"

    ''' <summary>
    ''' ログ保存
    ''' </summary>
    ''' <param name="winName">画面名</param>
    ''' <param name="content">操作内容</param>
    ''' <param name="detail">詳細内容</param>
    Protected Sub LogEvent(ByVal winName As String, ByVal content As String, Optional detail As String = "")
        Dim assemblyName As String = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name
        Dim exeName As String = System.IO.Path.GetFileName(System.Windows.Forms.Application.ExecutablePath)
        Dim targetDateW As Object = DBNull.Value
        If Not DateUtil.IsNullOrEmpty(AppState.TargetYearMonth) Then
            targetDateW = String.Format("{0}/{1}", AppState.TargetYearMonth.Year.ToString("0000;[0000]"), AppState.TargetYearMonth.Month.ToString("00;[00]"))
        End If

        Dim connStr As String = SqlDataBaseUtil.GetConnectionString()
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO ")
        sqlString.Append("  " & T_Operation_LogEnum.イベントID.Table).Append(" ")
        sqlString.Append("  (")
        sqlString.Append("      " & T_Operation_LogEnum.イベント発生日時.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.画面名.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.操作内容.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.操作詳細情報.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.対象年月度.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.実行ファイル名.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.実行ユーザー.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.実行PC.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.実行日.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.作成日.Column).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.作成者.Column).Append(" ")
        sqlString.Append("  ) VALUES ( ")
        sqlString.Append("      " & T_Operation_LogEnum.イベント発生日時.Param).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.画面名.Param).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.操作内容.Param).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.操作詳細情報.Param).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.対象年月度.Param).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.実行ファイル名.Param).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.実行ユーザー.Param).Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.実行PC.Param).Append(" ")
        sqlString.Append("    , GETDATE()").Append(" ")
        sqlString.Append("    , GETDATE()").Append(" ")
        sqlString.Append("    , " & T_Operation_LogEnum.作成者.Param).Append(" ")
        sqlString.Append("  )")
        sqlString.Append(";")

        SqlCommandExecutor.ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.イベント発生日時.Param, .Value = DateTime.Now},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.画面名.Param, .Value = GetWinTitle(winName)},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.操作内容.Param, .Value = content},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.操作詳細情報.Param, .Value = detail},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.対象年月度.Param, .Value = targetDateW},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行ファイル名.Param, .Value = exeName},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行ユーザー.Param, .Value = Environment.UserName},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行PC.Param, .Value = Environment.MachineName},
            New SqlParameter() With {.ParameterName = T_Operation_LogEnum.作成者.Param, .Value = Environment.UserName}
        )

    End Sub

#End Region
#End If

#Region "コントロール属性判定処理"

    ''' <summary>
    ''' コントロール属性判定（イベントログ出力無し設定）
    ''' </summary>
    ''' <param name="control"></param>
    ''' <returns>True</returns>
    Private Function IsNoLogOutput(ByVal control As Control) As Boolean
        Return Not control.Tag Is Nothing AndAlso control.Tag.ToString().Contains("NoLog")
    End Function

    ''' <summary>
    ''' コントロール属性判定（この後画面を閉じるイベント）
    ''' </summary>
    ''' <param name="control"></param>
    ''' <returns>True</returns>
    Private Function IsScreenCloseEvent(ByVal control As Control) As Boolean
        Return Not control.Tag Is Nothing AndAlso control.Tag.ToString().Contains("Close")
    End Function

    ''' <summary>
    ''' コントロール属性判定（この後画面を開くイベント）
    ''' </summary>
    ''' <param name="control"></param>
    ''' <returns>True</returns>
    Private Function IsScreenOpeningEvent(ByVal control As Control) As Boolean
        Return Not control.Tag Is Nothing AndAlso control.Tag.ToString().Contains("Open")
    End Function

#End Region

End Class
