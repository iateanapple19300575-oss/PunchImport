﻿Public Interface ITransactionBase
	Function SqlSelect() As DataTable
	Function SqlInsert() As Integer
	Function SqlUpdate() As Integer
	Function SqlDelete() As Integer
End Interface
