﻿
Imports System.Data.SqlClient

Public Class AggregationHistoryTran
    'Private logger As New Logger

    Public Function Register(ByRef data As AggregationHistoryRecData) As ResultData
		Dim result As ResultData = New ResultData()

		Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO " & " ")
        sqlString.Append("  " & TableAggregateConst.TABLE_NAME & " ")
        sqlString.Append("  (")
        sqlString.Append("      " & TableAggregateConst.COLNM_AGGREGATION_NAME & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_AGGREGATION_DATE & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_AGGREGATION_STATUS & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_TIME_STAMP_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_SCHEDULE_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_REQUEST_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_SUBSTITUTE_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_TIME_PATTERN_MASTER_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_TIMETABLE_MASTER_VERSION & " ")
		'sqlString.Append("    , " & TableAggregateConst.COLNM_PRICE_MASTER_VERSION & " ")
		sqlString.Append("    , " & TableAggregateConst.COLNM_EXECUTOR_DATE & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_CREATE_PC & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_CREATE_USER & " ")
		'sqlString.Append("    , " & TableHAggregationConst.COLNM_CREATE_DATE & " ")
		sqlString.Append("  ) " & " ")

		sqlString.Append("  OUTPUT " & " ")
        sqlString.Append("    INSERTED." & TableAggregateConst.COLNM_CREATE_DATE & " ")

        sqlString.Append("  VALUES (" & " ")
        sqlString.Append("      " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_AGGREGATION_NAME) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_AGGREGATION_DATE) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_AGGREGATION_STATUS) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_TIME_STAMP_DATA_VERSION) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_SCHEDULE_DATA_VERSION) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_REQUEST_DATA_VERSION) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_SUBSTITUTE_DATA_VERSION) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_TIME_PATTERN_MASTER_VERSION) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_TIMETABLE_MASTER_VERSION) & " ")
		'sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_PRICE_MASTER_VERSION) & " ")
		sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_EXECUTOR_DATE) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_CREATE_PC) & " ")
        sqlString.Append("    , " & TableUtil.ScalarVariable(TableAggregateConst.COLNM_CREATE_USER) & " ")
        'sqlString.Append("    , " & TableUtil.ScalarVariable(TableHAggregationConst.COLNM_CREATE_DATE) & " ")
        sqlString.Append("  )" & " ")
        sqlString.Append("; ")

        Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
            Using command As New SqlCommand(sqlString.ToString(), connection)
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_AGGREGATION_NAME), data.AggregationName)
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_AGGREGATION_DATE), SqlUtil.ExaminedValueForDateString(data.AggregationDate))
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_AGGREGATION_STATUS), data.AggregationStatus)
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_TIME_STAMP_DATA_VERSION), SqlUtil.ExaminedValueForDateString(data.TimeStampDataVersion))
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_SCHEDULE_DATA_VERSION), SqlUtil.ExaminedValueForDateString(data.ScheduleDataVersion))
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_REQUEST_DATA_VERSION), SqlUtil.ExaminedValueForDateString(data.RequestDataVersion))
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_SUBSTITUTE_DATA_VERSION), SqlUtil.ExaminedValueForDateString(data.SubstituteDataVersion))
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_TIME_PATTERN_MASTER_VERSION), SqlUtil.ExaminedValueForDateString(data.TimePatternMasterVersion))
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_TIMETABLE_MASTER_VERSION), SqlUtil.ExaminedValueForDateString(data.TimetableMasterVersion))
				command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_EXECUTOR_DATE), SqlUtil.ExaminedValueForDateString(data.ExecutorDate))
				command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_CREATE_PC), data.CREATE_PC)
                command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableAggregateConst.COLNM_CREATE_USER), data.CREATE_USER)
                'command.Parameters.AddWithValue(TableUtil.ScalarVariable(TableHAggregationConst.COLNM_CREATE_DATE), data.CREATE_DATE)
                'Logger.WriteQueryLog(Me.GetType().Name, command)

                Try
                    connection.Open()
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            Dim create_date As DateTime = reader.GetDateTime(0)
                            data.CREATE_DATE = create_date.ToString("yyyy/MM/dd HH:mm:ss.fff")
                        End While
                    End Using
                    result.Success = True
                Catch ex As Exception
                    result.Success = False
                    Throw
                Finally
                    connection.Close()

                End Try
            End Using
        End Using

        Return result
    End Function



    Public Function SelectDataAll() As ResultData
		Dim result As ResultData = New ResultData()
		Dim resultData As AggregationHistoryData = New AggregationHistoryData()
        Try
            Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                Dim sqlString As New System.Text.StringBuilder
                sqlString.Length = 0
                sqlString.Append("SELECT " & " ")
                sqlString.Append("      " & TableAggregateConst.COLNM_AGGREGATION_NAME & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_AGGREGATION_STATUS & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_AGGREGATION_DATE & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_TIME_STAMP_DATA_VERSION & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_SCHEDULE_DATA_VERSION & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_REQUEST_DATA_VERSION & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_SUBSTITUTE_DATA_VERSION & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_TIME_PATTERN_MASTER_VERSION & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_TIMETABLE_MASTER_VERSION & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_PRICE_MASTER_VERSION & " ")
                'sqlString.Append("    , " & TableHAggregationConst.COLNM_EXECUTOR_DATE & " ")
                'sqlString.Append("    , " & TableHAggregationConst.COLNM_CREATE_PC & " ")
                sqlString.Append("    , " & TableAggregateConst.COLNM_CREATE_USER & " ")
                'sqlString.Append("    , " & TableHAggregationConst.COLNM_CREATE_DATE & " ")
                sqlString.Append("FROM" & " ")
                sqlString.Append("  " & TableAggregateConst.TABLE_NAME & " ")
                sqlString.Append("WHERE " & " ")
                sqlString.Append("  1=1 " & " ")
                sqlString.Append("ORDER BY" & " ")
                sqlString.Append("  " & TableAggregateConst.COLNM_CREATE_DATE & " DESC ")
                sqlString.Append("; ")

                con.Open()

#If 0 Then
                Using cmd As New SqlCommand(sqlString.ToString(), con)
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            responseData.AGGREGATION_NAME = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_AGGREGATION_NAME))
                            responseData.AGGREGATION_DATE = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_AGGREGATION_DATE))
                            responseData.TIME_STAMP_DATA_VERSION = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_TIME_STAMP_DATA_VERSION))
                            responseData.SCHEDULE_DATA_VERSION = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_SCHEDULE_DATA_VERSION))
                            responseData.REQUEST_DATA_VERSION = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_REQUEST_DATA_VERSION))
                            responseData.SUBSTITUTE_DATA_VERSION = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_SUBSTITUTE_DATA_VERSION))
                            responseData.TIME_PATTERN_MASTER_VERSION = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_TIME_PATTERN_MASTER_VERSION))
                            responseData.TIMETABLE_MASTER_VERSION = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_PRICE_MASTER_VERSION))
                            responseData.PRICE_MASTER_VERSION = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_PRICE_MASTER_VERSION))
                            responseData.EXECUTOR_DATE = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_EXECUTOR_DATE))
                            responseData.CREATE_PC = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_CREATE_PC))
                            responseData.CREATE_USER = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_CREATE_USER))
                            responseData.CREATE_DATE = reader.GetDateTime(reader.GetOrdinal(TableHAggregationConst.COLNM_CREATE_DATE))
                        End While
                    End Using
                End Using
#End If

                Dim resultDataTable As New DataTable()
                Using command As New SqlCommand(sqlString.ToString(), con)
                    Using adapter As New SqlDataAdapter(command)
                        adapter.Fill(resultDataTable)
                    End Using
                End Using
                result.ResDataTable = resultDataTable
                con.Close()
                result.Success = True
            End Using
        Catch ex As Exception
            result.Success = False
        Finally
        End Try

        Return result
    End Function


    Public Function SelectLastData() As ResultData

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT " & " ")
        sqlString.Append("    TOP(1) " & " ")
        sqlString.Append("      " & TableAggregateConst.COLNM_AGGREGATION_NAME & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_AGGREGATION_STATUS & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_AGGREGATION_DATE & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_TIME_STAMP_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_SCHEDULE_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_REQUEST_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_SUBSTITUTE_DATA_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_TIME_PATTERN_MASTER_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_TIMETABLE_MASTER_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_PRICE_MASTER_VERSION & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_EXECUTOR_DATE & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_CREATE_PC & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_CREATE_USER & " ")
        sqlString.Append("    , " & TableAggregateConst.COLNM_CREATE_DATE & " ")
        sqlString.Append("FROM" & " ")
        sqlString.Append("  " & TableAggregateConst.TABLE_NAME & " ")
        sqlString.Append("WHERE " & " ")
        sqlString.Append("  1=1 " & " ")
        sqlString.Append("ORDER BY" & " ")
        sqlString.Append("  " & TableAggregateConst.COLNM_CREATE_DATE & " DESC ")
        sqlString.Append("; ")

        Dim result As ResultData = New ResultData()
        Dim outData As AggregationHistoryData = New AggregationHistoryData()

        Try
            Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                con.Open()
                Using cmd As New SqlCommand(sqlString.ToString(), con)
                    Dim count As Integer = 0
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            outData.AGGREGATION_NAME = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_AGGREGATION_NAME)
                            outData.AGGREGATION_STATUS = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_AGGREGATION_STATUS)
                            outData.AGGREGATION_DATE = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_AGGREGATION_DATE)
                            outData.TIME_STAMP_DATA_VERSION = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_TIME_STAMP_DATA_VERSION)
                            outData.SCHEDULE_DATA_VERSION = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_SCHEDULE_DATA_VERSION)
                            outData.REQUEST_DATA_VERSION = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_REQUEST_DATA_VERSION)
                            outData.SUBSTITUTE_DATA_VERSION = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_SUBSTITUTE_DATA_VERSION)
                            outData.TIME_PATTERN_MASTER_VERSION = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_TIME_PATTERN_MASTER_VERSION)
                            outData.TIMETABLE_MASTER_VERSION = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_PRICE_MASTER_VERSION)
                            outData.PRICE_MASTER_VERSION = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_PRICE_MASTER_VERSION)
                            outData.EXECUTOR_DATE = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_EXECUTOR_DATE)
                            outData.CREATE_PC = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_CREATE_PC)
                            outData.CREATE_USER = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_CREATE_USER)
                            outData.CREATE_DATE = SqlDataReaderUtil.GetValue(reader, TableAggregateConst.COLNM_CREATE_DATE)

                            count += 1
                        End While
                    End Using
                    result.DataCount = count
                    result.ResDataClass = outData
                End Using

                con.Close()
                result.Success = True
            End Using
        Catch ex As Exception
            result.Success = False
        Finally
        End Try

        Return result
    End Function

End Class
