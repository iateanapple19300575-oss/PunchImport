﻿''' <summary>
''' 代講データトラン
''' </summary>
Public Class AnalysisDataWithSubstituteTran
	Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    '''' <summary>
    '''' 本科実績データ作成
    '''' </summary>
    '''' <param name="targetDate"></param>
    '''' <param name="phase"></param>
    '''' <param name="dataType"></param>
    '''' <returns></returns>
    'Public Function AnalysisCreateData(ByVal targetDate As Date, ByVal phase As Integer, ByVal dataType As Integer) As Integer

    '	Dim resultData As New ResultData
    '	Dim importCount As Integer = 0
    '	Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
    '	Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

    '	Dim SqlQuery As New System.Text.StringBuilder
    '	SqlQuery.Length = 0
    '	SqlQuery.Append("INSERT INTO").Append(" ")
    '	SqlQuery.Append("  ").Append(W_Lecture_ActualEnum.フェーズ.Table).Append(" ")
    '	SqlQuery.Append("SELECT").Append(" ")
    '	SqlQuery.Append("    ").Append(phase).Append(" As ").Append(W_Lecture_ActualEnum.フェーズ.Column).Append(" ")
    '	SqlQuery.Append("  , ").Append(dataType).Append(" As ").Append(W_Lecture_ActualEnum.データ種別.Column).Append(" ")
    '	SqlQuery.Append("  , CASE WHEN PU.Teacher_Code Is Not NULL THEN PU.Teacher_Code ELSE RH.Teacher_Code END As Teacher_Code ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" As ").Append(W_Lecture_ActualEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.コマ.Column).Append(" As ").Append(W_Lecture_ActualEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.教室コード.Column).Append(" As ").Append(W_Lecture_ActualEnum.教室コード.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.学年.Column).Append(" As ").Append(W_Lecture_ActualEnum.学年.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.クラスコード.Column).Append(" As ").Append(W_Lecture_ActualEnum.クラスコード.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.科目.Column).Append(" As ").Append(W_Lecture_ActualEnum.科目.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.テキスト回.Column).Append(" As ").Append(W_Lecture_ActualEnum.テキスト回.Column).Append(" ")
    '	SqlQuery.Append("  , RS.").Append(M_Timetable_SiteEnum.開始時間.Column).Append(" As ").Append(W_Lecture_ActualEnum.開始時間.Column).Append(" ")
    '	SqlQuery.Append("  , RS.").Append(M_Timetable_SiteEnum.終了時間.Column).Append(" As ").Append(W_Lecture_ActualEnum.終了時間.Column).Append(" ")
    '	SqlQuery.Append("  , CASE WHEN").Append(" ")
    '	SqlQuery.Append("      PU.").Append(W_Pinch_ActualEnum.ピンチ区分.Column).Append(" IS NOT NULL THEN").Append(" ")
    '	SqlQuery.Append("      PU.").Append(W_Pinch_ActualEnum.ピンチ区分.Column).Append(" Else NULL END").Append(" ")
    '	SqlQuery.Append("      AS ").Append(W_Lecture_ActualEnum.ピンチ種別).Append(" ")
    '	SqlQuery.Append("FROM ")
    '	SqlQuery.Append("  ").Append(W_Lecture_PlanEnum.日付.Table).Append(" RH").Append(" ")
    '	SqlQuery.Append("  LEFT JOIN ").Append(W_Pinch_ActualEnum.日付.Table).Append(" PU").Append(" ")
    '	SqlQuery.Append("        ON (").Append(" ")
    '	SqlQuery.Append("            RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("                FORMAT(PU.").Append(W_Pinch_ActualEnum.日付.Column).Append(", 'yyyyMMdd')").Append(" ")
    '	SqlQuery.Append("            AND RH.").Append(W_Lecture_PlanEnum.教室コード.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("                PU.").Append(W_Pinch_ActualEnum.教室コード.Column).Append(" ")
    '	SqlQuery.Append("            AND CONCAT(").Append(" ")
    '	SqlQuery.Append("                  RH.").Append(W_Lecture_PlanEnum.学年.Column).Append(",").Append(" ")
    '	SqlQuery.Append("                  RH.").Append(W_Lecture_PlanEnum.クラスコード.Column).Append(") =").Append(" ")
    '	SqlQuery.Append("                PU.").Append(W_Pinch_ActualEnum.クラスコード.Column).Append(" ")
    '	SqlQuery.Append("            AND RH.").Append(W_Lecture_PlanEnum.コマ.Column).Append(" = PU.").Append(W_Pinch_ActualEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append("            AND RH.").Append(W_Lecture_PlanEnum.テキスト回.Column).Append(" = PU.").Append(W_Pinch_ActualEnum.テキスト回.Column).Append(" ")
    '	SqlQuery.Append("            AND PU.").Append(W_Pinch_ActualEnum.ピンチ区分.Column).Append(" ='U' ")
    '	SqlQuery.Append("        )  ")
    '	SqlQuery.Append("    LEFT JOIN ").Append(M_Time_PatternEnum.年度.Table).Append(" SP").Append(" ")
    '	SqlQuery.Append("        ON (").Append(" ")
    '	SqlQuery.Append("            RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("              FORMAT(SP.").Append(M_Time_PatternEnum.年月日).Append(", 'yyyyMMdd')").Append(" ")
    '	SqlQuery.Append("        )").Append(" ")
    '	SqlQuery.Append("    LEFT JOIN " & M_Timetable_SiteEnum.年.Table & " RS ")
    '	SqlQuery.Append("        ON (").Append(" ")
    '	SqlQuery.Append("            RS.").Append(M_Timetable_SiteEnum.教室コード.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("            RH.").Append(W_Lecture_PlanEnum.教室コード.Column).Append(" ")
    '	SqlQuery.Append("            AND RS.").Append(M_Timetable_SiteEnum.日程パターン名.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("                SP.").Append(M_Time_PatternEnum.日程パターン名.Column).Append(" ")
    '	SqlQuery.Append("            AND RS.").Append(M_Timetable_SiteEnum.コマ.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("                RH.").Append(W_Lecture_PlanEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append("        )").Append(" ")
    '	SqlQuery.Append("WHERE").Append(" ")
    '	SqlQuery.Append("    1= 1").Append(" ")
    '	SqlQuery.Append("  AND RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" >= " & "@日付1" & " ")
    '	SqlQuery.Append("  AND RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" <= " & "@日付2" & " ")
    '	SqlQuery.Append(" ")
    '	SqlQuery.Append("ORDER BY").Append(" ")
    '	SqlQuery.Append("      RH.").Append(W_Lecture_PlanEnum.講師コード.Column).Append(" ")
    '	SqlQuery.Append("    , RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("    , RH.").Append(W_Lecture_PlanEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append(";").Append(" ")

    '	Return ExcuteNonQuery(SqlQuery.ToString(),
    '			New SqlParameter() With {.ParameterName = "@日付1", .Value = firstDay},
    '			New SqlParameter() With {.ParameterName = "@日付2", .Value = lastDay}
    '		)
    'End Function
End Class
