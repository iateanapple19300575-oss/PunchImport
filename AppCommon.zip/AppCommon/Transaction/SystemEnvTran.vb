﻿Imports System.Data.SqlClient

''' <summary>
''' [システム環境設定データ]トランザクション
''' </summary>
Public Class SystemEnvTran
  Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' システム環境設定データを取得する。
    ''' </summary>
    ''' <returns></returns>
    Public Function SelectData() As ResultData
        Dim resultData As New ResultData
        Dim recData As New SystemEnvData
        Dim dic As New Dictionary(Of String, String)
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("SELECT ")
        sqlString.Append("    basic_unit_price ")
        sqlString.Append("    , time_span ")
        sqlString.Append("    , punching_in_out ")
        sqlString.Append("    , punching_in_earl ")
        sqlString.Append("    , punching_in_late ")
        sqlString.Append("    , punching_out_late ")
        sqlString.Append("    , punching_out_earl ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & DBTableConst.TABLE_NAME_PREFERENCES & " ")
        sqlString.Append("where ")
        sqlString.Append("    1 = 1 ")
        sqlString.Append("; ")

        Try
            Using sqlConnection As New SqlConnection(ConnectString)
                sqlConnection.Open()

                Dim count As Integer = 0
				'Dim sqlCommand As SqlCommand
				'sqlCommand = New SqlCommand(sqlString.ToString(), sqlConnection)
				'resultData.DataCount = sqlCommand.ExecuteNonQuery()
				Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
                    Using reader As SqlDataReader = commandSourceData.ExecuteReader()
                        While reader.Read()
                            recData.BaseUnitPrice = reader.GetValue(0)
                            recData.TimeSpan = reader.GetValue(1)
                            recData.PunchingInOut = reader.GetValue(2)
                            recData.PunchingInEarly = reader.GetValue(3)
                            recData.PunchingInLate = reader.GetValue(4)
                            recData.PunchingOutLate = reader.GetValue(5)
                            recData.PunchingOutEarly = reader.GetValue(6)
                            count += 1
                        End While
                    End Using
                End Using
                resultData.Success = True
                resultData.ResDataClass = recData
                resultData.DataCount = count
            End Using

        Catch ex As SqlException
            resultData.Success = False
            resultData.ErrorCode = ex.Number
            Throw

        Catch ex As Exception
            resultData.Success = False

        Finally

        End Try

        Return resultData
    End Function

    ''' <summary>
    ''' システム環境設定データを保存する。
    ''' </summary>
    ''' <param name="recData"></param>
    ''' <returns></returns>
    Public Function RegistData(ByRef recData As SystemEnvData) As ResultData
        Dim resultData As New ResultData()

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("UPDATE ")
        sqlString.Append("    " & DBTableConst.TABLE_NAME_PREFERENCES & " ")
        sqlString.Append("SET ")
        sqlString.Append("    basic_unit_price = @basic_unit_price ")
        sqlString.Append("    , time_span = @time_span ")
        sqlString.Append("    , punching_in_out = @punching_in_out ")
        sqlString.Append("    , punching_in_earl = @punching_in_earl ")
        sqlString.Append("    , punching_in_late = @punching_in_late ")
        sqlString.Append("    , punching_out_late = @punching_out_late ")
        sqlString.Append("    , punching_out_earl = @punching_out_earl ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & DBTableConst.TABLE_NAME_PREFERENCES & " ")
        sqlString.Append("; ")

        Try
            Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                con.Open()
                Using cmd As New SqlCommand(sqlString.ToString(), con)
                    cmd.Parameters.AddWithValue("@basic_unit_price", recData.BaseUnitPrice)
                    cmd.Parameters.AddWithValue("@time_span", recData.TimeSpan)
                    cmd.Parameters.AddWithValue("@punching_in_out", recData.PunchingInOut)
                    cmd.Parameters.AddWithValue("@punching_in_earl", recData.PunchingInEarly)
                    cmd.Parameters.AddWithValue("@punching_in_late", recData.PunchingInLate)
                    cmd.Parameters.AddWithValue("@punching_out_late", recData.PunchingOutLate)
                    cmd.Parameters.AddWithValue("@punching_out_earl", recData.PunchingOutEarly)
                    resultData.DataCount = cmd.ExecuteNonQuery()
                End Using

                con.Close()
                resultData.Success = True
            End Using
        Catch ex As Exception
            resultData.Success = False
        Finally
        End Try

        Return resultData
    End Function

End Class
