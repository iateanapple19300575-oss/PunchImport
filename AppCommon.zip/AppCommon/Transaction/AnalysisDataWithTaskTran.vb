﻿''' <summary>
''' 業務届(打刻あり)データトラン
''' </summary>
Public Class AnalysisDataWithTaskTran
  Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    '''' <summary>
    '''' 集計用業務データ作成
    '''' </summary>
    '''' <param name="targetDate"></param>
    '''' <param name="phase"></param>
    '''' <param name="dataType"></param>
    '''' <returns></returns>
    'Public Function AnalysisCreateData(ByVal targetDate As Date, ByVal phase As Integer, ByVal dataType As Integer) As ResultData

    '	Dim resultData As New ResultData
    '	Dim importCount As Integer = 0
    '	Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
    '	Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

    '	Dim SqlQuery As New System.Text.StringBuilder
    '	SqlQuery.Length = 0
    '	SqlQuery.Append("INSERT INTO").Append(" ")
    '	SqlQuery.Append("  ").Append(W_Lecture_ActualEnum.フェーズ.Table).Append(" ")
    '	SqlQuery.Append("SELECT ")
    '	SqlQuery.Append("    ").Append(phase).Append(" As ").Append(W_Lecture_ActualEnum.フェーズ.Column).Append(" ")
    '	SqlQuery.Append("  , ").Append(dataType).Append(" As ").Append(W_Lecture_ActualEnum.データ種別.Column).Append(" ")
    '	SqlQuery.Append("  , BR.").Append(W_Request_ActualEnum.講師コード.Column).Append(" As ").Append(W_Lecture_ActualEnum.講師コード)
    '	SqlQuery.Append("  , BR.").Append(W_Request_ActualEnum.日付.Column).Append(" As ").Append(W_Lecture_ActualEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("    , ROW_NUMBER() OVER (").Append(" ")
    '	SqlQuery.Append("        PARTITION BY").Append(" ")
    '	SqlQuery.Append("            ").Append(W_Request_ActualEnum.講師コード.Column).Append(" ")
    '	SqlQuery.Append("            , ").Append(W_Request_ActualEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("        ORDER BY").Append(" ")
    '	SqlQuery.Append("            ").Append(W_Request_ActualEnum.講師コード.Column).Append(" ")
    '	SqlQuery.Append("            , ").Append(W_Request_ActualEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("            , ").Append(W_Request_ActualEnum.開始時間.Column).Append(" ")
    '	SqlQuery.Append("    ) + 100 As ").Append(W_Lecture_ActualEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append("    , BR.").Append(W_Request_ActualEnum.教室コード.Column).Append(" As ").Append(W_Lecture_ActualEnum.教室コード.Column).Append(" ")
    '	SqlQuery.Append("    , 'X' As ").Append(W_Lecture_ActualEnum.学年.Column).Append(" ")
    '	SqlQuery.Append("    , 'XX' As ").Append(W_Lecture_ActualEnum.クラスコード.Column).Append(" ")
    '	SqlQuery.Append("    , '_' As ").Append(W_Lecture_ActualEnum.科目.Column).Append(" ")
    '	SqlQuery.Append("    , '' As ").Append(W_Lecture_ActualEnum.テキスト回.Column).Append(" ")
    '	SqlQuery.Append("    , BR.").Append(W_Request_ActualEnum.開始時間.Column).Append(" As ").Append(W_Lecture_ActualEnum.開始時間.Column).Append(" ")
    '	SqlQuery.Append("    , BR.").Append(W_Request_ActualEnum.終了時間.Column).Append(" As ").Append(W_Lecture_ActualEnum.終了時間.Column).Append(" ")
    '	SqlQuery.Append("    , NULL As ").Append(W_Lecture_ActualEnum.ピンチ種別.Column).Append(" ")
    '	SqlQuery.Append("FROM").Append(" ")
    '	SqlQuery.Append("    " & W_Request_ActualEnum.教室コード.Table & " BR ")
    '	SqlQuery.Append("WHERE").Append(" ")
    '	SqlQuery.Append("    1= 1").Append(" ")
    '	SqlQuery.Append("  AND BR.").Append(W_Request_ActualEnum.日付.Column).Append(" >= " & "@日付1" & " ")
    '	SqlQuery.Append("  AND BR.").Append(W_Request_ActualEnum.日付.Column).Append(" <= " & "@日付2" & " ")
    '	SqlQuery.Append("ORDER BY").Append(" ")
    '	SqlQuery.Append("      BR.").Append(W_Request_ActualEnum.講師コード.Column).Append(" ")
    '	SqlQuery.Append("    , BR.").Append(W_Request_ActualEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("    , BR.").Append(W_Request_ActualEnum.開始時間.Column).Append(" ")
    '	SqlQuery.Append(";")

    '	Try

    '		Using sqlConnection As New SqlConnection(ConnectString)
    '			sqlConnection.Open()

    '			'業務依頼実績データ投入
    '			Dim sqlCommand As SqlCommand
    '			sqlCommand = New SqlCommand(SqlQuery.ToString(), sqlConnection)
    '			resultData.DataCount = sqlCommand.ExecuteNonQuery()
    '		End Using

    '	Catch ex As SqlException
    '		resultData.Success = False
    '		resultData.ErrorCode = ex.Number
    '		Throw

    '	Catch ex As Exception
    '		resultData.Success = False
    '		Throw

    '	Finally

    '	End Try

    '	Return resultData
    'End Function
End Class
