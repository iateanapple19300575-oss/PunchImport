﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmExpensesExempt
	Inherits System.Windows.Forms.Form

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()>
	Private Sub InitializeComponent()
		Me.btnClose = New System.Windows.Forms.Button()
		Me.GroupBox4 = New System.Windows.Forms.GroupBox()
		Me.lblImportKomaPriceDate = New System.Windows.Forms.Label()
		Me.lblImportKomaPriceCount = New System.Windows.Forms.Label()
		Me.lblImportKomaPriceStatus = New System.Windows.Forms.Label()
		Me.GroupBox3 = New System.Windows.Forms.GroupBox()
		Me.lblImportTimeTableDate = New System.Windows.Forms.Label()
		Me.lblImportTimeTableCount = New System.Windows.Forms.Label()
		Me.lblImportTimeTableStatus = New System.Windows.Forms.Label()
		Me.CmbKomaPriceHistory = New System.Windows.Forms.ComboBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.CmbTimeTableHistory = New System.Windows.Forms.ComboBox()
		Me.lblImportTimePatternStatus = New System.Windows.Forms.Label()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.lblImportTimePatternDate = New System.Windows.Forms.Label()
		Me.lblImportTimePatternCount = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.CmbTimePatternHistory = New System.Windows.Forms.ComboBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.lblFinalKomaPriceDate = New System.Windows.Forms.Label()
		Me.btnSelectKomaPrice = New System.Windows.Forms.Button()
		Me.TxtBoxKomaPricePath = New System.Windows.Forms.TextBox()
		Me.lblFinalKomaPriceCount = New System.Windows.Forms.Label()
		Me.btnImportKomaPrice = New System.Windows.Forms.Button()
		Me.lblFinalTimeTableDate = New System.Windows.Forms.Label()
		Me.lblFinalTimePatternDate = New System.Windows.Forms.Label()
		Me.btnSelectTimePattern = New System.Windows.Forms.Button()
		Me.TxtBoxTimePatternPath = New System.Windows.Forms.TextBox()
		Me.lblFinalTimePatternCount = New System.Windows.Forms.Label()
		Me.btnImportTimePattern = New System.Windows.Forms.Button()
		Me.btnSelectTimeTable = New System.Windows.Forms.Button()
		Me.TxtBoxTimeTablePath = New System.Windows.Forms.TextBox()
		Me.lblFinalTimeTableCount = New System.Windows.Forms.Label()
		Me.btnImportTimeTable = New System.Windows.Forms.Button()
		Me.GroupBox4.SuspendLayout()
		Me.GroupBox3.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.GroupBox1.SuspendLayout()
		Me.SuspendLayout()
		'
		'btnClose
		'
		Me.btnClose.Location = New System.Drawing.Point(922, 13)
		Me.btnClose.Name = "btnClose"
		Me.btnClose.Size = New System.Drawing.Size(81, 27)
		Me.btnClose.TabIndex = 3
		Me.btnClose.Text = "閉じる(F12)"
		Me.btnClose.UseVisualStyleBackColor = True
		'
		'GroupBox4
		'
		Me.GroupBox4.Controls.Add(Me.lblImportKomaPriceDate)
		Me.GroupBox4.Controls.Add(Me.lblImportKomaPriceCount)
		Me.GroupBox4.Controls.Add(Me.lblImportKomaPriceStatus)
		Me.GroupBox4.Location = New System.Drawing.Point(600, 320)
		Me.GroupBox4.Name = "GroupBox4"
		Me.GroupBox4.Size = New System.Drawing.Size(351, 108)
		Me.GroupBox4.TabIndex = 43
		Me.GroupBox4.TabStop = False
		Me.GroupBox4.Text = "取込実行結果"
		'
		'lblImportKomaPriceDate
		'
		Me.lblImportKomaPriceDate.AutoSize = True
		Me.lblImportKomaPriceDate.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblImportKomaPriceDate.ForeColor = System.Drawing.Color.Black
		Me.lblImportKomaPriceDate.Location = New System.Drawing.Point(19, 54)
		Me.lblImportKomaPriceDate.Name = "lblImportKomaPriceDate"
		Me.lblImportKomaPriceDate.Size = New System.Drawing.Size(68, 16)
		Me.lblImportKomaPriceDate.TabIndex = 33
		Me.lblImportKomaPriceDate.Text = "今回日時："
		'
		'lblImportKomaPriceCount
		'
		Me.lblImportKomaPriceCount.AutoSize = True
		Me.lblImportKomaPriceCount.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblImportKomaPriceCount.ForeColor = System.Drawing.Color.Black
		Me.lblImportKomaPriceCount.Location = New System.Drawing.Point(19, 78)
		Me.lblImportKomaPriceCount.Name = "lblImportKomaPriceCount"
		Me.lblImportKomaPriceCount.Size = New System.Drawing.Size(68, 16)
		Me.lblImportKomaPriceCount.TabIndex = 32
		Me.lblImportKomaPriceCount.Text = "今回件数："
		'
		'lblImportKomaPriceStatus
		'
		Me.lblImportKomaPriceStatus.AutoSize = True
		Me.lblImportKomaPriceStatus.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblImportKomaPriceStatus.ForeColor = System.Drawing.Color.Black
		Me.lblImportKomaPriceStatus.Location = New System.Drawing.Point(19, 30)
		Me.lblImportKomaPriceStatus.Name = "lblImportKomaPriceStatus"
		Me.lblImportKomaPriceStatus.Size = New System.Drawing.Size(68, 16)
		Me.lblImportKomaPriceStatus.TabIndex = 38
		Me.lblImportKomaPriceStatus.Text = "処理結果："
		'
		'GroupBox3
		'
		Me.GroupBox3.Controls.Add(Me.lblImportTimeTableDate)
		Me.GroupBox3.Controls.Add(Me.lblImportTimeTableCount)
		Me.GroupBox3.Controls.Add(Me.lblImportTimeTableStatus)
		Me.GroupBox3.Location = New System.Drawing.Point(600, 180)
		Me.GroupBox3.Name = "GroupBox3"
		Me.GroupBox3.Size = New System.Drawing.Size(351, 108)
		Me.GroupBox3.TabIndex = 42
		Me.GroupBox3.TabStop = False
		Me.GroupBox3.Text = "取込実行結果"
		'
		'lblImportTimeTableDate
		'
		Me.lblImportTimeTableDate.AutoSize = True
		Me.lblImportTimeTableDate.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblImportTimeTableDate.ForeColor = System.Drawing.Color.Black
		Me.lblImportTimeTableDate.Location = New System.Drawing.Point(19, 54)
		Me.lblImportTimeTableDate.Name = "lblImportTimeTableDate"
		Me.lblImportTimeTableDate.Size = New System.Drawing.Size(68, 16)
		Me.lblImportTimeTableDate.TabIndex = 33
		Me.lblImportTimeTableDate.Text = "今回日時："
		'
		'lblImportTimeTableCount
		'
		Me.lblImportTimeTableCount.AutoSize = True
		Me.lblImportTimeTableCount.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblImportTimeTableCount.ForeColor = System.Drawing.Color.Black
		Me.lblImportTimeTableCount.Location = New System.Drawing.Point(19, 78)
		Me.lblImportTimeTableCount.Name = "lblImportTimeTableCount"
		Me.lblImportTimeTableCount.Size = New System.Drawing.Size(68, 16)
		Me.lblImportTimeTableCount.TabIndex = 32
		Me.lblImportTimeTableCount.Text = "今回件数："
		'
		'lblImportTimeTableStatus
		'
		Me.lblImportTimeTableStatus.AutoSize = True
		Me.lblImportTimeTableStatus.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblImportTimeTableStatus.ForeColor = System.Drawing.Color.Black
		Me.lblImportTimeTableStatus.Location = New System.Drawing.Point(19, 30)
		Me.lblImportTimeTableStatus.Name = "lblImportTimeTableStatus"
		Me.lblImportTimeTableStatus.Size = New System.Drawing.Size(68, 16)
		Me.lblImportTimeTableStatus.TabIndex = 37
		Me.lblImportTimeTableStatus.Text = "処理結果："
		'
		'CmbKomaPriceHistory
		'
		Me.CmbKomaPriceHistory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbKomaPriceHistory.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.CmbKomaPriceHistory.FormattingEnabled = True
		Me.CmbKomaPriceHistory.Location = New System.Drawing.Point(198, 394)
		Me.CmbKomaPriceHistory.Name = "CmbKomaPriceHistory"
		Me.CmbKomaPriceHistory.Size = New System.Drawing.Size(274, 24)
		Me.CmbKomaPriceHistory.TabIndex = 18
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.Label3.ForeColor = System.Drawing.Color.Black
		Me.Label3.Location = New System.Drawing.Point(112, 394)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(68, 16)
		Me.Label3.TabIndex = 20
		Me.Label3.Text = "取込履歴："
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'CmbTimeTableHistory
		'
		Me.CmbTimeTableHistory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbTimeTableHistory.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.CmbTimeTableHistory.FormattingEnabled = True
		Me.CmbTimeTableHistory.Location = New System.Drawing.Point(198, 250)
		Me.CmbTimeTableHistory.Name = "CmbTimeTableHistory"
		Me.CmbTimeTableHistory.Size = New System.Drawing.Size(274, 24)
		Me.CmbTimeTableHistory.TabIndex = 12
		'
		'lblImportTimePatternStatus
		'
		Me.lblImportTimePatternStatus.AutoSize = True
		Me.lblImportTimePatternStatus.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblImportTimePatternStatus.ForeColor = System.Drawing.Color.Black
		Me.lblImportTimePatternStatus.Location = New System.Drawing.Point(19, 30)
		Me.lblImportTimePatternStatus.Name = "lblImportTimePatternStatus"
		Me.lblImportTimePatternStatus.Size = New System.Drawing.Size(68, 16)
		Me.lblImportTimePatternStatus.TabIndex = 36
		Me.lblImportTimePatternStatus.Text = "処理結果："
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.Add(Me.lblImportTimePatternDate)
		Me.GroupBox2.Controls.Add(Me.lblImportTimePatternCount)
		Me.GroupBox2.Controls.Add(Me.lblImportTimePatternStatus)
		Me.GroupBox2.Location = New System.Drawing.Point(600, 40)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(351, 108)
		Me.GroupBox2.TabIndex = 41
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "取込実行結果"
		'
		'lblImportTimePatternDate
		'
		Me.lblImportTimePatternDate.AutoSize = True
		Me.lblImportTimePatternDate.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblImportTimePatternDate.ForeColor = System.Drawing.Color.Black
		Me.lblImportTimePatternDate.Location = New System.Drawing.Point(19, 54)
		Me.lblImportTimePatternDate.Name = "lblImportTimePatternDate"
		Me.lblImportTimePatternDate.Size = New System.Drawing.Size(68, 16)
		Me.lblImportTimePatternDate.TabIndex = 33
		Me.lblImportTimePatternDate.Text = "今回日時："
		'
		'lblImportTimePatternCount
		'
		Me.lblImportTimePatternCount.AutoSize = True
		Me.lblImportTimePatternCount.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblImportTimePatternCount.ForeColor = System.Drawing.Color.Black
		Me.lblImportTimePatternCount.Location = New System.Drawing.Point(19, 78)
		Me.lblImportTimePatternCount.Name = "lblImportTimePatternCount"
		Me.lblImportTimePatternCount.Size = New System.Drawing.Size(68, 16)
		Me.lblImportTimePatternCount.TabIndex = 32
		Me.lblImportTimePatternCount.Text = "今回件数："
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.Label2.ForeColor = System.Drawing.Color.Black
		Me.Label2.Location = New System.Drawing.Point(112, 254)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(68, 16)
		Me.Label2.TabIndex = 19
		Me.Label2.Text = "取込履歴："
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.Add(Me.GroupBox4)
		Me.GroupBox1.Controls.Add(Me.GroupBox3)
		Me.GroupBox1.Controls.Add(Me.GroupBox2)
		Me.GroupBox1.Controls.Add(Me.CmbKomaPriceHistory)
		Me.GroupBox1.Controls.Add(Me.Label3)
		Me.GroupBox1.Controls.Add(Me.CmbTimeTableHistory)
		Me.GroupBox1.Controls.Add(Me.Label2)
		Me.GroupBox1.Controls.Add(Me.CmbTimePatternHistory)
		Me.GroupBox1.Controls.Add(Me.Label1)
		Me.GroupBox1.Controls.Add(Me.lblFinalKomaPriceDate)
		Me.GroupBox1.Controls.Add(Me.btnSelectKomaPrice)
		Me.GroupBox1.Controls.Add(Me.TxtBoxKomaPricePath)
		Me.GroupBox1.Controls.Add(Me.lblFinalKomaPriceCount)
		Me.GroupBox1.Controls.Add(Me.btnImportKomaPrice)
		Me.GroupBox1.Controls.Add(Me.lblFinalTimeTableDate)
		Me.GroupBox1.Controls.Add(Me.lblFinalTimePatternDate)
		Me.GroupBox1.Controls.Add(Me.btnSelectTimePattern)
		Me.GroupBox1.Controls.Add(Me.TxtBoxTimePatternPath)
		Me.GroupBox1.Controls.Add(Me.lblFinalTimePatternCount)
		Me.GroupBox1.Controls.Add(Me.btnImportTimePattern)
		Me.GroupBox1.Controls.Add(Me.btnSelectTimeTable)
		Me.GroupBox1.Controls.Add(Me.TxtBoxTimeTablePath)
		Me.GroupBox1.Controls.Add(Me.lblFinalTimeTableCount)
		Me.GroupBox1.Controls.Add(Me.btnImportTimeTable)
		Me.GroupBox1.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.GroupBox1.Location = New System.Drawing.Point(22, 51)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(980, 487)
		Me.GroupBox1.TabIndex = 2
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "経費関連（非課税）"
		'
		'CmbTimePatternHistory
		'
		Me.CmbTimePatternHistory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbTimePatternHistory.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.CmbTimePatternHistory.FormattingEnabled = True
		Me.CmbTimePatternHistory.Location = New System.Drawing.Point(198, 110)
		Me.CmbTimePatternHistory.Name = "CmbTimePatternHistory"
		Me.CmbTimePatternHistory.Size = New System.Drawing.Size(274, 24)
		Me.CmbTimePatternHistory.TabIndex = 6
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.Label1.ForeColor = System.Drawing.Color.Black
		Me.Label1.Location = New System.Drawing.Point(112, 114)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(68, 16)
		Me.Label1.TabIndex = 5
		Me.Label1.Text = "取込履歴："
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'lblFinalKomaPriceDate
		'
		Me.lblFinalKomaPriceDate.AutoSize = True
		Me.lblFinalKomaPriceDate.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblFinalKomaPriceDate.ForeColor = System.Drawing.Color.Black
		Me.lblFinalKomaPriceDate.Location = New System.Drawing.Point(112, 360)
		Me.lblFinalKomaPriceDate.Name = "lblFinalKomaPriceDate"
		Me.lblFinalKomaPriceDate.Size = New System.Drawing.Size(92, 16)
		Me.lblFinalKomaPriceDate.TabIndex = 17
		Me.lblFinalKomaPriceDate.Text = "最終取込日時："
		'
		'btnSelectKomaPrice
		'
		Me.btnSelectKomaPrice.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnSelectKomaPrice.Enabled = False
		Me.btnSelectKomaPrice.Location = New System.Drawing.Point(22, 320)
		Me.btnSelectKomaPrice.Name = "btnSelectKomaPrice"
		Me.btnSelectKomaPrice.Size = New System.Drawing.Size(90, 27)
		Me.btnSelectKomaPrice.TabIndex = 13
		Me.btnSelectKomaPrice.Text = "○△控除"
		Me.btnSelectKomaPrice.UseVisualStyleBackColor = True
		'
		'TxtBoxKomaPricePath
		'
		Me.TxtBoxKomaPricePath.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.TxtBoxKomaPricePath.Location = New System.Drawing.Point(112, 320)
		Me.TxtBoxKomaPricePath.Name = "TxtBoxKomaPricePath"
		Me.TxtBoxKomaPricePath.ReadOnly = True
		Me.TxtBoxKomaPricePath.Size = New System.Drawing.Size(360, 27)
		Me.TxtBoxKomaPricePath.TabIndex = 14
		'
		'lblFinalKomaPriceCount
		'
		Me.lblFinalKomaPriceCount.AutoSize = True
		Me.lblFinalKomaPriceCount.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblFinalKomaPriceCount.ForeColor = System.Drawing.Color.Black
		Me.lblFinalKomaPriceCount.Location = New System.Drawing.Point(337, 360)
		Me.lblFinalKomaPriceCount.Name = "lblFinalKomaPriceCount"
		Me.lblFinalKomaPriceCount.Size = New System.Drawing.Size(68, 16)
		Me.lblFinalKomaPriceCount.TabIndex = 16
		Me.lblFinalKomaPriceCount.Text = "前回件数："
		'
		'btnImportKomaPrice
		'
		Me.btnImportKomaPrice.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnImportKomaPrice.Enabled = False
		Me.btnImportKomaPrice.Location = New System.Drawing.Point(480, 320)
		Me.btnImportKomaPrice.Name = "btnImportKomaPrice"
		Me.btnImportKomaPrice.Size = New System.Drawing.Size(70, 27)
		Me.btnImportKomaPrice.TabIndex = 15
		Me.btnImportKomaPrice.Text = "取込"
		Me.btnImportKomaPrice.UseVisualStyleBackColor = True
		'
		'lblFinalTimeTableDate
		'
		Me.lblFinalTimeTableDate.AutoSize = True
		Me.lblFinalTimeTableDate.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblFinalTimeTableDate.ForeColor = System.Drawing.Color.Black
		Me.lblFinalTimeTableDate.Location = New System.Drawing.Point(112, 220)
		Me.lblFinalTimeTableDate.Name = "lblFinalTimeTableDate"
		Me.lblFinalTimeTableDate.Size = New System.Drawing.Size(68, 16)
		Me.lblFinalTimeTableDate.TabIndex = 11
		Me.lblFinalTimeTableDate.Text = "前回日時："
		'
		'lblFinalTimePatternDate
		'
		Me.lblFinalTimePatternDate.AutoSize = True
		Me.lblFinalTimePatternDate.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblFinalTimePatternDate.ForeColor = System.Drawing.Color.Black
		Me.lblFinalTimePatternDate.Location = New System.Drawing.Point(112, 80)
		Me.lblFinalTimePatternDate.Name = "lblFinalTimePatternDate"
		Me.lblFinalTimePatternDate.Size = New System.Drawing.Size(68, 16)
		Me.lblFinalTimePatternDate.TabIndex = 4
		Me.lblFinalTimePatternDate.Text = "前回日時："
		Me.lblFinalTimePatternDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'btnSelectTimePattern
		'
		Me.btnSelectTimePattern.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnSelectTimePattern.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.btnSelectTimePattern.Location = New System.Drawing.Point(22, 40)
		Me.btnSelectTimePattern.Name = "btnSelectTimePattern"
		Me.btnSelectTimePattern.Size = New System.Drawing.Size(90, 27)
		Me.btnSelectTimePattern.TabIndex = 0
		Me.btnSelectTimePattern.Text = "○○手当"
		Me.btnSelectTimePattern.UseVisualStyleBackColor = True
		'
		'TxtBoxTimePatternPath
		'
		Me.TxtBoxTimePatternPath.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.TxtBoxTimePatternPath.Location = New System.Drawing.Point(112, 40)
		Me.TxtBoxTimePatternPath.Name = "TxtBoxTimePatternPath"
		Me.TxtBoxTimePatternPath.ReadOnly = True
		Me.TxtBoxTimePatternPath.Size = New System.Drawing.Size(360, 27)
		Me.TxtBoxTimePatternPath.TabIndex = 1
		'
		'lblFinalTimePatternCount
		'
		Me.lblFinalTimePatternCount.AutoSize = True
		Me.lblFinalTimePatternCount.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.lblFinalTimePatternCount.ForeColor = System.Drawing.Color.Black
		Me.lblFinalTimePatternCount.Location = New System.Drawing.Point(337, 80)
		Me.lblFinalTimePatternCount.Name = "lblFinalTimePatternCount"
		Me.lblFinalTimePatternCount.Size = New System.Drawing.Size(68, 16)
		Me.lblFinalTimePatternCount.TabIndex = 3
		Me.lblFinalTimePatternCount.Text = "前回件数："
		Me.lblFinalTimePatternCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'btnImportTimePattern
		'
		Me.btnImportTimePattern.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnImportTimePattern.Enabled = False
		Me.btnImportTimePattern.Location = New System.Drawing.Point(480, 40)
		Me.btnImportTimePattern.Name = "btnImportTimePattern"
		Me.btnImportTimePattern.Size = New System.Drawing.Size(70, 27)
		Me.btnImportTimePattern.TabIndex = 2
		Me.btnImportTimePattern.Text = "取込"
		Me.btnImportTimePattern.UseVisualStyleBackColor = True
		'
		'btnSelectTimeTable
		'
		Me.btnSelectTimeTable.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnSelectTimeTable.Location = New System.Drawing.Point(22, 180)
		Me.btnSelectTimeTable.Name = "btnSelectTimeTable"
		Me.btnSelectTimeTable.Size = New System.Drawing.Size(90, 27)
		Me.btnSelectTimeTable.TabIndex = 7
		Me.btnSelectTimeTable.Text = "△△手当"
		Me.btnSelectTimeTable.UseVisualStyleBackColor = True
		'
		'TxtBoxTimeTablePath
		'
		Me.TxtBoxTimeTablePath.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.TxtBoxTimeTablePath.Location = New System.Drawing.Point(112, 180)
		Me.TxtBoxTimeTablePath.Name = "TxtBoxTimeTablePath"
		Me.TxtBoxTimeTablePath.ReadOnly = True
		Me.TxtBoxTimeTablePath.Size = New System.Drawing.Size(360, 27)
		Me.TxtBoxTimeTablePath.TabIndex = 8
		'
		'lblFinalTimeTableCount
		'
		Me.lblFinalTimeTableCount.AutoSize = True
		Me.lblFinalTimeTableCount.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		Me.lblFinalTimeTableCount.ForeColor = System.Drawing.Color.Black
		Me.lblFinalTimeTableCount.Location = New System.Drawing.Point(337, 220)
		Me.lblFinalTimeTableCount.Name = "lblFinalTimeTableCount"
		Me.lblFinalTimeTableCount.Size = New System.Drawing.Size(68, 16)
		Me.lblFinalTimeTableCount.TabIndex = 10
		Me.lblFinalTimeTableCount.Text = "前回件数："
		'
		'btnImportTimeTable
		'
		Me.btnImportTimeTable.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnImportTimeTable.Enabled = False
		Me.btnImportTimeTable.Location = New System.Drawing.Point(480, 180)
		Me.btnImportTimeTable.Name = "btnImportTimeTable"
		Me.btnImportTimeTable.Size = New System.Drawing.Size(70, 27)
		Me.btnImportTimeTable.TabIndex = 9
		Me.btnImportTimeTable.Text = "取込"
		Me.btnImportTimeTable.UseVisualStyleBackColor = True
		'
		'frmExpensesExempt
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1024, 551)
		Me.Controls.Add(Me.btnClose)
		Me.Controls.Add(Me.GroupBox1)
		Me.Name = "frmExpensesExempt"
		Me.Text = "非課税経費データ取込"
		Me.GroupBox4.ResumeLayout(False)
		Me.GroupBox4.PerformLayout()
		Me.GroupBox3.ResumeLayout(False)
		Me.GroupBox3.PerformLayout()
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox2.PerformLayout()
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox1.PerformLayout()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents btnClose As Button
	Friend WithEvents GroupBox4 As GroupBox
	Friend WithEvents lblImportKomaPriceDate As Label
	Friend WithEvents lblImportKomaPriceCount As Label
	Friend WithEvents lblImportKomaPriceStatus As Label
	Friend WithEvents GroupBox3 As GroupBox
	Friend WithEvents lblImportTimeTableDate As Label
	Friend WithEvents lblImportTimeTableCount As Label
	Friend WithEvents lblImportTimeTableStatus As Label
	Friend WithEvents CmbKomaPriceHistory As ComboBox
	Friend WithEvents Label3 As Label
	Friend WithEvents CmbTimeTableHistory As ComboBox
	Friend WithEvents lblImportTimePatternStatus As Label
	Friend WithEvents GroupBox2 As GroupBox
	Friend WithEvents lblImportTimePatternDate As Label
	Friend WithEvents lblImportTimePatternCount As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents GroupBox1 As GroupBox
	Friend WithEvents lblFinalKomaPriceDate As Label
	Friend WithEvents btnSelectKomaPrice As Button
	Friend WithEvents TxtBoxKomaPricePath As TextBox
	Friend WithEvents lblFinalKomaPriceCount As Label
	Friend WithEvents btnImportKomaPrice As Button
	Friend WithEvents lblFinalTimeTableDate As Label
	Friend WithEvents lblFinalTimePatternDate As Label
	Friend WithEvents btnSelectTimePattern As Button
	Friend WithEvents TxtBoxTimePatternPath As TextBox
	Friend WithEvents lblFinalTimePatternCount As Label
	Friend WithEvents btnImportTimePattern As Button
	Friend WithEvents btnSelectTimeTable As Button
	Friend WithEvents TxtBoxTimeTablePath As TextBox
	Friend WithEvents lblFinalTimeTableCount As Label
	Friend WithEvents btnImportTimeTable As Button
	Friend WithEvents CmbTimePatternHistory As ComboBox
	Friend WithEvents Label1 As Label
End Class
