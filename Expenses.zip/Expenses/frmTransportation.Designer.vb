﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTransportation
	Inherits System.Windows.Forms.Form

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.btnClose = New System.Windows.Forms.Button()
		Me.GroupBox5 = New System.Windows.Forms.GroupBox()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.TextBox1 = New System.Windows.Forms.TextBox()
		Me.TextBox2 = New System.Windows.Forms.TextBox()
		Me.TextBox3 = New System.Windows.Forms.TextBox()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.GroupBox5.SuspendLayout()
		Me.SuspendLayout()
		'
		'btnClose
		'
		Me.btnClose.Location = New System.Drawing.Point(922, 13)
		Me.btnClose.Name = "btnClose"
		Me.btnClose.Size = New System.Drawing.Size(81, 27)
		Me.btnClose.TabIndex = 5
		Me.btnClose.Text = "閉じる(F12)"
		Me.btnClose.UseVisualStyleBackColor = True
		'
		'GroupBox5
		'
		Me.GroupBox5.Controls.Add(Me.Button1)
		Me.GroupBox5.Controls.Add(Me.TextBox3)
		Me.GroupBox5.Controls.Add(Me.TextBox2)
		Me.GroupBox5.Controls.Add(Me.TextBox1)
		Me.GroupBox5.Controls.Add(Me.Label6)
		Me.GroupBox5.Controls.Add(Me.Label5)
		Me.GroupBox5.Controls.Add(Me.Label4)
		Me.GroupBox5.Location = New System.Drawing.Point(20, 40)
		Me.GroupBox5.Name = "GroupBox5"
		Me.GroupBox5.Size = New System.Drawing.Size(382, 113)
		Me.GroupBox5.TabIndex = 6
		Me.GroupBox5.TabStop = False
		Me.GroupBox5.Text = "講師検索"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Location = New System.Drawing.Point(18, 27)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(56, 12)
		Me.Label4.TabIndex = 0
		Me.Label4.Text = "講師コード"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Location = New System.Drawing.Point(21, 52)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(53, 12)
		Me.Label5.TabIndex = 1
		Me.Label5.Text = "講師（姓）"
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Location = New System.Drawing.Point(21, 77)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(53, 12)
		Me.Label6.TabIndex = 2
		Me.Label6.Text = "講師（名）"
		'
		'TextBox1
		'
		Me.TextBox1.Location = New System.Drawing.Point(80, 24)
		Me.TextBox1.Name = "TextBox1"
		Me.TextBox1.Size = New System.Drawing.Size(40, 19)
		Me.TextBox1.TabIndex = 3
		Me.TextBox1.Text = "W999"
		'
		'TextBox2
		'
		Me.TextBox2.Location = New System.Drawing.Point(80, 49)
		Me.TextBox2.Name = "TextBox2"
		Me.TextBox2.Size = New System.Drawing.Size(100, 19)
		Me.TextBox2.TabIndex = 4
		Me.TextBox2.Text = "あああああ"
		'
		'TextBox3
		'
		Me.TextBox3.Location = New System.Drawing.Point(80, 74)
		Me.TextBox3.Name = "TextBox3"
		Me.TextBox3.Size = New System.Drawing.Size(100, 19)
		Me.TextBox3.TabIndex = 5
		Me.TextBox3.Text = "W999"
		'
		'GroupBox1
		'
		Me.GroupBox1.Location = New System.Drawing.Point(20, 170)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(180, 576)
		Me.GroupBox1.TabIndex = 7
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "講師"
		'
		'GroupBox2
		'
		Me.GroupBox2.Location = New System.Drawing.Point(222, 170)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(180, 576)
		Me.GroupBox2.TabIndex = 8
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "教室"
		'
		'Button1
		'
		Me.Button1.Location = New System.Drawing.Point(268, 71)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(85, 24)
		Me.Button1.TabIndex = 6
		Me.Button1.Text = "検索"
		Me.Button1.UseVisualStyleBackColor = True
		'
		'frmTransportation
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1335, 791)
		Me.Controls.Add(Me.GroupBox2)
		Me.Controls.Add(Me.GroupBox1)
		Me.Controls.Add(Me.GroupBox5)
		Me.Controls.Add(Me.btnClose)
		Me.Name = "frmTransportation"
		Me.Text = "交通費"
		Me.GroupBox5.ResumeLayout(False)
		Me.GroupBox5.PerformLayout()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents btnClose As Button
	Friend WithEvents GroupBox5 As GroupBox
	Friend WithEvents Button1 As Button
	Friend WithEvents TextBox3 As TextBox
	Friend WithEvents TextBox2 As TextBox
	Friend WithEvents TextBox1 As TextBox
	Friend WithEvents Label6 As Label
	Friend WithEvents Label5 As Label
	Friend WithEvents Label4 As Label
	Friend WithEvents GroupBox1 As GroupBox
	Friend WithEvents GroupBox2 As GroupBox
End Class
