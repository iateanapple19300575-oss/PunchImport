﻿Public Class AttendanceStatementWinData
  Inherits ResultData

  ''' <summary>
  ''' 勤怠明細DataTable
  ''' </summary>
  ''' <returns></returns>
  Public Property AttendanceDataTable As DataTable

  ''' <summary>
  ''' エラー・警告等DataTable
  ''' </summary>
  ''' <returns></returns>
  Public Property ErrorInfoDataTable As DataTable

  ''' <summary>
  ''' 出講・業務届明細DataTable
  ''' </summary>
  ''' <returns></returns>
  Public Property LectureWorkDataTable As DataTable

  ''' <summary>
  ''' 打刻外業務給データDataTable
  ''' </summary>
  ''' <returns></returns>
  Public Property WorkSalaryDataTable As DataTable
End Class
