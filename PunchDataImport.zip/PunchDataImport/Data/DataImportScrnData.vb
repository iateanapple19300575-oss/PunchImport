﻿''' <summary>
''' 出講データ取込画面データクラス
''' </summary>
Public Class DataImportScrnData
    Inherits ScreenData

    Public Class ImportInfo

        ''' <summary>
        ''' データ件数
        ''' </summary>
        ''' <returns></returns>
        Public Property DataCount As Integer

        ''' <summary>
        ''' 最終取込日時
        ''' </summary>
        ''' <returns></returns>
        Public Property FinalDate As Date

        ''' <summary>
        ''' 績履歴データ
        ''' </summary>
        ''' <returns></returns>
        Public Property History As DataTable

    End Class


    ''' <summary>
    ''' 対象年月度リスト
    ''' </summary>
    ''' <returns></returns>
    Public Property LectureYearMonthList As New List(Of String)

    ''' <summary>
    ''' [時間パターン]：最古日
    ''' </summary>
    ''' <returns></returns>
    Public Property TimePatternStartDate As Date

    ''' <summary>
    ''' [時間パターン]：最新日
    ''' </summary>
    ''' <returns></returns>
    Public Property TimePatternEndDate

    ''' <summary>
    ''' [時間パターン]：取込情報
    ''' </summary>
    ''' <returns></returns>
    Public Property TimePattern As ImportInfo

    ''' <summary>
    ''' [教室時間割]：取込情報
    ''' </summary>
    ''' <returns></returns>
    Public Property TimeTable As ImportInfo

    ''' <summary>
    ''' [コマ単価]：取込情報
    ''' </summary>
    ''' <returns></returns>
    Public Property UnitPrice As ImportInfo

    ''' <summary>
    ''' [打刻]：取込情報
    ''' </summary>
    ''' <returns></returns>
    Public Property Stamp As ImportInfo

    ''' <summary>
    ''' [出講予定]：取込情報
    ''' </summary>
    ''' <returns></returns>
    Public Property Plan As ImportInfo

    ''' <summary>
    ''' [業務依頼]：取込情報
    ''' </summary>
    ''' <returns></returns>
    Public Property Request As ImportInfo

    ''' <summary>
    ''' [代行実績]：取込情報
    ''' </summary>
    ''' <returns></returns>
    Public Property Delegation As ImportInfo

End Class
