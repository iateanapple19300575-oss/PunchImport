﻿Public Class TranspoExpensesData

	''' <summary>
	''' 講師コード
	''' </summary>
	''' <returns></returns>
	Public Property TeacherCode As String

	''' <summary>
	''' 講師名
	''' </summary>
	''' <returns></returns>
	Public Property TeacherName As String

	''' <summary>
	''' 出講場所
	''' </summary>
	''' <returns></returns>
	Public Property RoomCode As String

	''' <summary>
	''' 適用開始日
	''' </summary>
	''' <returns></returns>
	Public Property EffectiveDate As String

	''' <summary>
	''' 鮮度
	''' </summary>
	''' <returns></returns>
	Public Property Freshness As String

	''' <summary>
	''' 交通費
	''' </summary>
	''' <returns></returns>
	Public Property Amount As String

	''' <summary>
	''' 所要時間
	''' </summary>
	''' <returns></returns>
	Public Property TravelTime As Integer

	''' <summary>
	''' 更新対象の出講日
	''' </summary>
	''' <returns></returns>
	Public Property LectureDate As String

	''' <summary>
	''' 更新対象の適用開始日
	''' </summary>
	''' <returns></returns>
	''' <remarks>更新処理時のみ使用</remarks>
	Public Property NewEffectiveDate As String

	''' <summary>
	''' 更新対象の交通費
	''' </summary>
	''' <returns></returns>
	Public Property NewAmount As String
End Class
