﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto

''' <summary>
''' [LectureActual]テーブル用トラン
''' </summary>
Public Class LectureActualTran
  Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' [LectureActual]実績テーブルデータ削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteByPhaseAndType(ByRef param As CsvImportParameterDto) As Integer
    Dim firstDay As String = DateUtil.FirstDayOfMonth(param.TargetDate, "yyyy/MM/dd")
    Dim lastDay As String = DateUtil.LastDayOfMonth(param.TargetDate, "yyyy/MM/dd")

    Dim SqlQuery As New System.Text.StringBuilder
    SqlQuery.Length = 0
    SqlQuery.Append("DELETE").Append(" ")
    SqlQuery.Append("  FROM").Append(" ")
    SqlQuery.Append("    ").Append("W_Lecture_Actual").Append(" ")
    SqlQuery.Append("WHERE").Append(" ")
    SqlQuery.Append("  1=1").Append(" ")
    SqlQuery.Append("  AND Lecture_Date >= " & "@日付1" & " ")
    SqlQuery.Append("  AND Lecture_Date <= " & "@日付2" & " ")
    SqlQuery.Append("  AND Phase = @Phase").Append(" ")
    SqlQuery.Append("  AND Data_Type = @Data_Type").Append(" ")
    SqlQuery.Append("  AND Course_Type = @Course_Type").Append(" ")
    SqlQuery.Append(";")

    Return ExecuteNonQuery(SqlQuery.ToString(),
        New SqlParameter() With {.ParameterName = "@日付1", .Value = firstDay},
        New SqlParameter() With {.ParameterName = "@日付2", .Value = lastDay},
        New SqlParameter() With {.ParameterName = "@Phase", .Value = param.Phase},
        New SqlParameter() With {.ParameterName = "@Data_Type", .Value = param.DataType},
        New SqlParameter() With {.ParameterName = "@Course_Type", .Value = param.CourseType}
      )
  End Function

  ''' <summary>
  ''' 解析データ生成（出講データ）
  ''' </summary>
  ''' <param name="param"></param>
  ''' <returns></returns>
  Public Function InsertAnalysisLecture(ByRef param As CsvImportParameterDto) As Integer
    Dim resultData As New ResultData
    Dim importCount As Integer = 0
    Dim firstDay As String = DateUtil.FirstDayOfMonth(param.TargetDate, "yyyy/MM/dd")
    Dim lastDay As String = DateUtil.LastDayOfMonth(param.TargetDate, "yyyy/MM/dd")

        Dim SqlString As New System.Text.StringBuilder
        SqlString.Length = 0
        SqlString.Append(LectureActualInsertQueryBuilder())
        SqlString.Append("").Append(" ")

        SqlString.Append("SELECT").Append(" ")
        SqlString.Append("    LP.Lecture_Date As Lecture_Date").Append(" ")
        SqlString.Append("  , LP.Site_Code As Site_Code").Append(" ")
        SqlString.Append("  , LP.Grade As Grade").Append(" ")
        SqlString.Append("  , LP.Class_Code As Class_Code").Append(" ")
        SqlString.Append("  , LP.Koma_Seq As Koma_Seq").Append(" ")
        SqlString.Append("  , LP.Subject As Subject").Append(" ")
        SqlString.Append("  , LP.Number_Of_Text As Number_Of_Text").Append(" ")
        SqlString.Append("  , @Course_Type As Course_Type").Append(" ")
        SqlString.Append("  , LP.Teacher_Code As Teacher_Code").Append(" ")
        SqlString.Append("  , CONVERT(CHAR (5), COALESCE(").Append(" ")
        SqlString.Append("    TCD.Start_Time,").Append(" ")
        SqlString.Append("    TCM.Start_Time,").Append(" ")
        SqlString.Append("    TCY.Start_Time,").Append(" ")
        SqlString.Append("    TS.Start_Time").Append(" ")
        SqlString.Append("  )) AS Start_Time").Append(" ")
        SqlString.Append("  , CONVERT(CHAR (5), COALESCE(").Append(" ")
        SqlString.Append("    TCD.End_Time,").Append(" ")
        SqlString.Append("    TCM.End_Time,").Append(" ")
        SqlString.Append("    TCY.End_Time,").Append(" ")
        SqlString.Append("    TS.End_Time").Append(" ")
        SqlString.Append("  )) AS End_Time").Append(" ")
        SqlString.Append("  , LP.Pinch_Type As Pinch_Type").Append(" ")
        SqlString.Append("  , @Phase As Phase").Append(" ")
        SqlString.Append("  , @Data_Type As Data_Type").Append(" ")
        SqlString.Append("FROM W_Lecture_Plan LP").Append(" ")

        SqlString.Append("").Append(" ")
        SqlString.Append(GetScheduledTimeQuery()).Append(" ")
        SqlString.Append("").Append(" ")

        SqlString.Append("WHERE 1=1").Append(" ")
        SqlString.Append("  AND LP.Lecture_Date  >= @日付1").Append(" ")
        SqlString.Append("  AND LP.Lecture_Date  <= EOMONTH(@日付2, 0)").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("ORDER BY ").Append(" ")
        SqlString.Append("    LP.Lecture_Date").Append(" ")
        SqlString.Append("    , LP.Site_Code").Append(" ")
        SqlString.Append("    , LP.Grade").Append(" ")
        SqlString.Append("    , LP.Class_Code").Append(" ")
        SqlString.Append("    , LP.Koma_Seq").Append(" ")

        Return ExecuteNonQuery(SqlString.ToString(),
        New SqlParameter() With {.ParameterName = "@日付1", .Value = firstDay},
        New SqlParameter() With {.ParameterName = "@日付2", .Value = lastDay},
        New SqlParameter() With {.ParameterName = "@Phase", .Value = param.Phase},
        New SqlParameter() With {.ParameterName = "@Data_Type", .Value = param.DataType},
        New SqlParameter() With {.ParameterName = "@Course_Type", .Value = param.CourseType}
      )
    End Function

  ''' <summary>
  ''' 解析データ生成（代講反映データ）
  ''' 出講予定データと代講実績データを突き合わせてい当初の出講講師から代講した講師に書き換える
  ''' </summary>
  ''' <param name="param"></param>
  ''' <returns></returns>
  Public Function InsertAnalysisPinch(ByRef param As CsvImportParameterDto) As Integer

    Dim resultData As New ResultData
    Dim importCount As Integer = 0
    Dim firstDay As String = DateUtil.FirstDayOfMonth(param.TargetDate, "yyyy/MM/dd")
    Dim lastDay As String = DateUtil.LastDayOfMonth(param.TargetDate, "yyyy/MM/dd")

    Dim SqlQuery As New System.Text.StringBuilder
    SqlQuery.Length = 0
    SqlQuery.Append(LectureActualInsertQueryBuilder())
    SqlQuery.Append("").Append(" ")

    SqlQuery.Append("SELECT").Append(" ")
    SqlQuery.Append("  MT.Lecture_Date As Lecture_Date").Append(" ")
    SqlQuery.Append("  , MT.Site_Code As Site_Code").Append(" ")
    SqlQuery.Append("  , MT.Grade As Grade").Append(" ")
    SqlQuery.Append("  , MT.Class_Code As Class_Code").Append(" ")
    SqlQuery.Append("  , MT.Koma_Seq As Koma_Seq").Append(" ")
    SqlQuery.Append("  , MT.Subject As Subject").Append(" ")
    SqlQuery.Append("  , MT.Number_Of_Text As Number_Of_Text").Append(" ")
    SqlQuery.Append("  , @Course_Type As Course_Type").Append(" ")
    SqlQuery.Append("  , CASE ").Append(" ")
    SqlQuery.Append("    WHEN PU.Teacher_Code IS NOT NULL ").Append(" ")
    SqlQuery.Append("      THEN PU.Teacher_Code ").Append(" ")
    SqlQuery.Append("    ELSE MT.Teacher_Code ").Append(" ")
    SqlQuery.Append("    END As Teacher_Code").Append(" ")
    SqlQuery.Append("  , CONVERT( ").Append(" ")
    SqlQuery.Append("    CHAR (5)").Append(" ")
    SqlQuery.Append("    , COALESCE( ").Append(" ")
    SqlQuery.Append("      TCD.Start_Time").Append(" ")
    SqlQuery.Append("      , TCM.Start_Time").Append(" ")
    SqlQuery.Append("      , TCY.Start_Time").Append(" ")
    SqlQuery.Append("      , TS.Start_Time").Append(" ")
    SqlQuery.Append("    )").Append(" ")
    SqlQuery.Append("  ) AS Start_Time").Append(" ")
    SqlQuery.Append("  , CONVERT( ").Append(" ")
    SqlQuery.Append("    CHAR (5)").Append(" ")
    SqlQuery.Append("    , COALESCE( ").Append(" ")
    SqlQuery.Append("      TCD.End_Time").Append(" ")
    SqlQuery.Append("      , TCM.End_Time").Append(" ")
    SqlQuery.Append("      , TCY.End_Time").Append(" ")
    SqlQuery.Append("      , TS.End_Time").Append(" ")
    SqlQuery.Append("    )").Append(" ")
    SqlQuery.Append("  ) AS End_Time").Append(" ")
    SqlQuery.Append("  , Case ").Append(" ")
    SqlQuery.Append("    When PU.Pinch_Type Is Not NULL ").Append(" ")
    SqlQuery.Append("      Then PU.Pinch_Type ").Append(" ")
    SqlQuery.Append("    Else NULL ").Append(" ")
    SqlQuery.Append("    End As Pinch_Type ").Append(" ")
    SqlQuery.Append("  , @Phase As Phase").Append(" ")
    SqlQuery.Append("  , @Data_Type As Data_Type").Append(" ")
    SqlQuery.Append("FROM").Append(" ")
    SqlQuery.Append("  W_Lecture_Plan MT ").Append(" ")
    SqlQuery.Append("  LEFT JOIN W_Pinch_Actual PU ").Append(" ")
    SqlQuery.Append("    On ( ").Append(" ")
    SqlQuery.Append("      MT.Lecture_Date = FORMAT(PU.Lecture_Date, 'yyyyMMdd') ").Append(" ")
    SqlQuery.Append("      AND MT.Site_Code = PU.Site_Code ").Append(" ")
    SqlQuery.Append("      AND CONCAT(MT.Grade, MT.Class_Code) = PU.Class_Code ").Append(" ")
    SqlQuery.Append("      AND MT.Koma_Seq = PU.Koma_Seq ").Append(" ")
    SqlQuery.Append("      AND MT.Number_Of_Text = PU.Number_Of_Text ").Append(" ")
    SqlQuery.Append("      AND PU.Pinch_Type = 'U'").Append(" ")
    SqlQuery.Append("    ) ").Append(" ")

    SqlQuery.Append("").Append(" ")
    SqlQuery.Append(GetScheduledTimeQuery()).Append(" ")
    SqlQuery.Append("").Append(" ")

    SqlQuery.Append("WHERE 1=1").Append(" ")
    SqlQuery.Append("  AND MT.Lecture_Date  >= @日付1").Append(" ")
    SqlQuery.Append("  AND MT.Lecture_Date  <= EOMONTH(@日付2, 0)").Append(" ")
    SqlQuery.Append("").Append(" ")
    SqlQuery.Append("ORDER BY ").Append(" ")
    SqlQuery.Append("    MT.Lecture_Date").Append(" ")
    SqlQuery.Append("    , MT.Site_Code").Append(" ")
    SqlQuery.Append("    , MT.Grade").Append(" ")
    SqlQuery.Append("    , MT.Class_Code").Append(" ")
    SqlQuery.Append("    , MT.Koma_Seq").Append(" ")

    Return ExecuteNonQuery(SqlQuery.ToString(),
        New SqlParameter() With {.ParameterName = "@日付1", .Value = firstDay},
        New SqlParameter() With {.ParameterName = "@日付2", .Value = lastDay},
        New SqlParameter() With {.ParameterName = "@Phase", .Value = param.Phase},
        New SqlParameter() With {.ParameterName = "@Data_Type", .Value = param.DataType},
        New SqlParameter() With {.ParameterName = "@Course_Type", .Value = param.CourseType}
      )
  End Function

  ''' <summary>
  ''' 解析データ生成（業務届データ１）
  ''' </summary>
  ''' <param name="param"></param>
  ''' <returns></returns>
  Public Function InsertAnalysisTaskPunch(ByRef param As CsvImportParameterDto) As Integer
    Dim resultData As New ResultData
    Dim importCount As Integer = 0
    Dim firstDay As String = DateUtil.FirstDayOfMonth(param.TargetDate, "yyyy/MM/dd")
    Dim lastDay As String = DateUtil.LastDayOfMonth(param.TargetDate, "yyyy/MM/dd")

    Dim SqlQuery As New System.Text.StringBuilder
    SqlQuery.Length = 0
    SqlQuery.Append(LectureActualInsertQueryBuilder())
    SqlQuery.Append("").Append(" ")

    SqlQuery.Append("SELECT").Append(" ")
    SqlQuery.Append("  MT.Lecture_Date As Lecture_Date").Append(" ")
    SqlQuery.Append("  , MT.Site_Code As Site_Code").Append(" ")
    SqlQuery.Append("  , 'X' As Grade").Append(" ")
    SqlQuery.Append("  , 'XX' As Class_Code").Append(" ")
    SqlQuery.Append("  , ROW_NUMBER() OVER ( ").Append(" ")
    SqlQuery.Append("    PARTITION BY").Append(" ")
    SqlQuery.Append("      Teacher_Code").Append(" ")
    SqlQuery.Append("      , Lecture_Date ").Append(" ")
    SqlQuery.Append("    ORDER BY").Append(" ")
    SqlQuery.Append("      Teacher_Code").Append(" ")
    SqlQuery.Append("      , Lecture_Date").Append(" ")
    SqlQuery.Append("      , Start_Time").Append(" ")
    SqlQuery.Append("  ) + 100 As Koma_Seq").Append(" ")
    SqlQuery.Append("  , '_' As Subject").Append(" ")
    SqlQuery.Append("  , '' As Number_Of_Text").Append(" ")
    SqlQuery.Append("  , '" & param.CourseType & "'").Append(" ")
    SqlQuery.Append("  , MT.Teacher_Code As Teacher_Code").Append(" ")
    SqlQuery.Append("  , MT.Start_Time As Start_Time").Append(" ")
    SqlQuery.Append("  , MT.End_Time As End_Time").Append(" ")
    SqlQuery.Append("  , NULL As Pinch_Type ").Append(" ")
    SqlQuery.Append("  , @Phase As Phase").Append(" ")
    SqlQuery.Append("  , @Data_Type As Data_Type").Append(" ")
    SqlQuery.Append("FROM").Append(" ")
    SqlQuery.Append("  W_Request_Plan MT ").Append(" ")
    SqlQuery.Append("WHERE").Append(" ")
    SqlQuery.Append("  1 = 1 ").Append(" ")
    SqlQuery.Append("  AND MT.Lecture_Date  >= @日付1").Append(" ")
    SqlQuery.Append("  AND MT.Lecture_Date  <= EOMONTH(@日付2, 0)").Append(" ")
    SqlQuery.Append("ORDER BY").Append(" ")
    SqlQuery.Append("  MT.Lecture_Date").Append(" ")
    SqlQuery.Append("  , MT.Site_Code").Append(" ")
    SqlQuery.Append("  , MT.Teacher_Code").Append(" ")
    SqlQuery.Append("  , MT.Start_Time").Append(" ")

    Return ExecuteNonQuery(SqlQuery.ToString(),
        New SqlParameter() With {.ParameterName = "@日付1", .Value = firstDay},
        New SqlParameter() With {.ParameterName = "@日付2", .Value = lastDay},
        New SqlParameter() With {.ParameterName = "@Phase", .Value = param.Phase},
        New SqlParameter() With {.ParameterName = "@Data_Type", .Value = param.DataType}
      )
  End Function

  ''' <summary>
  ''' 実績テーブルインポート用INSERTクエリを作成する。
  ''' </summary>
  ''' <returns></returns>
  Private Function LectureActualInsertQueryBuilder() As String
        Dim SqlString As New System.Text.StringBuilder
        SqlString.Length = 0
        SqlString.Append("INSERT ").Append(" ")
        SqlString.Append("INTO W_Lecture_Actual( ").Append(" ")
        SqlString.Append("  Lecture_Date").Append(" ")
        SqlString.Append("  , Site_Code").Append(" ")
        SqlString.Append("  , Grade").Append(" ")
        SqlString.Append("  , Class_Code").Append(" ")
        SqlString.Append("  , Koma_Seq").Append(" ")
        SqlString.Append("  , Subject").Append(" ")
        SqlString.Append("  , Number_Of_Text").Append(" ")
        SqlString.Append("  , Course_Type").Append(" ")
        SqlString.Append("  , Teacher_Code").Append(" ")
        SqlString.Append("  , Start_Time").Append(" ")
        SqlString.Append("  , End_Time").Append(" ")
        SqlString.Append("  , Pinch_Type").Append(" ")
        SqlString.Append("  , Phase").Append(" ")
        SqlString.Append("  , Data_Type").Append(" ")
        SqlString.Append(") ").Append(" ")
        Return SqlString.ToString()
    End Function

  ''' <summary>
  ''' 時間割取得用クエリを作成する。
  ''' </summary>
  ''' <returns></returns>
  Private Function GetScheduledTimeQuery() As String
        Dim SqlString As New System.Text.StringBuilder
        SqlString.Length = 0
        SqlString.Append("LEFT JOIN M_Timetable_Class TCD").Append(" ")
        SqlString.Append("  ON  TCD.Site_Code = LP.Site_Code").Append(" ")
        SqlString.Append("  AND TCD.Grade  = LP.Grade").Append(" ")
        SqlString.Append("  AND TCD.Class_Code  = LP.Class_Code").Append(" ")
        SqlString.Append("  AND TCD.Koma_Seq   = LP.Koma_Seq").Append(" ")
        SqlString.Append("  AND TCD.Setting_Category = 3").Append(" ")
        SqlString.Append("  AND TCD.Target_Period = CONVERT(char(10), LP.Lecture_Date, 120)").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("LEFT JOIN M_Timetable_Class TCM").Append(" ")
        SqlString.Append("  ON  TCM.Site_Code = LP.Site_Code").Append(" ")
        SqlString.Append("  AND TCM.Grade  = LP.Grade").Append(" ")
        SqlString.Append("  AND TCM.Site_Code  = LP.Site_Code").Append(" ")
        SqlString.Append("  AND TCM.Koma_Seq   = LP.Koma_Seq").Append(" ")
        SqlString.Append("  AND TCM.Setting_Category = 2").Append(" ")
        SqlString.Append("  AND TCM.Target_Period = LEFT(CONVERT(char(10), LP.Lecture_Date, 120), 7)").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("LEFT JOIN M_Timetable_Class TCY").Append(" ")
        SqlString.Append("  ON  TCY.Site_Code = LP.Site_Code").Append(" ")
        SqlString.Append("  AND TCY.Grade  = LP.Grade").Append(" ")
        SqlString.Append("  AND TCY.Class_Code  = LP.Class_Code").Append(" ")
        SqlString.Append("  AND TCY.Koma_Seq   = LP.Koma_Seq").Append(" ")
        SqlString.Append("  AND TCY.Setting_Category = 1").Append(" ")
        SqlString.Append("  AND TCY.Target_Period = LEFT(CONVERT(char(10), LP.Lecture_Date, 120), 4)").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("LEFT JOIN (").Append(" ")
        SqlString.Append("  SELECT TP.Year, TP.Lecture_Date, TS.Site_Code, TS.Koma_Seq, TS.Start_Time, TS.End_Time").Append(" ")
        SqlString.Append("  FROM M_Time_Pattern TP ").Append(" ")
        SqlString.Append("  LEFT JOIN M_Timetable_Site TS ").Append(" ")
        SqlString.Append("  ON (").Append(" ")
        SqlString.Append("      TP.Year = TS.Year").Append(" ")
        SqlString.Append("      AND TP.Schedule_Pattern = TS.Schedule_Pattern ").Append(" ")
        SqlString.Append("  )").Append(" ")
        SqlString.Append(") TS").Append(" ")
        SqlString.Append("  ON (").Append(" ")
        SqlString.Append("      LP.Year=TS.Year").Append(" ")
        SqlString.Append("      AND LP.Lecture_Date = TS.Lecture_Date").Append(" ")
        SqlString.Append("      AND LP.Site_Code = TS.Site_Code").Append(" ")
        SqlString.Append("      AND LP.Koma_Seq = TS.Koma_Seq").Append(" ")
        SqlString.Append("  )").Append(" ")
        SqlString.Append("").Append(" ")
        Return SqlString.ToString()
    End Function

End Class
