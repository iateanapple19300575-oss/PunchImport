﻿''' <summary>
''' 業務依頼CSVデータバリデーションエラー表示画面
''' </summary>
Public Class RequestCsvError
    Inherits FrmValidationErrors

	'''' <summary>
	'''' Windowタイトル名
	'''' </summary>
	'Protected Overrides Property WINDOW_TITLE As String = "エラー一覧（業務届）"

	'''' <summary>
	'''' 業務届CSVデータ
	'''' </summary>
	'Private csvFileInfo As New RequestCsv


	'''' <summary>
	'''' コンストラクタ
	'''' </summary>
	'''' <param name="validationResultList"></param>
	'Public Sub New(ByVal validationResultList As Dictionary(Of Integer, List(Of ValidationResult)), ByVal csvInfo As CsvAbstract)
	'	MyBase.New(validationResultList)
	'End Sub

	'''' <summary>
	'''' カラム情報設定
	'''' </summary>
	'Protected Overrides Sub InitializeDataGridView()
	'	' カラム名と表示位置
	'	Dim csvColumns() As String = csvFileInfo.Headers.ToArray()
	'	Add(csvColumns(0), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(1), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(2), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(3), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(4), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(5), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(6), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(7), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(8), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(9), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(10), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(11), DataGridViewContentAlignment.MiddleRight)
	'	Add(csvColumns(12), DataGridViewContentAlignment.MiddleRight)
	'	Add(csvColumns(13), DataGridViewContentAlignment.MiddleRight)
	'	Add(csvColumns(14), DataGridViewContentAlignment.MiddleRight)
	'	Add(csvColumns(15), DataGridViewContentAlignment.MiddleRight)
	'	Add(csvColumns(16), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(17), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(18), DataGridViewContentAlignment.MiddleLeft)
	'End Sub
End Class
