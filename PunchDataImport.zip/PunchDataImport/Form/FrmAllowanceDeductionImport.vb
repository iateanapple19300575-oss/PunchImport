﻿Imports UserControl

Public Class FrmAllowanceDeductionImport
	Inherits BaseForm
	
	' CSV取込データ種別
	Private ReadOnly DataTypes As String() = {
		"手当(課税)データ",
		"控除(課税)データ",
		"精算金支払い(非課税)データ",
		"控除(非課税)データ",
		"手入力交通費データ"
	}

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New()
    MyBase.New("手当・控除データ取込")
    InitializeComponent()

    FormLogWrapper.WrapFormLifecycle(Me)
    FormLogWrapper.WrapAllEvents(Me)
  End Sub

  ''' <summary>
  ''' Loadイベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub FrmAllowanceDeductionImport_Load(sender As Object, e As EventArgs) Handles Me.Load
		flpRows.FlowDirection = FlowDirection.TopDown
		flpRows.WrapContents = False
		flpRows.AutoScroll = True

		For Each dt As String In DataTypes
      Dim row As New ImportRowControl
      row.DataTypeLabel = dt

			row.LastImportTime = "----/--/-- --:--"
			row.LastImportCount = "--,---件"

			AddHandler row.FileSelected, AddressOf OnFileSelected
            AddHandler row.ImportButtonClick, AddressOf OnImportRequested

            flpRows.Controls.Add(row)
		Next
	End Sub

    Private Sub OnFileSelected(sender As Object, e As EventArgs)

    End Sub

    Private Sub OnImportRequested(sender As Object, e As EventArgs)
        Dim row = DirectCast(sender, ImportRowControl)
        Dim dataType As String = row.DataTypeLabel
        Dim count As Integer = 0
        Dim result As String = "成功"

        Try
            Select Case dataType
                Case "手当(課税)データ"
                    count = AllowancesTaxableImport()
                Case "控除(課税)データ"
                    count = DeductionsTtaxableImport()
                Case "精算金支払い(非課税)データ"
                    count = SettlementPaymentsTaxExemptImport()
                Case "控除(非課税)データ"
                    count = DeductionsTaxExemptImport()
                Case "手入力交通費データ"
                    count = AllowancesAndDeductionsImport()
                Case Else
            End Select
        Catch ex As Exception
            result = "失敗"
        End Try

        row.SetCurrentImportResult(
                Date.Now.ToString("yyyy/MM/dd HH:mm"),
                count.ToString() & "件",
                result
            )
    End Sub

    Private Function AllowancesTaxableImport() As Integer
    Return 0
  End Function

  Private Function DeductionsTtaxableImport() As Integer
    Return 0
  End Function

  Private Function SettlementPaymentsTaxExemptImport() As Integer
    Return 0
  End Function

  Private Function DeductionsTaxExemptImport() As Integer
    Return 0
  End Function

  Private Function AllowancesAndDeductionsImport() As Integer
    Return 0
  End Function

	''' <summary>
	''' [手当・控除データ確認画面を開く]ボタン押下イベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub btnOpenWindow_Click(sender As Object, e As EventArgs) Handles btnOpenWindow.Click
		' [手当・控除データ確認]画面表示
		Dim frm As New FrmCheckAllowanceAndDeduction
		frm.ShowDialog()
	End Sub
End Class