﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmAllowanceDeductionImport
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
    Me.flpRows = New System.Windows.Forms.FlowLayoutPanel()
    Me.btnOpenWindow = New System.Windows.Forms.Button()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.SuspendLayout()
    '
    'flpRows
    '
    Me.flpRows.Location = New System.Drawing.Point(12, 10)
    Me.flpRows.Margin = New System.Windows.Forms.Padding(4)
    Me.flpRows.Name = "flpRows"
    Me.flpRows.Size = New System.Drawing.Size(800, 720)
    Me.flpRows.TabIndex = 0
    '
    'btnOpenWindow
    '
    Me.btnOpenWindow.Location = New System.Drawing.Point(580, 744)
    Me.btnOpenWindow.Margin = New System.Windows.Forms.Padding(4)
    Me.btnOpenWindow.Name = "btnOpenWindow"
    Me.btnOpenWindow.Size = New System.Drawing.Size(228, 30)
    Me.btnOpenWindow.TabIndex = 2
    Me.btnOpenWindow.Text = "手当・控除データ確認画面を開く"
    Me.btnOpenWindow.UseVisualStyleBackColor = True
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.Label1.Location = New System.Drawing.Point(149, 751)
    Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(411, 17)
    Me.Label1.TabIndex = 1
    Me.Label1.Text = "取込済みデータは「手当・控除データ確認」画面からご確認ください"
    '
    'FrmAllowanceDeductionImport
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(824, 791)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.btnOpenWindow)
    Me.Controls.Add(Me.flpRows)
    Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.Margin = New System.Windows.Forms.Padding(4)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "FrmAllowanceDeductionImport"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "手当・控除データ取込"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents flpRows As FlowLayoutPanel
	Friend WithEvents btnOpenWindow As Button
	Friend WithEvents Label1 As Label
End Class
