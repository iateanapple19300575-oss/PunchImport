﻿Imports ImportType
Imports MainApp.Data.Dto

Public Class TranImporterFactory

    Public Shared Function Create(type As ImportCsvType, param As CsvImportParameterDto, components As CsvImportComponents) As ICsvImporter
        Select Case param.CsvType
            Case ImportCsvType.PunchData
                Return New ImportPunchDataImporter(param, components)
            Case ImportCsvType.LecturePlan
                Return New ImportLecturePlanImporter(param, components)
            Case ImportCsvType.LectureCourse
                Return New ImportLecturePlanImporter(param, components)
            Case ImportCsvType.PinchActual
                Return New ImportPinchActualImporter(param, components)
            Case ImportCsvType.RequestActual
                Return New ImportRequestActualImporter(param, components)
            Case ImportCsvType.RequsttNoPunch
                Return New ImportRequestNoPunchImporter(param, components)
            Case Else
                Throw New NotSupportedException("未対応の CSV 種類です: " & param.CsvType)
        End Select
    End Function

End Class