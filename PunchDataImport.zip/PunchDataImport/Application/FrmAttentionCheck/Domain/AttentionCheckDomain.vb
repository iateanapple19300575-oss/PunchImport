﻿Public Class AttentionCheckDomain

    Public Shared Function LectureAndWorkAnalysis(ByVal dt As DataTable) As DataTable
        Dim destDt As DataTable = dt.Copy()

        For Each row As DataRow In destDt.Rows.Cast(Of DataRow).ToArray()
            Dim dataType = IIf(Not IsDBNull(row("Data_Type")), row("Data_Type"), "")
            Dim siteCode As String = IIf(Not IsDBNull(row("Site_Code")), row("Site_Code"), "")
            Dim grade As String = IIf(Not IsDBNull(row("Grade")), row("Grade"), "")
            Dim classCode As String = IIf(Not IsDBNull(row("Class_Code")), row("Class_Code"), "")
            Dim komaSeq As String = IIf(Not IsDBNull(row("Koma_Seq")), row("Koma_Seq"), "")
            Dim business As String = IIf(Not IsDBNull(row("Business_Name")), row("Business_Name"), "")
            Dim contents As String = IIf(Not IsDBNull(row("Contents")), row("Contents"), "")
            Dim siteName As String = IIf(Not IsDBNull(row("Site_Name")), row("Site_Name"), "")

            Dim message As String = ""
            If Not String.IsNullOrEmpty(dataType) Then
                If dataType = 1 Then
                    message = String.Format("出講：{0}年{1}クラス", grade, Trim(classCode))
                Else
                    message = String.Format("業務届：{0} ({1})", Trim(business), Trim(contents))
                End If
            End If

            row.BeginEdit()
            If dataType = 2 Then
                row("Koma_Seq") = DBNull.Value
            End If
            row("Site_Name") = String.Concat(siteCode, "：", siteName)
            row("Contents") = message
            row.EndEdit()
        Next

        Return destDt
    End Function

End Class
