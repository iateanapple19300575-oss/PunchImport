﻿Imports MainApp.Data.Dto

''' <summary>
''' 出講料アテンション確認画面サービスクラス
''' </summary>
Public Class FrmAttentionCheckService

    ''' <summary>
    ''' Domainサービス
    ''' </summary>
    Private _domain As New AttendanceDomain

    ''' <summary>
    ''' Domainサービス
    ''' </summary>
    Private _attentionCheckRepository As New FrmAttentionCheckRepository

    '''' <summary>
    '''' 勤怠情報リポジトリ
    '''' </summary>
    'Private _attendanceRepo As New AttendanceRepository


    '''' <summary>
    '''' 勤怠情報リポジトリ
    '''' </summary>
    'Private _repository As New AttendanceRepository

    ''' <summary>
    ''' 初期表示
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoad(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _domain = New AttendanceDomain(uow)
                dataList = _domain.LoadData(param)
                modelList = _domain.AttendanceAnalysis(dataList)
                Dim vMonthly As New AttendanceValidator(ValidationRuleSet.MonthlyCheck)
                vMonthly.Validate(modelList)
                dt = _domain.WorkListToAttentionCheckDataTable(modelList)
            End Using

        Catch ex As Exception

        End Try

        Return dt
    End Function

    ''' <summary>
    ''' 出講料チェックリスト(EXCEL出力処理)
    ''' </summary>
    ''' <param name="targetYearMonth"></param>
    ''' <returns></returns>
    Public Function ExportForLecturePunch(ByVal targetYearMonth As String, ByVal filePath As String) As ResultData
        Dim resultData As ResultData

        ' 対象年月度(String) → Date型に変換
        Dim dtTargetYearMonth As Date
        If (Not Date.TryParse(targetYearMonth, dtTargetYearMonth)) Then
            resultData = New ResultData()
            resultData.Success = False
            Return resultData
        End If

        Dim param As New ReportCondition
        param.TargetDate = dtTargetYearMonth

        ' 取得したシステム設定情報をパラメタにEXCEL出力実行
        Dim report As New ReportLectureFee(dtTargetYearMonth, filePath)
        resultData = report.Output()

        Return resultData
    End Function

    ''' <summary>
    ''' 出講料アテンションリスト(EXCEL出力処理)
    ''' </summary>
    ''' <param name="targetYearMonth"></param>
    ''' <returns></returns>
    Public Function ExportForLectureAttention(ByVal targetYearMonth As String, ByVal filePath As String) As ResultData
        Dim resultData As ResultData

        ' 対象年月度(String) → Date型に変換
        Dim dtTargetYearMonth As Date
        If (Not Date.TryParse(targetYearMonth, dtTargetYearMonth)) Then
            resultData = New ResultData()
            resultData.Success = False
            Return resultData
        End If

        Dim param As New RepositoryFindParameterDto
        param.TargetDate = targetYearMonth

        ' 取得したシステム設定情報をパラメタにEXCEL出力実行
        Dim report As New ReportAttentionCheck(dtTargetYearMonth, filePath)
        resultData = report.Output(param)

        Return resultData
    End Function

    Public Function LectureAttentionDataTable(ByVal targetYearMonth As String, ByVal filePath As String) As DataTable
        Dim param As New LectureDetailsFindParameter
        param.TargetDate = targetYearMonth
        'Dim dt As DataTable = _attentionCheckRepository.FindRowsByTargetDate(param)
        ''Return _domain.AttendanceAnalysis(dt)
        'Return dt


        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _domain = New AttendanceDomain(uow)
                dataList = _domain.LoadData(param)
                modelList = _domain.AttendanceAnalysis(dataList)
                Dim vMonthly As New AttendanceValidator(ValidationRuleSet.MonthlyCheck)
                vMonthly.Validate(modelList)
                dt = _domain.WorkListToAttentionCheckDataTable(modelList)
            End Using

        Catch ex As Exception

        End Try

        Return dt

    End Function

End Class
