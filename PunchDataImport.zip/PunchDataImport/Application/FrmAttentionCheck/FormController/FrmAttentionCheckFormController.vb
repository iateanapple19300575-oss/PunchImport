﻿''' <summary>
''' 出講料アテンション確認画面 Form Controller
''' </summary>
Public Class FrmAttentionCheckFormController

    ' 出講料アテンション確認画面 Service
    Private _service As New FrmAttentionCheckService

    ''' <summary>
    ''' 初期表示データロード
    ''' </summary>
    ''' <param name="dgv"></param>
    ''' <returns></returns>
    Public Function DataLoad(ByRef dgv As DataGridView) As DataTable
        ' DataGridView初期設定
        Dim def As New GridAttentionCheckStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)

        Dim param As New LectureDetailsFindParameter
        param.TargetDate = AppState.TargetYearMonth
        param.SearchStartDate = DateUtil.FirstDayOfMonth(AppState.TargetYearMonth)
        param.SearchEndDate = DateUtil.LastDayOfMonth(AppState.TargetYearMonth)
        Dim dt As DataTable = _service.DataLoad(param)

        Return dt
    End Function
End Class
