﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmDailyAttendanceStatement
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.dgvPunchInfo = New System.Windows.Forms.DataGridView()
        Me.dgvDailyStatement = New System.Windows.Forms.DataGridView()
        Me.dgvBusinessPayData = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dgvErrorInfo = New System.Windows.Forms.DataGridView()
        CType(Me.dgvPunchInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvDailyStatement, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvBusinessPayData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvErrorInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvPunchInfo
        '
        Me.dgvPunchInfo.AllowUserToAddRows = False
        Me.dgvPunchInfo.AllowUserToDeleteRows = False
        Me.dgvPunchInfo.AllowUserToResizeColumns = False
        Me.dgvPunchInfo.AllowUserToResizeRows = False
        Me.dgvPunchInfo.ColumnHeadersHeight = 30
        Me.dgvPunchInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvPunchInfo.Location = New System.Drawing.Point(20, 20)
        Me.dgvPunchInfo.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvPunchInfo.Name = "dgvPunchInfo"
        Me.dgvPunchInfo.ReadOnly = True
        Me.dgvPunchInfo.RowHeadersVisible = False
        Me.dgvPunchInfo.RowHeadersWidth = 20
        Me.dgvPunchInfo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvPunchInfo.RowTemplate.Height = 30
        Me.dgvPunchInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvPunchInfo.Size = New System.Drawing.Size(1000, 60)
        Me.dgvPunchInfo.TabIndex = 0
        '
        'dgvDailyStatement
        '
        Me.dgvDailyStatement.AllowUserToAddRows = False
        Me.dgvDailyStatement.AllowUserToDeleteRows = False
        Me.dgvDailyStatement.AllowUserToResizeColumns = False
        Me.dgvDailyStatement.AllowUserToResizeRows = False
        Me.dgvDailyStatement.ColumnHeadersHeight = 30
        Me.dgvDailyStatement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvDailyStatement.Location = New System.Drawing.Point(20, 310)
        Me.dgvDailyStatement.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvDailyStatement.Name = "dgvDailyStatement"
        Me.dgvDailyStatement.ReadOnly = True
        Me.dgvDailyStatement.RowHeadersVisible = False
        Me.dgvDailyStatement.RowHeadersWidth = 20
        Me.dgvDailyStatement.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvDailyStatement.RowTemplate.Height = 30
        Me.dgvDailyStatement.RowTemplate.ReadOnly = True
        Me.dgvDailyStatement.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvDailyStatement.Size = New System.Drawing.Size(492, 250)
        Me.dgvDailyStatement.TabIndex = 2
        '
        'dgvBusinessPayData
        '
        Me.dgvBusinessPayData.AllowUserToAddRows = False
        Me.dgvBusinessPayData.AllowUserToDeleteRows = False
        Me.dgvBusinessPayData.AllowUserToResizeColumns = False
        Me.dgvBusinessPayData.AllowUserToResizeRows = False
        Me.dgvBusinessPayData.ColumnHeadersHeight = 30
        Me.dgvBusinessPayData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvBusinessPayData.Location = New System.Drawing.Point(530, 310)
        Me.dgvBusinessPayData.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvBusinessPayData.Name = "dgvBusinessPayData"
        Me.dgvBusinessPayData.ReadOnly = True
        Me.dgvBusinessPayData.RowHeadersVisible = False
        Me.dgvBusinessPayData.RowHeadersWidth = 20
        Me.dgvBusinessPayData.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvBusinessPayData.RowTemplate.Height = 30
        Me.dgvBusinessPayData.RowTemplate.ReadOnly = True
        Me.dgvBusinessPayData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvBusinessPayData.Size = New System.Drawing.Size(492, 250)
        Me.dgvBusinessPayData.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 290)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "出講・業務届明細"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(530, 290)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "打刻外業務給データ"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(36, 570)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(631, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "※打刻漏れや打刻ミスの場合、ジョブカン管理画面から打刻修正を行い、再度CSV出力を行ってください。"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 100)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "エラー・警告等"
        '
        'dgvErrorInfo
        '
        Me.dgvErrorInfo.AllowUserToAddRows = False
        Me.dgvErrorInfo.AllowUserToDeleteRows = False
        Me.dgvErrorInfo.AllowUserToResizeColumns = False
        Me.dgvErrorInfo.AllowUserToResizeRows = False
        Me.dgvErrorInfo.ColumnHeadersHeight = 30
        Me.dgvErrorInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvErrorInfo.Location = New System.Drawing.Point(20, 120)
        Me.dgvErrorInfo.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvErrorInfo.Name = "dgvErrorInfo"
        Me.dgvErrorInfo.ReadOnly = True
        Me.dgvErrorInfo.RowHeadersVisible = False
        Me.dgvErrorInfo.RowHeadersWidth = 20
        Me.dgvErrorInfo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvErrorInfo.RowTemplate.Height = 30
        Me.dgvErrorInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvErrorInfo.Size = New System.Drawing.Size(1000, 146)
        Me.dgvErrorInfo.TabIndex = 7
        '
        'FrmDailyAttendanceStatement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1039, 596)
        Me.Controls.Add(Me.dgvErrorInfo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvBusinessPayData)
        Me.Controls.Add(Me.dgvDailyStatement)
        Me.Controls.Add(Me.dgvPunchInfo)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmDailyAttendanceStatement"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "日次勤怠明細"
        CType(Me.dgvPunchInfo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvDailyStatement, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvBusinessPayData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvErrorInfo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvPunchInfo As DataGridView
	Friend WithEvents dgvDailyStatement As DataGridView
	Friend WithEvents dgvBusinessPayData As DataGridView
	Friend WithEvents Label1 As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents Label3 As Label
	Friend WithEvents Label4 As Label
	Friend WithEvents dgvErrorInfo As DataGridView
End Class
