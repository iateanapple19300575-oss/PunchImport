﻿Imports MainApp.Data.Dto

Public Class DailyAttendanceStatementFormController
    Private _service As New AttendanceService

    Public Function DataLoad(ByRef dgv As DataGridView) As DataTable
        'Dim def As New GridDailyCheckStyle()
        'def.Apply(dgv)
        'Dim style As New GridStyleDefinitionDefault()
        'style.ApplyCustom(dgv)

        Dim param As New LectureDetailsFindParameter
        param.TargetDate = AppState.TargetYearMonth
        param.TeacherCode = "G039"
        Dim dt As DataTable = _service.DataLoadByDay(param)
        Return dt
    End Function
End Class
