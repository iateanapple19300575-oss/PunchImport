﻿Imports Nts.Freamwork.Common.Utilities
Imports PunchDataImport.MainApp.Data.Model

''' <summary>
''' 月締め処理画面の ViewController
''' </summary>
Public Class FrmMonthlyClosingViewController

    ''' <summary>
    ''' 月締め処理 Service
    ''' </summary>
    Private _service As New MonthlyClosingService

    ''' <summary>
    ''' 初期表示データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function LoadData() As ClosingManagementModel
        Dim model As New ClosingManagementModel
        model.YearMonth = DateUtil.DateToYearMonth(AppState.TargetYearMonth)
        model = _service.LoadData(model)

        ' まだ締め処理をしたことがないならば締め状態：通常
        If StringUtil.IsNullOrWhiteSpace(model.YearMonth) Then
            model.MonthlyClosingState = MonthlyClosingMode.None
            Return model
        End If

        ' 月締め状態の更新
        CloseStatusUpdate(model)

        Return model
    End Function

    ''' <summary>
    ''' 仮締め処理
    ''' </summary>
    ''' <returns></returns>
    Public Function TempClose() As ClosingManagementModel
        Dim model As New ClosingManagementModel
        model.YearMonth = DateUtil.DateToYearMonth(AppState.TargetYearMonth)
        model = _service.TempClose(model)

        ' 月締め状態の更新
        model = CloseStatusUpdate(model)
        Return model
    End Function

    ''' <summary>
    ''' 本締め処理
    ''' </summary>
    ''' <returns></returns>
    Public Function FinalClose() As ClosingManagementModel
        Dim model As New ClosingManagementModel
        model.YearMonth = DateUtil.DateToYearMonth(AppState.TargetYearMonth)
        model = _service.FinalClose(model)

        ' 月締め状態の更新
        model = CloseStatusUpdate(model)
        Return model
    End Function

    ''' <summary>
    ''' 仮締め解除処理
    ''' </summary>
    ''' <returns></returns>
    Public Function TempCloseRelease() As ClosingManagementModel
        Dim model As New ClosingManagementModel
        model.YearMonth = DateUtil.DateToYearMonth(AppState.TargetYearMonth)
        model = _service.TempCloseRelease(model)

        ' まだ締め処理をしたことがないならば締め状態：通常
        If StringUtil.IsNotNullOrWhiteSpace(model.YearMonth) Then
            model.MonthlyClosingState = MonthlyClosingMode.None
            Return model
        End If

        ' 一度でも締め処理をしたことがあるならば、管理情報を元に判定
        If StringUtil.IsNotNullOrWhiteSpace(model.FinalCloseUser) Then
            model.MonthlyClosingState = MonthlyClosingMode.FinalClose
        ElseIf StringUtil.IsNotNullOrWhiteSpace(model.TempCloseUser) Then
            model.MonthlyClosingState = MonthlyClosingMode.TempClose
        Else
            model.MonthlyClosingState = MonthlyClosingMode.None
        End If

        Return model
    End Function

    ''' <summary>
    ''' 月締め状態の更新
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Private Shared Function CloseStatusUpdate(model As ClosingManagementModel) As ClosingManagementModel
        If StringUtil.IsNotNullOrWhiteSpace(model.FinalCloseUser) Then
            model.MonthlyClosingState = MonthlyClosingMode.FinalClose
        ElseIf StringUtil.IsNotNullOrWhiteSpace(model.TempCloseUser) Then
            model.MonthlyClosingState = MonthlyClosingMode.TempClose
        Else
            model.MonthlyClosingState = MonthlyClosingMode.None
        End If

        Return model
    End Function

End Class
