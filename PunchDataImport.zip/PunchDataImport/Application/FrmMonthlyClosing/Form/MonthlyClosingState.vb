﻿Public Class MonthlyClosingState

    ''' <summary>現在の月締めモード</summary>
    Public Property Mode As MonthlyClosingMode = MonthlyClosingMode.None

    '===============================
    ' モード遷移
    '===============================
    ''' <summary>初期状態</summary>
    Public Sub EnterInitMode()
        Mode = MonthlyClosingMode.None
    End Sub

    ''' <summary>仮締め済みモードに遷移する</summary>
    Public Sub EnterTempCloseMode()
        Mode = MonthlyClosingMode.TempClose
    End Sub

    ''' <summary>本締め済みモードに遷移する</summary>
    Public Sub EnterFinalCloseMode()
        Mode = MonthlyClosingMode.FinalClose
    End Sub

    '===============================
    ' 判定
    '===============================

    ''' <summary>仮締め処理可能かどうか</summary>
    Public Function CanTempClose() As Boolean
        Return Mode = MonthlyClosingMode.None
    End Function

    ''' <summary>本締め処理可能かどうか</summary>
    Public Function CanFinalClose() As Boolean
        Return Mode = MonthlyClosingMode.TempClose
    End Function

    ''' <summary>仮締めボタンが有効かどうか</summary>
    Public Function IsTempCloseEnabled() As Boolean
        Return Mode = MonthlyClosingMode.None
    End Function

    ''' <summary>本締めボタンが有効かどうか</summary>
    Public Function IsFinalCloseEnabled() As Boolean
        Return Mode = MonthlyClosingMode.TempClose
    End Function

    ''' <summary>解除ボタンが有効かどうか</summary>
    Public Function IsReleaseEnabled() As Boolean
        Return Mode = MonthlyClosingMode.TempClose
    End Function

End Class

''' <summary>
''' 画面の編集モードを表す列挙体。
''' </summary>
Public Enum MonthlyClosingMode

    ''' <summary>仮締め前状態</summary>
    None

    ''' <summary>仮締め済み</summary>
    TempClose

    ''' <summary>本締め済み</summary>
    FinalClose

End Enum