﻿Imports PunchDataImport.MainApp.Data.Model

''' <summary>
''' 月締め処理画面
''' </summary>
Public Class FormMonthlyClosing

    ''' <summary>
    ''' 仮締め状態管理
    ''' </summary>
    Private _state As New MonthlyClosingState

    ''' <summary>
    ''' 月締め処理画面 ViewController
    ''' </summary>
    Private _controller As New FrmMonthlyClosingViewController



#Region "初期表示"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FormMonthlyClosing_Load(sender As Object, e As EventArgs) Handles Me.Load

        ' 初期表示
        InitDisplay()

    End Sub

    ''' <summary>
    ''' 初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        ' 月締め状態取得
        Dim model As ClosingManagementModel
        model = _controller.LoadData()
        _state.Mode = model.MonthlyClosingState

        ' 対象年月の表示
        lblTargetYearMonth.Text = DateUtil.FormatKanjiYearMonth(AppState.TargetYearMonth)

        ' 状態の表示
        lblCloseState.Text = GetCloseState()

        ' 各ボタン表示
        ScreenComponentRefresh()

    End Sub

#End Region

    ''' <summary>
    ''' 解除ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnRelease_Click(sender As Object, e As EventArgs) Handles btnRelease.Click
        ' 月締め解除
        Dim model As ClosingManagementModel
        model = _controller.TempCloseRelease()
        _state.Mode = model.MonthlyClosingState


        _state.EnterInitMode()
        ScreenComponentRefresh()
    End Sub

    ''' <summary>
    ''' 仮締め処理ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnTempClose_Click(sender As Object, e As EventArgs) Handles btnTempClose.Click
        Dim model As ClosingManagementModel
        model = _controller.TempClose()
        _state.Mode = model.MonthlyClosingState

        _state.EnterTempCloseMode()
        ScreenComponentRefresh()
    End Sub

    ''' <summary>
    ''' 本締め処理ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnFinalClose_Click(sender As Object, e As EventArgs) Handles btnFinalClose.Click
        Dim model As ClosingManagementModel
        model = _controller.FinalClose()
        _state.Mode = model.MonthlyClosingState

        _state.EnterFinalCloseMode()
        ScreenComponentRefresh()
    End Sub

    ''' <summary>
    ''' 画面部品の表示更新
    ''' </summary>
    Private Sub ScreenComponentRefresh()

        ' ボタンの表示更新
        btnRelease.Visible = _state.IsReleaseEnabled
        btnTempClose.Enabled = _state.IsTempCloseEnabled
        btnFinalClose.Enabled = _state.IsFinalCloseEnabled

        ' 締め状態の更新
        lblCloseState.Text = GetCloseState()

    End Sub

    ''' <summary>
    ''' 現在の締め状態に対応する状態名を返します。
    ''' </summary>
    ''' <returns></returns>
    Private Function GetCloseState() As String
        Dim stateStr As String = ""
        Select Case _state.Mode
            Case MonthlyClosingMode.None
                stateStr = "締め処理前"
            Case MonthlyClosingMode.TempClose
                stateStr = "仮締め済み"
            Case MonthlyClosingMode.FinalClose
                stateStr = "本締め済み"
            Case Else
                stateStr = "?????"
        End Select
        Return stateStr
    End Function

End Class