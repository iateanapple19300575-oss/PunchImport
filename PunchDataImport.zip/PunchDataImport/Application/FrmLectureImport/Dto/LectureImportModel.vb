﻿Imports MainApp.Data.Dto
Imports UserControl

Namespace MainApp.Data.Dto

    ''' <summary>
    ''' Model。
    ''' </summary>
    Public Class LectureImportModel

        ''' <summary>
        ''' CSVファイルパス
        ''' </summary>
        Public Property FilePath As String

        ''' <summary>
        ''' CSVタイプ
        ''' </summary>
        Public Property CsvType As Integer

        ''' <summary>
        ''' データタイプ名
        ''' </summary>
        Public Property DataName As String

        ''' <summary>
        ''' 取込フェーズ
        ''' </summary>
        Public Property Phase As Integer

        ''' <summary>
        ''' データタイプ
        ''' </summary>
        Public Property DataType As Integer

        ''' <summary>
        ''' コースタイプ
        ''' </summary>
        Public Property CourseType As Integer

        ''' <summary>
        ''' 対象年月度
        ''' </summary>
        Public Property TargetDate As Date

        ''' <summary>
        ''' 対象インポートUserControl
        ''' </summary>
        ''' <returns></returns>
        Public Property ImportUserCtrl As ImportRowControl

        ''' <summary>
        ''' 打刻インポート
        ''' </summary>
        Public Property ImportResults As New Dictionary(Of Integer, ImportResultsDto)

        ''' <summary>
        ''' 打刻データ
        ''' </summary>
        ''' <returns></returns>
        Public Property ImportPunchResult As New ImportResultsDto

        ''' <summary>
        ''' 出講データ
        ''' </summary>
        Public Property ImportLectureResult1 As New ImportResultsDto

        ''' <summary>
        ''' 出講データ
        ''' </summary>
        Public Property ImportLectureResult2 As New ImportResultsDto

        ''' <summary>
        ''' 代講実績
        ''' </summary>
        Public Property ImportDelegationResult As New ImportResultsDto

        ''' <summary>
        ''' 業務依頼
        ''' </summary>
        Public Property ImportRequestResult1 As New ImportResultsDto

        ''' <summary>
        ''' 業務依頼(打刻なし)
        ''' </summary>
        Public Property ImportRequestResult2 As New ImportResultsDto

        ''' <summary>
        ''' インポート結果情報
        ''' </summary>
        ''' <returns></returns>
        Public Property ImportResult As New ImportResultInfo

    End Class

End Namespace
