﻿Imports LecturePay.Common.Infrastructure

''' <summary>
''' 交通費管理画面クラス
''' </summary>
Public Class FrmTransportExpenses
  Inherits BaseForm

  ''' <summary>
  ''' 
  ''' </summary>
  Private service As New TransportExpensesService()

  ''' <summary>
  ''' 初期表示処理中フラグ
  ''' </summary>
  Private IsInitializing As Boolean = True

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New()
    MyBase.New("交通費管理")
    InitializeComponent()

    FormLogWrapper.WrapFormLifecycle(Me)
    FormLogWrapper.WrapAllEvents(Me)
  End Sub

  ''' <summary>
  ''' Loadイベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub FrmTransportExpenses_Load(sender As Object, e As EventArgs) Handles Me.Load
    IsInitializing = True
    RemoveHandler cmbSubject.SelectedIndexChanged, AddressOf cmbDistrict_SelectedIndexChanged
    RemoveHandler cmbTeacher.SelectedIndexChanged, AddressOf cmbTeacher_SelectedIndexChanged
    RemoveHandler cmbGroup.SelectedIndexChanged, AddressOf cmbGroup_SelectedIndexChanged
    RemoveHandler cmbSite.SelectedIndexChanged, AddressOf cmbClassRoom_SelectedIndexChanged
    InitDisplay()
    AddHandler cmbSubject.SelectedIndexChanged, AddressOf cmbDistrict_SelectedIndexChanged
    AddHandler cmbTeacher.SelectedIndexChanged, AddressOf cmbTeacher_SelectedIndexChanged
    AddHandler cmbGroup.SelectedIndexChanged, AddressOf cmbGroup_SelectedIndexChanged
    AddHandler cmbSite.SelectedIndexChanged, AddressOf cmbClassRoom_SelectedIndexChanged
    IsInitializing = False
  End Sub

  ''' <summary>
  ''' 画面初期表示処理
  ''' </summary>
  Private Sub InitDisplay()
    ' 科目コンボデータ設定
    LoadComboDataForSubject()
    ' 講師コンボデータ設定
    LoadComboDataForTeacher()
    ' グループコンボデータ設定
    LoadComboDataForGroup()
    ' 教室コンボデータ設定
    LoadComboDataForSite()
    ' 交通費一覧データ
    DisplayTranspExpens()
  End Sub

  ''' <summary>
  ''' 科目コンボボックスにデータ設定
  ''' </summary>
  Private Sub LoadComboDataForSubject()
    Dim dtTable As DataTable
    dtTable = AppCommon.GetTranspExpSubjects()
    ComboBoxHelper.SetDataSource(cmbSubject, dtTable, "Name", "ID")
  End Sub

  ''' <summary>
  ''' 講師コンボボックスにデータ設定
  ''' </summary>
  Private Sub LoadComboDataForTeacher()
    Dim targetDate As Date = AppState.TargetYearMonth
    Dim subject_Code As String = IIf(cmbSubject.SelectedValue Is Nothing OrElse IsDBNull(cmbSubject.SelectedValue), "", cmbSubject.SelectedValue)
    Dim teacher_Code As String = IIf(cmbTeacher.SelectedValue Is Nothing OrElse IsDBNull(cmbTeacher.SelectedValue), "", cmbTeacher.SelectedValue)
    Dim result As ResultData = service.LoadTeacherData(targetDate, teacher_Code, subject_Code)

    If result.Success Then
      Dim dtTable As DataTable = result.ResDataTable
      With cmbTeacher
        ComboBoxHelper.SetDataSource(cmbTeacher, dtTable, TeacherRegistryEnum.講師名.Column, TeacherRegistryEnum.講師コード.Column)
        .SelectedValue = teacher_Code

        If .SelectedIndex = -1 Then
          .SelectedIndex = 0
        End If
      End With
    End If
  End Sub

  ''' <summary>
  ''' グループのコンボボックスにデータ設定
  ''' </summary>
  Private Sub LoadComboDataForGroup()
    Dim dtTable As DataTable
    dtTable = service.LoadComboDataForGroup("1")
    ComboBoxHelper.SetDataSource(cmbGroup, dtTable, MNSPM10Enum.Division_Name.Column, MNSPM10Enum.Division_KND.Column)
  End Sub

  ''' <summary>
  ''' 教室のコンボボックスにデータ設定
  ''' </summary>
  Private Sub LoadComboDataForSite()
    Dim corporate As String = "1"
    Dim division As String = ""
    If Not IsDBNull(cmbGroup.SelectedValue) Then
      division = cmbGroup.SelectedValue
    End If

    Dim dtTable As DataTable
    dtTable = service.LoadComboDataForSite(corporate, division)
    ComboBoxHelper.SetDataSource(cmbSite, dtTable, MNSPM11Enum.Site_Name.Column, MNSPM11Enum.Site_Code.Column)
  End Sub

  '' <summary>
  '' 交通費一覧表示
  '' </summary>
  Private Sub DisplayTranspExpens()
    Dim ifData As TrasportExpensesIF = DataLoadCondition()
    Dim result As ResultData = service.LoadTransportationExpensesData(dgvTranspExpens, ifData)
    If result.Success Then
      Dim dtTable As DataTable = result.ResDataTable
      dtTable = result.ResDataTable
      IsInitializing = True
      With dgvTranspExpens
        .DataSource = dtTable
        If .Rows.Count > 0 Then
          .Rows(0).Selected = True
        End If
      End With
      IsInitializing = False
    End If
  End Sub

  ''' <summary>
  ''' 条件指定による交通費情報再表示
  ''' </summary>
  Private Sub DisplayUpadte()
    'Dim result As New ResultData
    'IsInitializing = True
    'Dim ifData As TrasportExpensesIF = DataLoadCondition()
    'result = service.LoadTransportationExpensesData(dgvTranspExpens, ifData)
    'IsInitializing = False
    DisplayTranspExpens()
  End Sub

  '''' <summary>
  '''' [教室]選択イベント
  '''' </summary>
  '''' <param name="sender"></param>
  '''' <param name="e"></param>
  'Private Sub btnRoomSelect_Click(sender As Object, e As EventArgs)
  '	Dim frm As New FrmClassRoomSelect
  '	frm.ShowDialog()
  'End Sub


  ''' <summary>
  ''' [科目]コンボ選択変更イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub cmbDistrict_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSubject.SelectedIndexChanged
    If IsInitializing = True Then
      Return
    End If

    With cmbSubject
      If .SelectedIndex < 0 Then
        Return
      End If
      RemoveHandler cmbTeacher.SelectedIndexChanged, AddressOf cmbTeacher_SelectedIndexChanged
      LoadComboDataForTeacher()
      AddHandler cmbTeacher.SelectedIndexChanged, AddressOf cmbTeacher_SelectedIndexChanged
    End With
    DisplayUpadte()
  End Sub

  ''' <summary>
  ''' [講師]コンボ選択変更イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub cmbTeacher_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTeacher.SelectedIndexChanged
    If IsInitializing = True Then
      Return
    End If

    DisplayUpadte()
  End Sub

  ''' <summary>
  ''' [グループ]コンボ選択変更イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub cmbGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbGroup.SelectedIndexChanged
    If IsInitializing = True Then
      Return
    End If

    DisplayUpadte()
    'LoadComboDataForSite()
  End Sub

  ''' <summary>
  ''' [教室]コンボ選択変更イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub cmbClassRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSite.SelectedIndexChanged
    If IsInitializing = True Then
      Return
    End If

    DisplayUpadte()
  End Sub

  ''' <summary>
  ''' [未登録のみ]チェックボックスクリックイベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub cbxUnregisteredOnly_CheckedChanged(sender As Object, e As EventArgs) Handles cbxUnregisteredOnly.CheckedChanged
    If IsInitializing = True Then
      Return
    End If

    DisplayUpadte()
  End Sub

  ''' <summary>
  ''' 画面表示条件取得
  ''' </summary>
  ''' <returns></returns>
  Private Function DataLoadCondition() As TrasportExpensesIF
    Dim ifData As New TrasportExpensesIF

    If cmbSubject.SelectedIndex >= 1 Then
      If Not IsDBNull(cmbSubject.SelectedValue) Then
        ifData.Subjects = cmbSubject.SelectedValue
      End If
    End If

    If cmbTeacher.SelectedIndex >= 1 Then
      If Not IsDBNull(cmbTeacher.SelectedValue) Then
        ifData.TeacherCode = cmbTeacher.SelectedValue
      End If
    End If

    If cmbGroup.SelectedIndex >= 1 Then
      If Not IsDBNull(cmbGroup.SelectedValue) Then
        ifData.GroupCode = cmbGroup.SelectedValue
      End If
    End If

    If cmbSite.SelectedIndex >= 1 Then
      If Not IsDBNull(cmbSite.SelectedValue) Then
        ifData.SiteCode = cmbSite.SelectedValue
      End If
    End If

    ifData.UnregisteredOnly = (True = cbxUnregisteredOnly.Checked)

    Return ifData
  End Function

End Class