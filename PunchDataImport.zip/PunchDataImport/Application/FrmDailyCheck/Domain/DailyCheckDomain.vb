﻿Imports System.Reflection
Imports Nts.Freamwork.Common.Utilities

Public Class DailyCheckDomain

#If 0 Then

    ''' <summary>
    ''' 実務開始時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleStartTime(ByVal model As AttendanceModel) As TimeSpan?

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.WorkStartTime = model.LectureStart
            Else
                model.WorkStartTime = model.TaskStart
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.WorkStartTime = model.TaskStart
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.WorkStartTime = model.LectureStart
        End If

        Return model.WorkStartTime
    End Function

    ''' <summary>
    ''' 実務終了時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleEndTime(ByVal model As AttendanceModel) As TimeSpan?

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.WorkEndTime = model.LectureEnd
            Else
                model.WorkEndTime = model.TaskEnd
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.WorkEndTime = model.TaskEnd
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.WorkEndTime = model.LectureEnd
        End If

        Return model.WorkEndTime
    End Function

    ''' <summary>
    ''' みなし開始時間
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeStart(ByVal model As AttendanceModel) As TimeSpan?

        If Not model.PunchStartTime.HasValue Then
            Return Nothing
        End If

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.DeemedStartTime = IIf(model.PunchStartTime < model.LectureStart - model.DeemedTimeBefore,
                                            model.PunchStartTime,
                                            model.LectureStart - model.DeemedTimeBefore)
            Else
                model.DeemedStartTime = model.PunchStartTime
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.DeemedStartTime = model.PunchStartTime
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.DeemedStartTime = IIf(model.PunchStartTime < model.LectureStart - model.DeemedTimeBefore,
                                        model.PunchStartTime,
                                        model.LectureStart - model.DeemedTimeBefore)
        End If

        Return model.DeemedStartTime
    End Function

    ''' <summary>
    ''' みなし終了時間
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeEnd(ByVal model As AttendanceModel) As TimeSpan?

        If Not model.PunchEndTime.HasValue Then
            Return Nothing
        End If

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.DeemedEndTime = IIf(model.PunchEndTime > model.LectureEnd + model.DeemedTimeAfter,
                                            model.PunchEndTime,
                                            model.LectureEnd + model.DeemedTimeAfter)
            Else
                model.DeemedEndTime = model.PunchEndTime
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.PunchEndTime
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.DeemedEndTime = IIf(model.PunchEndTime > model.LectureEnd + model.DeemedTimeAfter,
                                        model.PunchEndTime,
                                        model.LectureEnd + model.DeemedTimeAfter)
        End If

        Return model.DeemedEndTime
    End Function
#End If

    Public Function FilteredSearch(ByVal param As LectureDetailsFindParameter, ByVal modelList As List(Of AttendanceModel)) As DataTable
        Dim dt As New DataTable("Work")

#Region "DataTableの定義関連"

        ' 打刻等の時間情報関連
        dt.Columns.Add("DateStr", GetType(String))
        dt.Columns.Add("DateKey", GetType(String))
        dt.Columns.Add("DateColor", GetType(String))
        dt.Columns.Add("StatusLevel", GetType(String))
        dt.Columns.Add("StatusStr", GetType(String))
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Punch_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Punch_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Lecture_Start", GetType(TimeSpan))
        dt.Columns.Add("Lecture_End", GetType(TimeSpan))
        dt.Columns.Add("Task_Start", GetType(TimeSpan))
        dt.Columns.Add("Task_End", GetType(TimeSpan))
        dt.Columns.Add("Work_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Work_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Hours", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Hour_Time", GetType(Decimal))

        ' 打刻等の時間外の情報
        dt.Columns.Add("Overlap_Other", GetType(Integer))
        dt.Columns.Add("Overlap_Lecture", GetType(Integer))
        dt.Columns.Add("Overlap_Lect_Task", GetType(Integer))
        dt.Columns.Add("Deemed_Time_Before", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Time_After", GetType(TimeSpan))
        dt.Columns.Add("Number_Of_Punched", GetType(Byte))
        dt.Columns.Add("Lecture_Unit_Price", GetType(Decimal))
        dt.Columns.Add("TaskBase_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Un_Break_Time", GetType(TimeSpan))
        dt.Columns.Add("Late_Night_Shift", GetType(TimeSpan))

        ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
        dt.Columns.Add("Lecture_Count", GetType(Integer))
        dt.Columns.Add("Daily_Rewards", GetType(Decimal))
        dt.Columns.Add("Lecture_Fee", GetType(Decimal))
        dt.Columns.Add("Work_Salary", GetType(Decimal))

        ' 日別報酬リスト：実績コマ回数で使用する。
        For i As Integer = 0 To 6 - 1
            dt.Columns.Add("Grade_Count" & (i + 1).ToString(), GetType(Integer))
        Next

        ' グループ毎に DTO 型を登録
        Dim groupInfo As New Dictionary(Of String, Type) From {
            {"A", GetType(LectureWorkItem)},
            {"B", GetType(TaskWorkItem)},
            {"C", GetType(OthersWorkItem)}
        }

        ' グループ毎に列を作成（コマ１～コマ６のコマ情報）
        For Each grp As String In groupInfo.Keys
            Dim props = groupInfo(grp).GetProperties(BindingFlags.Public Or BindingFlags.Instance)

            For i As Integer = 1 To 6
                For Each p As PropertyInfo In props
                    Dim colName As String = grp & p.Name & i

                    Dim colType As Type = p.PropertyType
                    If colType.IsGenericType AndAlso colType.GetGenericTypeDefinition() Is GetType(Nullable(Of )) Then
                        colType = colType.GetGenericArguments()(0)
                    End If

                    dt.Columns.Add(colName, colType)
                Next
            Next
        Next

#End Region

#Region "Data投入"

        Dim periodToday As String = DateUtil.DateToFormatString(Date.Today, "yyyyMMdd")
        Dim periodStart As String = DateUtil.DateToFormatString(param.SearchStartDate, "yyyyMMdd")
        Dim periodEnd As String = DateUtil.DateToFormatString(param.SearchEndDate, "yyyyMMdd")

        '--- 行追加 ---
        Dim StatusList As List(Of ValidationRuleResult)
        Dim statusLevel As String = ""
        Dim statusMessage As String = ""
        For Each w In modelList
            ' 対象期間外の日付は、スキップ
            If (w.DateKey Is Nothing OrElse
                w.DateKey < periodStart OrElse
                w.DateKey > periodEnd OrElse
                w.DateKey > periodToday) Then
                Continue For
            End If

            ' ステータス情報がない場合スキップ
            If (w.StatusList Is Nothing OrElse w.StatusList.Count <= 0) Then
                Continue For
            End If

            ' 状態指定あり
            If StringUtil.IsNotNullOrWhiteSpace(param.RuleId) Then
                ' 指定状態のデータを検索
                StatusList = w.StatusList.Where(Function(r) r.RuleId = param.RuleId).ToList()
            Else
                ' エラーのみ表示
                If param.ErrorOnly Then
                    ' 状態のレベル：エラーのものだけ
                    StatusList = w.StatusList.Where(Function(r) r.Level = ValidationLevel.ErrorLevel).ToList()
                Else
                    ' 状態レベル：あるもの
                    StatusList = w.StatusList.ToList()
                End If
            End If

            ' 指定状態のものがない場合スキップ
            If StatusList.Count <= 0 Then
                Continue For
            End If

            ' 優先順位の一番高いものを取得
            statusLevel = StatusList(0).LevelString
            statusMessage = StatusList(0).Message

            Dim row = dt.NewRow()

                ' 打刻等の時間情報関連
                row("DateStr") = ToStringSafe(w.DateStr)
                row("DateKey") = ToStringSafe(w.DateKey)
                row("DateColor") = ToStringSafe(w.DateColor)
                row("StatusLevel") = statusLevel
                row("StatusStr") = statusMessage
                row("Lecture_Date") = ToDateSafe(w.LectureDate)
                row("Teacher_Code") = ToStringSafe(w.TeacherCode)
                row("Teacher_Name") = ToStringSafe(w.TeacherName)
                row("Punch_Start_Time") = ToTimeSpanSafe(w.PunchStartTime)
                row("Punch_End_Time") = ToTimeSpanSafe(w.PunchEndTime)
                row("Lecture_Start") = ToTimeSpanSafe(w.LectureStart)
                row("Lecture_End") = ToTimeSpanSafe(w.LectureEnd)
                row("Task_Start") = ToTimeSpanSafe(w.TaskStart)
                row("Task_End") = ToTimeSpanSafe(w.TaskEnd)
                row("Work_Start_Time") = ToTimeSpanSafe(w.WorkStartTime)
                row("Work_End_Time") = ToTimeSpanSafe(w.WorkEndTime)
                row("Deemed_Start_Time") = ToTimeSpanSafe(w.DeemedStartTime)
                row("Deemed_End_Time") = ToTimeSpanSafe(w.DeemedEndTime)
                row("Deemed_Hours") = ToTimeSpanSafe(w.DeemedHours)
                row("Deemed_Hour_Time") = ToDecimalSafe(w.DeemedHourTime)

                ' 打刻等の時間外の情報
                row("Overlap_Other") = ToIntSafe(w.OverlapOther)
                row("Overlap_Lecture") = ToIntSafe(w.OverlapLecture)
                row("Overlap_Lect_Task") = ToIntSafe(w.OverlapLectTask)
                row("Deemed_Time_Before") = ToTimeSpanSafe(w.DeemedTimeBefore)
                row("Deemed_Time_After") = ToTimeSpanSafe(w.DeemedTimeAfter)
                row("Number_Of_Punched") = ToByteSafe(w.NumberOfPunched)
                row("Lecture_Unit_Price") = ToDecimalSafe(w.LectureUnitPrice)
                row("TaskBase_Unit_Price") = ToDecimalSafe(w.TaskBaseUnitPrice)
                row("Task_Unit_Price") = ToDecimalSafe(w.TaskUnitPrice)
                row("Task_Un_Break_Time") = ToTimeSpanSafe(w.TaskUnBreakTime)
                row("Late_Night_Shift") = ToTimeSpanSafe(w.LateNightShift)

                ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
                row("Lecture_Count") = ToIntSafe(w.LectureCount)
                row("Daily_Rewards") = ToDecimalSafe(w.DailyRewards)
                row("Lecture_Fee") = ToDecimalSafe(w.LectureFee)
                row("Work_Salary") = ToDecimalSafe(w.WorkSalary)

                ' 日別報酬リスト：実績コマ回数で使用する。
                Dim count() As Integer = w.GradeCount
                For i As Integer = 0 To 6 - 1
                    row("Grade_Count" & (i + 1).ToString()) = count(i)
                Next

                FillGroup(row, "A", w.LectureWorkItems, GetType(LectureWorkItem))
                FillGroup(row, "B", w.TaskWorkItems, GetType(TaskWorkItem))
                FillGroup(row, "C", w.OthersWorkItems, GetType(OthersWorkItem))

                dt.Rows.Add(row)
        Next

#End Region

        Return dt
    End Function

    ''' <summary>
    ''' リスト内メンバーの作成
    ''' </summary>
    ''' <param name="row">ROW</param>
    ''' <param name="groupName">グループ名</param>
    ''' <param name="list">グループ内リスト</param>
    ''' <param name="dtoType">DTOタイプ</param>
    Private Sub FillGroup(row As DataRow, groupName As String,
                          list As IList, dtoType As Type)

        If list Is Nothing Then
            Exit Sub
        End If

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        ' 0～5以内の
        For i As Integer = 0 To Math.Min(5, list.Count - 1)
            Dim item = list(i)
            ' プロパティメンバすべてを処理する
            For Each p As PropertyInfo In props
                ' グループの接頭辞作成
                Dim colName As String = groupName & p.Name & (i + 1)
                ' プロパティ値を取得
                Dim value As Object = p.GetValue(item, Nothing)
                ' 値をDataTableの項目に値を設定（Nullならば、DBNull.Value）
                If value Is Nothing Then
                    row(colName) = DBNull.Value
                Else
                    row(colName) = value
                End If
            Next
        Next
    End Sub

End Class
