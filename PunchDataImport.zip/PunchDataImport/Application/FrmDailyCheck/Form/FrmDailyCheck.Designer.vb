﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmDailyCheck
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()>
	Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.LblDataCount = New System.Windows.Forms.Label()
        Me.dgvData = New System.Windows.Forms.DataGridView()
        Me.CmbFilters = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblStartYearMonth = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblEndYearMonth = New System.Windows.Forms.Label()
        Me.cmbStartDay = New System.Windows.Forms.ComboBox()
        Me.cmbEndDay = New System.Windows.Forms.ComboBox()
        Me.lblStartYobi = New System.Windows.Forms.Label()
        Me.lblEndYobi = New System.Windows.Forms.Label()
        Me.btnSaerch = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnPrevWeek = New System.Windows.Forms.Button()
        Me.btnPrevDay = New System.Windows.Forms.Button()
        Me.btnNextWeek = New System.Windows.Forms.Button()
        Me.btnNexDay = New System.Windows.Forms.Button()
        Me.btnToday = New System.Windows.Forms.Button()
        Me.btnExcel = New System.Windows.Forms.Button()
        Me.chkErrorOnly = New System.Windows.Forms.CheckBox()
        CType(Me.dgvData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LblDataCount
        '
        Me.LblDataCount.AutoSize = True
        Me.LblDataCount.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.LblDataCount.Location = New System.Drawing.Point(762, 64)
        Me.LblDataCount.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblDataCount.Name = "LblDataCount"
        Me.LblDataCount.Size = New System.Drawing.Size(26, 21)
        Me.LblDataCount.TabIndex = 12
        Me.LblDataCount.Text = "件"
        Me.LblDataCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dgvData
        '
        Me.dgvData.AllowUserToAddRows = False
        Me.dgvData.AllowUserToDeleteRows = False
        Me.dgvData.AllowUserToResizeRows = False
        Me.dgvData.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgvData.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvData.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvData.ColumnHeadersHeight = 24
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvData.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dgvData.Location = New System.Drawing.Point(20, 93)
        Me.dgvData.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvData.Name = "dgvData"
        Me.dgvData.ReadOnly = True
        Me.dgvData.RowHeadersWidth = 20
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        Me.dgvData.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvData.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.dgvData.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.SystemColors.ControlText
        Me.dgvData.RowTemplate.Height = 21
        Me.dgvData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvData.Size = New System.Drawing.Size(990, 887)
        Me.dgvData.TabIndex = 13
        '
        'CmbFilters
        '
        Me.CmbFilters.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbFilters.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CmbFilters.FormattingEnabled = True
        Me.CmbFilters.Location = New System.Drawing.Point(234, 60)
        Me.CmbFilters.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbFilters.Name = "CmbFilters"
        Me.CmbFilters.Size = New System.Drawing.Size(267, 25)
        Me.CmbFilters.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(690, 64)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 21)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "件数："
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(20, 15)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "期間"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(184, 64)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 21)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "状態"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblStartYearMonth
        '
        Me.lblStartYearMonth.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblStartYearMonth.Location = New System.Drawing.Point(70, 11)
        Me.lblStartYearMonth.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStartYearMonth.Name = "lblStartYearMonth"
        Me.lblStartYearMonth.Size = New System.Drawing.Size(98, 24)
        Me.lblStartYearMonth.TabIndex = 1
        Me.lblStartYearMonth.Text = "2025年05月"
        Me.lblStartYearMonth.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("游ゴシック", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(254, 11)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(27, 24)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "～"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEndYearMonth
        '
        Me.lblEndYearMonth.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblEndYearMonth.Location = New System.Drawing.Point(280, 11)
        Me.lblEndYearMonth.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblEndYearMonth.Name = "lblEndYearMonth"
        Me.lblEndYearMonth.Size = New System.Drawing.Size(103, 24)
        Me.lblEndYearMonth.TabIndex = 5
        Me.lblEndYearMonth.Text = "2025年05月"
        Me.lblEndYearMonth.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmbStartDay
        '
        Me.cmbStartDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStartDay.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmbStartDay.FormattingEnabled = True
        Me.cmbStartDay.Location = New System.Drawing.Point(161, 11)
        Me.cmbStartDay.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbStartDay.Name = "cmbStartDay"
        Me.cmbStartDay.Size = New System.Drawing.Size(41, 25)
        Me.cmbStartDay.TabIndex = 2
        '
        'cmbEndDay
        '
        Me.cmbEndDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbEndDay.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmbEndDay.FormattingEnabled = True
        Me.cmbEndDay.Location = New System.Drawing.Point(371, 10)
        Me.cmbEndDay.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbEndDay.Name = "cmbEndDay"
        Me.cmbEndDay.Size = New System.Drawing.Size(41, 25)
        Me.cmbEndDay.TabIndex = 6
        '
        'lblStartYobi
        '
        Me.lblStartYobi.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblStartYobi.Location = New System.Drawing.Point(199, 11)
        Me.lblStartYobi.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStartYobi.Name = "lblStartYobi"
        Me.lblStartYobi.Size = New System.Drawing.Size(74, 24)
        Me.lblStartYobi.TabIndex = 3
        Me.lblStartYobi.Text = "日(　)"
        Me.lblStartYobi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblEndYobi
        '
        Me.lblEndYobi.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblEndYobi.Location = New System.Drawing.Point(409, 11)
        Me.lblEndYobi.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblEndYobi.Name = "lblEndYobi"
        Me.lblEndYobi.Size = New System.Drawing.Size(62, 24)
        Me.lblEndYobi.TabIndex = 7
        Me.lblEndYobi.Text = "日(　)"
        Me.lblEndYobi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSaerch
        '
        Me.btnSaerch.Font = New System.Drawing.Font("游ゴシック", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnSaerch.Location = New System.Drawing.Point(479, 10)
        Me.btnSaerch.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSaerch.Name = "btnSaerch"
        Me.btnSaerch.Size = New System.Drawing.Size(68, 28)
        Me.btnSaerch.TabIndex = 8
        Me.btnSaerch.Text = "検索"
        Me.btnSaerch.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label9.Location = New System.Drawing.Point(16, 64)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(138, 21)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "【打刻忘れ一覧】"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnPrevWeek
        '
        Me.btnPrevWeek.Font = New System.Drawing.Font("游ゴシック", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnPrevWeek.Location = New System.Drawing.Point(692, 10)
        Me.btnPrevWeek.Name = "btnPrevWeek"
        Me.btnPrevWeek.Size = New System.Drawing.Size(62, 28)
        Me.btnPrevWeek.TabIndex = 20
        Me.btnPrevWeek.Text = "≪前週"
        Me.btnPrevWeek.UseVisualStyleBackColor = True
        '
        'btnPrevDay
        '
        Me.btnPrevDay.Font = New System.Drawing.Font("游ゴシック", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnPrevDay.Location = New System.Drawing.Point(756, 10)
        Me.btnPrevDay.Name = "btnPrevDay"
        Me.btnPrevDay.Size = New System.Drawing.Size(62, 28)
        Me.btnPrevDay.TabIndex = 21
        Me.btnPrevDay.Text = "＜前日"
        Me.btnPrevDay.UseVisualStyleBackColor = True
        '
        'btnNextWeek
        '
        Me.btnNextWeek.Font = New System.Drawing.Font("游ゴシック", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnNextWeek.Location = New System.Drawing.Point(948, 10)
        Me.btnNextWeek.Name = "btnNextWeek"
        Me.btnNextWeek.Size = New System.Drawing.Size(62, 28)
        Me.btnNextWeek.TabIndex = 23
        Me.btnNextWeek.Text = "翌週≫"
        Me.btnNextWeek.UseVisualStyleBackColor = True
        '
        'btnNexDay
        '
        Me.btnNexDay.Font = New System.Drawing.Font("游ゴシック", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnNexDay.Location = New System.Drawing.Point(884, 10)
        Me.btnNexDay.Name = "btnNexDay"
        Me.btnNexDay.Size = New System.Drawing.Size(62, 28)
        Me.btnNexDay.TabIndex = 22
        Me.btnNexDay.Text = "翌日＞"
        Me.btnNexDay.UseVisualStyleBackColor = True
        '
        'btnToday
        '
        Me.btnToday.Font = New System.Drawing.Font("游ゴシック", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnToday.Location = New System.Drawing.Point(820, 10)
        Me.btnToday.Name = "btnToday"
        Me.btnToday.Size = New System.Drawing.Size(62, 28)
        Me.btnToday.TabIndex = 24
        Me.btnToday.Text = "今日"
        Me.btnToday.UseVisualStyleBackColor = True
        '
        'btnExcel
        '
        Me.btnExcel.Location = New System.Drawing.Point(903, 58)
        Me.btnExcel.Name = "btnExcel"
        Me.btnExcel.Size = New System.Drawing.Size(107, 30)
        Me.btnExcel.TabIndex = 27
        Me.btnExcel.Text = "EXCEL出力"
        Me.btnExcel.UseVisualStyleBackColor = True
        '
        'chkErrorOnly
        '
        Me.chkErrorOnly.AutoSize = True
        Me.chkErrorOnly.Location = New System.Drawing.Point(531, 64)
        Me.chkErrorOnly.Name = "chkErrorOnly"
        Me.chkErrorOnly.Size = New System.Drawing.Size(118, 21)
        Me.chkErrorOnly.TabIndex = 28
        Me.chkErrorOnly.Text = "エラーのみ表示"
        Me.chkErrorOnly.UseVisualStyleBackColor = True
        '
        'FrmDailyCheck
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1030, 991)
        Me.Controls.Add(Me.chkErrorOnly)
        Me.Controls.Add(Me.cmbEndDay)
        Me.Controls.Add(Me.btnExcel)
        Me.Controls.Add(Me.btnToday)
        Me.Controls.Add(Me.btnNextWeek)
        Me.Controls.Add(Me.btnNexDay)
        Me.Controls.Add(Me.btnPrevDay)
        Me.Controls.Add(Me.btnPrevWeek)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.btnSaerch)
        Me.Controls.Add(Me.cmbStartDay)
        Me.Controls.Add(Me.lblEndYearMonth)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblStartYearMonth)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CmbFilters)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LblDataCount)
        Me.Controls.Add(Me.dgvData)
        Me.Controls.Add(Me.lblEndYobi)
        Me.Controls.Add(Me.lblStartYobi)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmDailyCheck"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "打刻忘れ一覧"
        CType(Me.dgvData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblDataCount As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents CmbFilters As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblStartYearMonth As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblEndYearMonth As Label
    Friend WithEvents cmbStartDay As ComboBox
    Friend WithEvents cmbEndDay As ComboBox
    Friend WithEvents lblStartYobi As Label
    Friend WithEvents lblEndYobi As Label
    Friend WithEvents btnSaerch As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents btnPrevWeek As Button
    Friend WithEvents btnPrevDay As Button
    Friend WithEvents btnNextWeek As Button
    Friend WithEvents btnNexDay As Button
    Friend WithEvents btnToday As Button
    Friend WithEvents btnExcel As Button
    Friend WithEvents chkErrorOnly As CheckBox
    Public WithEvents dgvData As DataGridView
End Class
