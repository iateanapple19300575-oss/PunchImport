﻿''' <summary>
''' 月別報酬リストシート出力
''' </summary>
Public Class RptPageMonthly
  Inherits VBReportPage

#Region "[定数]"

  ' ページタイトル名
  Private Const REPORT_PAGE_NAME As String = "月別報酬リスト（{0}年{1}月度）"

  ' ページタイトルの変数名
  Private Const REPORT_SHEET_NAME As String = "CHECK_MONTHLY"

  ' ページタイトル出力項目の変数
  Private Const REPORT_PAGE_TITLE As String = "**TITLE"

  ' 出力項目変数
  Private Const SQL_COL_TEACHER_CODE As String = "講師コード"
  Private Const SQL_COL_TEACHER_NAME As String = "講師名"
  Private Const SQL_COL_TOTAL_HOURS As String = "勤務時間"
  Private Const SQL_COL_TOTAL_AMOUNT As String = "報酬額合計"
  Private Const SQL_COL_KOMA_AMOUNT As String = "授業給合計"
  Private Const SQL_COL_BASIC_AMOUNT As String = "業務給合計"
  Private Const SQL_COL_KOMA_COUNT As String = "コマ数合計"

  ' 基本セル書式参照セル
  Private Const FMT_CELL_TEACHER_CODE As String = "**TeacherCode"
  Private Const FMT_CELL_TEACHER_NAME As String = "**TeacherName"
  Private Const FMT_CELL_TOTAL_HOUR As String = "**Time_Minashi"
  Private Const FMT_CELL_TOTAL_AMOUNT As String = "**TotalAmount"
  Private Const FMT_CELL_BASIC_AMOUNT As String = "**BasicAmount"
  Private Const FMT_CELL_KOMA_AMOUNT As String = "**KomaAmount"
  Private Const FMT_CELL_KOMA_COUNT As String = "**KomaCount"

  ' 出力項目対応テーブル項目名
  Private Const ATTR_CELL_TEACHER_CODE As String = "B6"
  Private Const ATTR_CELL_TEACHER_NAME As String = "C6"
  Private Const ATTR_CELL_TOTAL_HOUR As String = "D6"
  Private Const ATTR_CELL_BASIC_AMOUNT As String = "E6"
  Private Const ATTR_CELL_TOTAL_AMOUNT As String = "F6"
  Private Const ATTR_CELL_KOMA_AMOUNT As String = "G6"
  Private Const ATTR_CELL_KOMA_COUNT As String = "H6"

#End Region

#Region "[プロパティ]"

  ''' <summary>
  ''' ページタイトルセル
  ''' </summary>
  ''' <returns></returns>
  Protected Overrides ReadOnly Property PageTitleCell As String
    Get
      Return REPORT_PAGE_TITLE
    End Get
  End Property

  ''' <summary>
  ''' ページタイトル名
  ''' </summary>
  ''' <returns></returns>
  Protected Overrides ReadOnly Property PageTitleName As String
    Get
      Return REPORT_PAGE_NAME
    End Get
  End Property

  ''' <summary>
  ''' シート名
  ''' </summary>
  ''' <returns></returns>
  Protected Overrides ReadOnly Property PageSheetName As String
    Get
      Return REPORT_SHEET_NAME
    End Get
  End Property

  ''' <summary>
  ''' 基本報酬単価
  ''' </summary>
  ''' <returns></returns>
  Private Property UnitPrice As Double

  ''' <summary>
  ''' みなし時間(分)
  ''' </summary>
  ''' <returns></returns>
  Private Property TimeSpan As Integer


#End Region

#Region "[メソッド]"

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="targetDate"></param>
  Public Sub New(ByVal targetDate As Date)
    MyBase.New(targetDate)
  End Sub

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="targetDate"></param>
  Public Sub New(ByVal targetDate As Date, ByVal reportSourceDataTable As DataTable)
    MyBase.New(targetDate, reportSourceDataTable)
  End Sub

  ''' <summary>
  ''' 初期設定
  ''' </summary>
  Public Overrides Sub InitialSetup()
    m_PageName = String.Format(REPORT_PAGE_NAME, Year(MyBase.TargetDate), Month(MyBase.TargetDate))
    m_SheetName = REPORT_SHEET_NAME
  End Sub

  ''' <summary>
  ''' 出力データ取得クエリ
  ''' </summary>
  ''' <returns></returns>
  Public Overrides Function ReportQuery() As String
    Return MonthlyListQuery.SelectSql(MyBase.TargetDate)
  End Function

  ''' <summary>
  ''' ページデータ出力
  ''' </summary>
  Public Overrides Sub PageOutput()
    OutputDetail(ReportSourceDataTable)
  End Sub

  ''' <summary>
  ''' 明細出力
  ''' </summary>
  ''' <param name="dtTable"></param>
  Public Overrides Sub OutputDetail(ByVal dtTable As DataTable)
    Dim cellUtil As New CellReportUtil(m_CellReport)
    Dim rowNo As Integer = 0

    For Each row As DataRow In dtTable.Rows
      With m_CellReport
        cellUtil.CellValue(FMT_CELL_TEACHER_CODE, 0, rowNo, GetValue(row(SQL_COL_TEACHER_CODE)), ATTR_CELL_TEACHER_CODE)
        cellUtil.CellValue(FMT_CELL_TEACHER_NAME, 0, rowNo, GetValue(row(SQL_COL_TEACHER_NAME)), ATTR_CELL_TEACHER_NAME)
        cellUtil.CellValue(FMT_CELL_TOTAL_HOUR, 0, rowNo, GetValue(row(SQL_COL_TOTAL_HOURS)), ATTR_CELL_TOTAL_HOUR)
        cellUtil.CellValue(FMT_CELL_TOTAL_AMOUNT, 0, rowNo, GetValue(row(SQL_COL_TOTAL_AMOUNT)), ATTR_CELL_TOTAL_AMOUNT)
        cellUtil.CellValue(FMT_CELL_BASIC_AMOUNT, 0, rowNo, GetValue(row(SQL_COL_BASIC_AMOUNT)), ATTR_CELL_BASIC_AMOUNT)
        cellUtil.CellValue(FMT_CELL_KOMA_AMOUNT, 0, rowNo, GetValue(row(SQL_COL_KOMA_AMOUNT)), ATTR_CELL_KOMA_AMOUNT)
        cellUtil.CellValue(FMT_CELL_KOMA_COUNT, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT)), ATTR_CELL_KOMA_COUNT)
        rowNo = rowNo + 1
      End With
    Next
  End Sub

#End Region

End Class
