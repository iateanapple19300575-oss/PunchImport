﻿''' <summary>
''' 日別報酬リストシート出力
''' </summary>
Public Class RptPageDaylyList
    Inherits VBReportPage

#Region "[定数]"

    ' ページタイトル名
    Private Const REPORT_PAGE_NAME As String = "日別報酬リスト（{0}年{1}月度）"

    ' ページタイトルの変数名
    Private Const REPORT_SHEET_NAME As String = "CHECK_DAYLY"

    ' ページタイトル出力項目の変数
    Private Const REPORT_PAGE_TITLE As String = "**TITLE"

    ' 出力項目変数
    Private Const FMT_CELL_BASE_UNIT_PRICE As String = "**BaseUnitPrice"
    Private Const FMT_CELL_TEACHER_CODE As String = "**TeacherCode"
    Private Const FMT_CELL_TEACHER_NAME As String = "**TeacherName"
    Private Const FMT_CELL_LECTURE_DATE As String = "**LectureDate"
    Private Const FMT_CELL_CHECK_STATUS As String = "**Status"
    Private Const FMT_CELL_ST_JOBKAN As String = "**St_Jobkan"
    Private Const FMT_CELL_ED_JOBKAN As String = "**Ed_Jobkan"
    Private Const FMT_CELL_ST_MINASHI As String = "**St_Minashi"
    Private Const FMT_CELL_ED_MINASHI As String = "**Ed_Minashi"
    Private Const FMT_CELL_ST_ACTUAL As String = "**St_Actual"
    Private Const FMT_CELL_ED_ACTUAL As String = "**Ed_Actual"
    Private Const FMT_CELL_ST_REQUEST As String = "**St_Request"
    Private Const FMT_CELL_ED_REQUEST As String = "**Ed_Request"
    Private Const FMT_CELL_TOTAL_AMOUNT As String = "**TotalAmount"
    Private Const FMT_CELL_TOTAL_HOUR As String = "**Time_Minashi"
    Private Const FMT_CELL_BASIC_AMOUNT As String = "**BasicAmount"
    Private Const FMT_CELL_KOMA_COUNT_1 As String = "**KomaCount1"
    Private Const FMT_CELL_KOMA_COUNT_2 As String = "**KomaCount2"
    Private Const FMT_CELL_KOMA_COUNT_3 As String = "**KomaCount3"
    Private Const FMT_CELL_KOMA_COUNT_4 As String = "**KomaCount4"
    Private Const FMT_CELL_KOMA_COUNT_5 As String = "**KomaCount5"
    Private Const FMT_CELL_KOMA_COUNT_6 As String = "**KomaCount6"
    Private Const FMT_CELL_KOMA_COUNT_T As String = "**KomaCount"
    Private Const FMT_CELL_KOMA_AMOUNTT As String = "**KomaAmount"
    Private Const FMT_CELL_REQUEST_AMOUNT As String = "**RequestAmount"
    ' 交通費
    Private Const FMT_CELL_TRANS_EXP_TOTAL As String = "**TransExpTotal"
    Private Const FMT_CELL_TRANS_EXP_SITE1 As String = "**TransExpSite1"
    Private Const FMT_CELL_TRANS_EXP_AMOUNT1 As String = "**TransExpAmount1"
    Private Const FMT_CELL_TRANS_EXP_SITE2 As String = "**TransExpSite2"
    Private Const FMT_CELL_TRANS_EXP_AMOUNT2 As String = "**TransExpAmount2"
    Private Const FMT_CELL_TRANS_EXP_SITE3 As String = "**TransExpSite3"
    Private Const FMT_CELL_TRANS_EXP_AMOUNT3 As String = "**TransExpAmount3"
    Private Const FMT_CELL_TRANS_EXP_SITE4 As String = "**TransExpSite4"
    Private Const FMT_CELL_TRANS_EXP_AMOUNT4 As String = "**TransExpAmount4"
    Private Const FMT_CELL_TRANS_EXP_SITE5 As String = "**TransExpSite5"
    Private Const FMT_CELL_TRANS_EXP_AMOUNT5 As String = "**TransExpAmount5"
    Private Const FMT_CELL_TRANS_EXP_REMARKS As String = "**TransExpRemarks"

    ' 基本セル書式参照セル
    Private Const ATTR_CELL_BASE_UNIT_PRICE As String = "O5"
    Private Const ATTR_CELL_TEACHER_CODE As String = "B6"
    Private Const ATTR_CELL_TEACHER_NAME As String = "C6"
    Private Const ATTR_CELL_LECTURE_DATE As String = "D6"
    Private Const ATTR_CELL_ST_JOBKAN As String = "E6"
    Private Const ATTR_CELL_ED_JOBKAN As String = "F6"
    Private Const ATTR_CELL_ST_MINASHI As String = "G6"
    Private Const ATTR_CELL_ED_MINASHI As String = "H6"
    Private Const ATTR_CELL_ST_ACTUAL As String = "I6"
    Private Const ATTR_CELL_ED_ACTUAL As String = "J6"
    Private Const ATTR_CELL_ST_REQUEST As String = "K6"
    Private Const ATTR_CELL_ED_REQUEST As String = "L6"
    Private Const ATTR_CELL_TOTAL_AMOUNT As String = "N6"
    Private Const ATTR_CELL_TOTAL_HOUR As String = "O6"
    Private Const ATTR_CELL_BASIC_AMOUNT As String = "P6"
    Private Const ATTR_CELL_KOMA_COUNT_1 As String = "Q6"
    Private Const ATTR_CELL_KOMA_COUNT_2 As String = "R6"
    Private Const ATTR_CELL_KOMA_COUNT_3 As String = "S6"
    Private Const ATTR_CELL_KOMA_COUNT_4 As String = "T6"
    Private Const ATTR_CELL_KOMA_COUNT_5 As String = "U6"
    Private Const ATTR_CELL_KOMA_COUNT_6 As String = "V6"
    Private Const ATTR_CELL_KOMA_COUNT_T As String = "W6"
    Private Const ATTR_CELL_KOMA_AMOUNTT As String = "X6"

    ' 交通費
    Private Const ATTR_CELL_TRANS_EXP_TOTAL As String = "Z6"
    Private Const ATTR_CELL_TRANS_EXP_SITE1 As String = "AA6"
    Private Const ATTR_CELL_TRANS_EXP_AMOUNT1 As String = "AB6"
    Private Const ATTR_CELL_TRANS_EXP_SITE2 As String = "AC6"
    Private Const ATTR_CELL_TRANS_EXP_AMOUNT2 As String = "AD6"
    Private Const ATTR_CELL_TRANS_EXP_SITE3 As String = "AE6"
    Private Const ATTR_CELL_TRANS_EXP_AMOUNT3 As String = "AF6"
    Private Const ATTR_CELL_TRANS_EXP_SITE4 As String = "AG6"
    Private Const ATTR_CELL_TRANS_EXP_AMOUNT4 As String = "AH6"
    Private Const ATTR_CELL_TRANS_EXP_SITE5 As String = "AI6"
    Private Const ATTR_CELL_TRANS_EXP_AMOUNT5 As String = "AJ6"
    Private Const ATTR_CELL_TRANS_EXP_REMARKS As String = "AK6"

    ' 出力項目対応テーブル項目名
    Private Const SQL_COL_TEACHER_CODE As String = "Teacher_Code"
    Private Const SQL_COL_TEACHER_NAME As String = "Teacher_Name"
    Private Const SQL_COL_LECTURE_DATE As String = "Lecture_Date"
    Private Const SQL_COL_CHECK_STATUS As String = "StatusStr"
    Private Const SQL_COL_ST_JOBKAN As String = "Punch_Start_Time"
    Private Const SQL_COL_ED_JOBKAN As String = "Punch_End_Time"
    Private Const SQL_COL_ST_MINASHI As String = "Deemed_Start_Time"
    Private Const SQL_COL_ED_MINASHI As String = "Deemed_End_Time"
    Private Const SQL_COL_TOTAL_HOUR As String = "Deemed_Hours"
    Private Const SQL_COL_TOTAL_HOUR_VALUE As String = "Deemed_Hour_Time"
    Private Const SQL_COL_ST_ACTUAL As String = "Lecture_Start"
    Private Const SQL_COL_ED_ACTUAL As String = "Lecture_End"
    Private Const SQL_COL_ST_REQUEST As String = "Task_Start"
    Private Const SQL_COL_ED_REQUEST As String = "Task_End"
    Private Const SQL_COL_KOMA_COUNT_1 As String = "Grade_Count1"
    Private Const SQL_COL_KOMA_COUNT_2 As String = "Grade_Count2"
    Private Const SQL_COL_KOMA_COUNT_3 As String = "Grade_Count3"
    Private Const SQL_COL_KOMA_COUNT_4 As String = "Grade_Count4"
    Private Const SQL_COL_KOMA_COUNT_5 As String = "Grade_Count5"
    Private Const SQL_COL_KOMA_COUNT_6 As String = "Grade_Count6"
    Private Const SQL_COL_KOMA_T_AMOUNT As String = "Lecture_Unit_Price"
    Private Const SQL_COL_KOMA_COUNT_T As String = "Lecture_Count"
    Private Const SQL_COL_KOMA_AMOUNTT As String = "Lecture_Fee"

    Private Const SQL_COL_TOTAL_AMOUNT As String = "Daily_Rewards"
    Private Const SQL_COL_BASIC_AMOUNT As String = "Work_Salary"

    ' 交通費
    Private Const SQL_COL_TRANS_EXP_TOTAL As String = "Trans_Exp_Total"
    'Private Const SQL_COL_TRANS_EXP_SITE As String = "Trans_Exp_Site"
    'Private Const SQL_COL_TRANS_EXP_AMOUNT As String = "Trans_Exp_Amount"

    Private Const SQL_COL_TRANS_EXP_SITE1 As String = "Trans_Exp_Site1"
    Private Const SQL_COL_TRANS_EXP_AMOUNT1 As String = "Trans_Exp_Amount1"
    Private Const SQL_COL_TRANS_EXP_SITE2 As String = "Trans_Exp_Site2"
    Private Const SQL_COL_TRANS_EXP_AMOUNT2 As String = "Trans_Exp_Amount2"
    Private Const SQL_COL_TRANS_EXP_SITE3 As String = "Trans_Exp_Site3"
    Private Const SQL_COL_TRANS_EXP_AMOUNT3 As String = "Trans_Exp_Amount3"
    Private Const SQL_COL_TRANS_EXP_SITE4 As String = "Trans_Exp_Site4"
    Private Const SQL_COL_TRANS_EXP_AMOUNT4 As String = "Trans_Exp_Amount4"
    Private Const SQL_COL_TRANS_EXP_SITE5 As String = "Trans_Exp_Site5"
    Private Const SQL_COL_TRANS_EXP_AMOUNT5 As String = "Trans_Exp_Amount5"
    Private Const SQL_COL_TRANS_EXP_REMARKS As String = "Trans_Exp_Remarks"

    ' 交通費一覧の教室１セル(列)
    Private Const CELL_COL_OFFSET_SITE1 As Integer = 27

    ' 交通費一覧の教室１セル(行)
    Private Const CELL_ROW_OFFSET_SITE1 As Integer = 6

#End Region

#Region "[プロパティ]"

    ''' <summary>
    ''' ページタイトルセル
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageTitleCell As String
        Get
            Return REPORT_PAGE_TITLE
        End Get
    End Property

    ''' <summary>
    ''' ページタイトル名
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageTitleName As String
        Get
            Return REPORT_PAGE_NAME
        End Get
    End Property

    ''' <summary>
    ''' シート名
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageSheetName As String
        Get
            Return REPORT_SHEET_NAME
        End Get
    End Property

#End Region

#Region "[メソッド]"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    Public Sub New(ByVal targetDate As Date)
        MyBase.New(targetDate)
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    Public Sub New(ByVal targetDate As Date, ByVal reportSourceDataTable As DataTable)
        MyBase.New(targetDate, reportSourceDataTable)
    End Sub

    ''' <summary>
    ''' 初期設定
    ''' </summary>
    Public Overrides Sub InitialSetup()
        m_PageName = String.Format(REPORT_PAGE_NAME, Year(MyBase.TargetDate), Month(MyBase.TargetDate))
        m_SheetName = REPORT_SHEET_NAME
    End Sub

    ''' <summary>
    ''' 出力データ取得クエリ
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function ReportQuery() As String
        Return StampListQuery.SelectSql(MyBase.TargetDate)
    End Function

    ''' <summary>
    ''' ページデータ出力
    ''' </summary>
    Public Overrides Sub PageOutput()
        OutputDetail(ReportSourceDataTable)
    End Sub

    ''' <summary>
    ''' 明細出力
    ''' </summary>
    ''' <param name="dtTable"></param>
    Public Overrides Sub OutputDetail(ByVal dtTable As DataTable)
        Dim cellUtil As New CellReportUtil(m_CellReport)
        Dim rowNo As Integer = 0

        For Each row As DataRow In dtTable.Rows

            With m_CellReport
                ' --------------------
                ' 明細行の出力
                ' --------------------
                ' --- 勤怠関連 ---
                cellUtil.CellValue(FMT_CELL_TEACHER_CODE, 0, rowNo, GetValue(row(SQL_COL_TEACHER_CODE)), ATTR_CELL_TEACHER_CODE)
                cellUtil.CellValue(FMT_CELL_TEACHER_NAME, 0, rowNo, GetValue(row(SQL_COL_TEACHER_NAME)), ATTR_CELL_TEACHER_NAME)
                cellUtil.CellValueDateFormat(FMT_CELL_LECTURE_DATE, 0, rowNo, GetValue(row(SQL_COL_LECTURE_DATE)), ATTR_CELL_LECTURE_DATE)
                cellUtil.CellValueTimeFormat(FMT_CELL_ST_JOBKAN, 0, rowNo, GetValue(row(SQL_COL_ST_JOBKAN)), ATTR_CELL_ST_JOBKAN)
                cellUtil.CellValueTimeFormat(FMT_CELL_ED_JOBKAN, 0, rowNo, GetValue(row(SQL_COL_ED_JOBKAN)), ATTR_CELL_ED_JOBKAN)
                cellUtil.CellValueTimeFormat(FMT_CELL_ST_MINASHI, 0, rowNo, GetValue(row(SQL_COL_ST_MINASHI)), ATTR_CELL_ST_MINASHI)
                cellUtil.CellValueTimeFormat(FMT_CELL_ED_MINASHI, 0, rowNo, GetValue(row(SQL_COL_ED_MINASHI)), ATTR_CELL_ED_MINASHI)
                cellUtil.CellValueTimeFormat(FMT_CELL_ST_ACTUAL, 0, rowNo, GetValue(row(SQL_COL_ST_ACTUAL)), ATTR_CELL_ST_ACTUAL)
                cellUtil.CellValueTimeFormat(FMT_CELL_ED_ACTUAL, 0, rowNo, GetValue(row(SQL_COL_ED_ACTUAL)), ATTR_CELL_ED_ACTUAL)
                cellUtil.CellValueTimeFormat(FMT_CELL_ST_REQUEST, 0, rowNo, GetValue(row(SQL_COL_ST_REQUEST)), ATTR_CELL_ST_REQUEST)
                cellUtil.CellValueTimeFormat(FMT_CELL_ED_REQUEST, 0, rowNo, GetValue(row(SQL_COL_ED_REQUEST)), ATTR_CELL_ED_REQUEST)

                ' --- 報酬額関連 ---
                cellUtil.CellValue(FMT_CELL_TOTAL_HOUR, 0, rowNo, GetValue(row(SQL_COL_TOTAL_HOUR_VALUE)), ATTR_CELL_TOTAL_HOUR)
                cellUtil.CellValue(FMT_CELL_BASIC_AMOUNT, 0, rowNo, GetValue(row(SQL_COL_BASIC_AMOUNT)), ATTR_CELL_BASIC_AMOUNT)
                cellUtil.CellValue(FMT_CELL_TOTAL_AMOUNT, 0, rowNo, GetValue(row(SQL_COL_TOTAL_AMOUNT)), ATTR_CELL_TOTAL_AMOUNT)
                cellUtil.CellValue(FMT_CELL_KOMA_COUNT_1, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT_1)), ATTR_CELL_KOMA_COUNT_1)
                cellUtil.CellValue(FMT_CELL_KOMA_COUNT_2, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT_2)), ATTR_CELL_KOMA_COUNT_2)
                cellUtil.CellValue(FMT_CELL_KOMA_COUNT_3, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT_3)), ATTR_CELL_KOMA_COUNT_3)
                cellUtil.CellValue(FMT_CELL_KOMA_COUNT_4, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT_4)), ATTR_CELL_KOMA_COUNT_4)
                cellUtil.CellValue(FMT_CELL_KOMA_COUNT_5, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT_5)), ATTR_CELL_KOMA_COUNT_5)
                cellUtil.CellValue(FMT_CELL_KOMA_COUNT_6, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT_6)), ATTR_CELL_KOMA_COUNT_6)
                cellUtil.CellValue(FMT_CELL_KOMA_COUNT_T, 0, rowNo, GetValue(row(SQL_COL_KOMA_COUNT_T)), ATTR_CELL_KOMA_COUNT_T)

                ' 授業給
                If Not IsDBNull(row(SQL_COL_KOMA_AMOUNTT)) Then
                    Dim komaAmount As Decimal = GetValue(row(SQL_COL_KOMA_AMOUNTT))
                    komaAmount = Math.Round(komaAmount, 0, MidpointRounding.AwayFromZero)
                    cellUtil.CellValue(FMT_CELL_KOMA_AMOUNTT, 0, rowNo, komaAmount, ATTR_CELL_KOMA_AMOUNTT)
                Else
                    cellUtil.CellValue(FMT_CELL_KOMA_AMOUNTT, 0, rowNo, "", ATTR_CELL_KOMA_AMOUNTT)
                End If

                ' --- 交通費 ---
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_TOTAL, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_TOTAL)), ATTR_CELL_TRANS_EXP_TOTAL)

                'Dim columnIdx As Integer = 0
                'For i = 0 To 5 - 1
                '    cellUtil.CellValue(columnIdx, rowNo, CELL_COL_OFFSET_SITE1, CELL_ROW_OFFSET_SITE1, GetValue(row(SQL_COL_TRANS_EXP_SITE & (i + 1).ToString()))) : columnIdx += 1
                '    cellUtil.CellValue(columnIdx, rowNo, CELL_COL_OFFSET_SITE1, CELL_ROW_OFFSET_SITE1, GetValue(row(SQL_COL_TRANS_EXP_AMOUNT & (i + 1).ToString()))) : columnIdx += 1
                'Next

                cellUtil.CellValue(FMT_CELL_TRANS_EXP_SITE1, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_SITE1)), ATTR_CELL_TRANS_EXP_SITE1)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_AMOUNT1, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_AMOUNT1)), ATTR_CELL_TRANS_EXP_AMOUNT1)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_SITE2, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_SITE2)), ATTR_CELL_TRANS_EXP_SITE2)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_AMOUNT2, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_AMOUNT2)), ATTR_CELL_TRANS_EXP_AMOUNT2)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_SITE3, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_SITE3)), ATTR_CELL_TRANS_EXP_SITE3)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_AMOUNT3, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_AMOUNT3)), ATTR_CELL_TRANS_EXP_AMOUNT3)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_SITE4, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_SITE4)), ATTR_CELL_TRANS_EXP_SITE4)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_AMOUNT4, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_AMOUNT4)), ATTR_CELL_TRANS_EXP_AMOUNT4)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_SITE5, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_SITE5)), ATTR_CELL_TRANS_EXP_SITE5)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_AMOUNT5, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_AMOUNT5)), ATTR_CELL_TRANS_EXP_AMOUNT5)
                cellUtil.CellValue(FMT_CELL_TRANS_EXP_REMARKS, 0, rowNo, GetValue(row(SQL_COL_TRANS_EXP_REMARKS)), ATTR_CELL_TRANS_EXP_REMARKS)

                rowNo = rowNo + 1
            End With
        Next
    End Sub

#End Region

End Class
