﻿Imports MainApp.Data.Dto
''' <summary>
''' 出講○○EXCEL出力処理
''' </summary>
Public Class ReportLectureFee
    Inherits VBReport

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    Public Sub New(ByVal targetDate As Date, ByVal filePath As String)
        MyBase.New(targetDate, filePath)
        Me.OutputFilePath = filePath
    End Sub

    ''' <summary>
    ''' EXCEL出力
    ''' </summary>
    Public Overloads Function Output()
        Dim resultData As New ResultData()
        Dim frmVBReportsViewer As New frmVBReportsViewer

        Try
            VbReportsEnvSetting(frmVBReportsViewer.CellReport1, frmVBReportsViewer.ViewerControl1)
            Dim service As New ReportLectureFeeService(MyBase.TargetDate)
            Dim param As New LectureDetailsFindParameter
            param.TargetDate = TargetDate
            param.SearchStartDate = DateUtil.FirstDayOfMonth(param.TargetDate, "yyyy/MM/dd")
            param.SearchEndDate = DateUtil.LastDayOfMonth(param.TargetDate, "yyyy/MM/dd")
            Dim dailyListData As DataTable = service.GetDataForDataTable(param)

            ' [勤怠状況チェック]シート
            AddPage(New RptPageWorkList(MyBase.TargetDate, dailyListData))

            '[日別報酬リスト]シート
            AddPage(New RptPageDaylyList(MyBase.TargetDate, dailyListData))

            '' [月別報酬リスト]シート
            Dim monthlyListData As DataTable = GetMonthlyListData(dailyListData)
            AddPage(New RptPageMonthly(MyBase.TargetDate, monthlyListData))

            ' レポート出力
            Report()

            ' Viewerは表示しない
            'frmVBReportsViewer.ShowDialog()

            ' リソースの解放
            frmVBReportsViewer.Dispose()

            resultData.Success = True

        Catch ex As Exception
            resultData.Success = False
        End Try

        Return resultData
    End Function

    ''' <summary>
    ''' 月単位報酬データ取得
    ''' </summary>
    ''' <param name="srcDataTable">月単位報酬データ</param>
    ''' <returns></returns>
    Private Function GetMonthlyListData(ByVal srcDataTable As DataTable) As DataTable
        ' 日単位を月単位にグループ化
        Dim dailyQuery = From row In srcDataTable.AsEnumerable()
                         Group row By
                        teacherCode = row.Field(Of String)("Teacher_Code"),
                        teacherNamee = row.Field(Of String)("Teacher_Name")
                      Into g = Group
                         Select New With {
                        .講師ｺｰﾄﾞ = teacherCode,
                        .講師名 = teacherNamee,
                        .勤務時間 = g.Sum(Function(r) r.Field(Of Nullable(Of Decimal))("Deemed_Hour_Time")),
                        .報酬額合計 = g.Sum(Function(r) r.Field(Of Nullable(Of Decimal))("Daily_Rewards")),
                        .業務給合計 = g.Sum(Function(r) r.Field(Of Nullable(Of Decimal))("Work_Salary")),
                        .授業給合計 = g.Sum(Function(r) r.Field(Of Nullable(Of Decimal))("Lecture_Fee")),
                        .コマ数合計 = g.Sum(Function(r) r.Field(Of Nullable(Of Integer))("Lecture_Count"))
                      }

        Dim destDataTable As DataTable = MonthlyListDifenition()
        For Each item In dailyQuery
            Dim newRow As DataRow = destDataTable.NewRow()
            newRow("講師ｺｰﾄﾞ") = item.講師ｺｰﾄﾞ
            newRow("講師名") = item.講師名
            newRow("勤務時間") = item.勤務時間
            newRow("報酬額合計") = item.報酬額合計
            newRow("業務給合計") = item.業務給合計
            newRow("授業給合計") = item.授業給合計
            newRow("コマ数合計") = item.コマ数合計
            destDataTable.Rows.Add(newRow)
        Next

        Return destDataTable
    End Function

    ''' <summary>
    ''' 月単位報酬リストDataTableカラム定義
    ''' </summary>
    ''' <returns></returns>
    Private Function MonthlyListDifenition() As DataTable
        Dim dtTable As New DataTable
        dtTable.Columns.Add("講師ｺｰﾄﾞ", GetType(String))
        dtTable.Columns.Add("講師名", GetType(String))
        dtTable.Columns.Add("勤務時間", GetType(Decimal))
        dtTable.Columns.Add("報酬額合計", GetType(Decimal))
        dtTable.Columns.Add("業務給合計", GetType(Decimal))
        dtTable.Columns.Add("授業給合計", GetType(Decimal))
        dtTable.Columns.Add("コマ数合計", GetType(Integer))

        Return dtTable
    End Function
End Class
