﻿Imports MainApp.Data.Dto

''' <summary>
''' 出講料アテンションリストEXCEL出力処理
''' </summary>
Public Class ReportAttentionCheck
  Inherits VBReport

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="targetDate"></param>
  Public Sub New(ByVal targetDate As Date, ByVal filePath As String)
    MyBase.New(targetDate, filePath)
    Me.OutputFilePath = filePath
  End Sub

  ''' <summary>
  ''' EXCEL出力
  ''' </summary>
  ''' <param name="param"></param>
  Public Overloads Function Output(ByVal param As RepositoryFindParameterDto)
    Dim resultData As New ResultData()
    Dim frmVBReportsViewer As New frmVBReportsViewer

    Try
      VbReportsEnvSetting(frmVBReportsViewer.CellReport1, frmVBReportsViewer.ViewerControl1)
      Dim service As New FrmAttentionCheckService()
      Dim reportListData As DataTable = service.LectureAttentionDataTable(param.TargetDate, Me.OutputFilePath)

      ' [出講料アテンション]シート
      AddPage(New RptPageAttentionList(param.TargetDate, reportListData))

      ' レポート出力
      Report()

      ' Viewerは表示しない
      'frmVBReportsViewer.ShowDialog()

      ' リソースの解放
      frmVBReportsViewer.Dispose()

      resultData.Success = True

    Catch ex As Exception
      resultData.Success = False
    End Try

    Return resultData
  End Function

  ''' <summary>
  ''' 出講料アテンションデータ取得
  ''' </summary>
  ''' <param name="srcDataTable">月単位報酬データ</param>
  ''' <returns></returns>
  Private Function GetAttentionListData(ByVal srcDataTable As DataTable) As DataTable
    Dim dailyQuery = From row In srcDataTable.AsEnumerable()
                     Select New With {
            .分類 = row.Field(Of String)("分類"),
            .講師ｺｰﾄﾞ = row.Field(Of String)("Teacher_Code"),
            .講師名 = row.Field(Of String)("Teacher_Name"),
            .日付 = row.Field(Of Date)("Lecture_Date"),
            .内容 = row.Field(Of String)("内容")
          }

    Dim destDataTable As DataTable = AttentionListDifenition()
    For Each item In dailyQuery
      Dim newRow As DataRow = destDataTable.NewRow()
      newRow("分類") = item.分類
      newRow("講師ｺｰﾄﾞ") = item.講師ｺｰﾄﾞ
      newRow("講師名") = item.講師名
      newRow("日付") = item.日付
      newRow("内容") = item.内容
      destDataTable.Rows.Add(newRow)
    Next

    Return destDataTable
  End Function

  ''' <summary>
  ''' 出講料アテンションリストDataTableカラム定義
  ''' </summary>
  ''' <returns></returns>
  Private Function AttentionListDifenition() As DataTable
    Dim dtTable As New DataTable
    dtTable.Columns.Add("分類", GetType(String))
    dtTable.Columns.Add("講師ｺｰﾄﾞ", GetType(String))
    dtTable.Columns.Add("講師名", GetType(String))
    dtTable.Columns.Add("日付", GetType(Date))
    dtTable.Columns.Add("内容", GetType(String))

    Return dtTable
  End Function
End Class
