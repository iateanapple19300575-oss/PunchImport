﻿Public Class ReportCondition

    ''' <summary>
    ''' 対象年月
    ''' </summary>
    ''' <returns></returns>
    Public Property TargetDate As Date

End Class
