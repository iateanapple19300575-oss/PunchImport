﻿'Imports System.Data.SqlClient
'Imports ClassLibrary
'Imports MainApp

'Public Class SqlImportProcessedRepository
'  Implements IImportProcessedRepository

'  Private ReadOnly _connection As SqlConnection

'  Public Sub New(conn As SqlConnection)
'    _connection = conn
'  End Sub

'  Public Function InsertProcessedData(param As ImportParameterData, tran As SqlTransaction) As Integer Implements IImportProcessedRepository.InsertProcessedData
'    Dim resultData As New ImportResultData
'    resultData.TargetYearMonth = param.TargetDate

'    Dim impFactory As New CsvImportFactory(param)
'    Dim CsvImport As CsvImportBulkCopy = impFactory.CreateCsvImport()
'    If (resultData.Success) Then
'      resultData.ImportResult = CsvImport.Import(CsvFileName, TargetYearMonth)
'      resultData.Success = resultData.ImportResult.Success
'      resultData.Exclusive = resultData.ImportResult.Exclusive
'      resultData.ProcessDateTime = resultData.ImportResult.ProcessDateTime
'    End If
'  End Function

'End Class