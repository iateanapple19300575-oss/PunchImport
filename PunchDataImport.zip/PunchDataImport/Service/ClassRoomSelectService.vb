﻿Public Class ClassRoomSelectService
  Inherits DataGriViewLoader

  Protected Overrides ReadOnly Property SqlQuery As String
    Get
      Return GetSqlQuery()
    End Get
  End Property

  Private Function GetSqlQuery() As String
    Dim sqlString As New System.Text.StringBuilder
    sqlString.Length = 0
    sqlString.Append("SELECT" & " ")
    sqlString.Append("  SGL.[ID]" & " ")
    sqlString.Append("  , SGL.[地区名]" & " ")
    sqlString.Append("  , S.[教室コード]" & " ")
    sqlString.Append("  , REPLACE(S.[教室名],'　','')" & " ")
    sqlString.Append("FROM " & " ")
    sqlString.Append("    " & DBTableConst.TABLE_NAME_SITE_GROUP_LIST & " SGL " & " ")
    sqlString.Append("    LEFT JOIN (" & " ")
    sqlString.Append("      SELECT" & " ")
    sqlString.Append("        [教室コード]" & " ")
    sqlString.Append("        , [教室名]" & " ")
    sqlString.Append("        , [教室区分]" & " ")
    sqlString.Append("        , [本校教室コード]" & " ")
    sqlString.Append("      FROM" & " ")
    sqlString.Append("        " & DBTableConst.TABLE_NAME_SITE & ") S " & " ")
    sqlString.Append("        ON (" & " ")
    sqlString.Append("          SGL.ID = S.教室区分" & " ")
    sqlString.Append("        )" & " ")
    sqlString.Append("ORDER BY " & " ")
    sqlString.Append("  SGL.[ID] ASC" & " ")
    sqlString.Append("; ")

    Return sqlString.ToString()
  End Function


  Protected Overrides Sub BindToGrid(ByRef grid As Windows.Forms.DataGridView, ByRef dtTable As DataTable)
    grid.DataSource = dtTable
    grid.Columns("教室コード").HeaderText = "教室コード"
    grid.Columns("教室名").HeaderText = "教室名"

    grid.Columns("教室コード").Width = 70
    grid.Columns("教室名").Width = 100

    grid.ReadOnly = True
    grid.AllowUserToAddRows = False
    grid.AllowUserToDeleteRows = False
    grid.AllowUserToResizeRows = False
    grid.AllowUserToOrderColumns = False
    grid.AllowUserToResizeColumns = False
    grid.AllowUserToResizeRows = False
    grid.RowHeadersWidth = 20
    For Each column As DataGridViewColumn In grid.Columns
      column.SortMode = DataGridViewColumnSortMode.NotSortable
    Next

    Dim totalWidth As Integer = grid.RowHeadersWidth
    For Each column As DataGridViewColumn In grid.Columns
      totalWidth += column.Width
    Next
    'grid.Width = totalWidth + 2
    grid.BackgroundColor = Color.White
    grid.ScrollBars = ScrollBars.Vertical
    grid.Columns("ID").Visible = False
    grid.Columns("地区名").Visible = False

    grid.Columns("教室コード").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns("教室名").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft

    grid.Columns("教室コード").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns("教室名").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft

  End Sub

End Class
