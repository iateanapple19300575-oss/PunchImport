﻿Imports System.Data.SqlClient

''' <summary>
''' 打刻状況画面用サービスクラス
''' </summary>
Public Class TransExpService
	Inherits DataGridViewDisplayService

	''' <summary>
	''' 時間パターントラン
	''' </summary>
	Private timePatternTran As New TimePatternTran()

	''' <summary>
	''' システム環境設定情報
	''' </summary>
	''' <returns></returns>
	Private Property SystemEnvData As New SystemEnvData

	Private debugUtil = New DebugUtil()


	''' <summary>
	''' コンストラクタ
	''' </summary>
	Sub New()
	End Sub

	''' <summary>
	''' コンストラクタ
	''' </summary>
	''' <param name="targetDate"></param>
	''' <param name="p_dataGridView"></param>
	Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
		MyBase.New(targetDate, p_dataGridView)
		Me.TargetDate = targetDate
		SystemEnvData = GetErrorColorInfo()
	End Sub

	''' <summary>
	''' 画面表示データ取得：対象年月度情報
	''' </summary>
	''' <returns></returns>
	Public Function GetTargetMonthList() As ResultData
		Dim result As ResultData = timePatternTran.GetLectureYearMonth()
		Return result
	End Function

  ''' <summary>
  ''' 表示データ取得クエリ取得
  ''' </summary>
  ''' <returns>表示データ取得クエリ</returns>
  Protected Overrides Function GetQuery(Optional ByVal param As DaoParameter = Nothing) As String
    Return TransExpQuery.SelectSql(TargetDate, SystemEnvData.TimeSpan, SystemEnvData.BaseUnitPrice, param)
  End Function

  ''' <summary>
  ''' DataGridView表示編集
  ''' </summary>
  ''' <param name="reader"></param>
  Protected Overrides Sub GetReaderValue(reader As SqlDataReader)

		debugUtil.StopwatchStart("GetReaderValue")

		Dim dtTable As New DataTable
		dtTable.Columns.Add("講師コード", GetType(String))
		dtTable.Columns.Add("教室Code", GetType(String))
		dtTable.Columns.Add("出講場所名", GetType(String))
		dtTable.Columns.Add("交通費", GetType(String))
		dtTable.Columns.Add("鮮度", GetType(String))
		dtTable.Columns.Add("所要時間", GetType(String))
		dtTable.Columns.Add("適用開始日", GetType(String))

		'Dim row As Integer = 0
		With Me.DataGridView
			While reader.Read()
				Dim rowRec As DataRow = dtTable.NewRow()
				rowRec("講師コード") = reader.GetValue(reader.GetOrdinal("講師コード"))
				rowRec("教室Code") = reader.GetValue(reader.GetOrdinal("教室Code"))
				rowRec("出講場所名") = reader.GetValue(reader.GetOrdinal("出講場所名"))
				rowRec("交通費") = reader.GetValue(reader.GetOrdinal("交通費"))
				rowRec("鮮度") = reader.GetValue(reader.GetOrdinal("鮮度"))
				rowRec("所要時間") = reader.GetValue(reader.GetOrdinal("所要時間"))
				rowRec("適用開始日") = reader.GetValue(reader.GetOrdinal("適用開始日"))
				dtTable.Rows.Add(rowRec)

				'row += 1
			End While

			.DataSource = dtTable
		End With

		debugUtil.StopwatchStop("GetReaderValue")
	End Sub

	Public Function GetErrorColorInfo() As SystemEnvData
		Dim result As New SystemEnvData

		Dim tran As New SystemEnvTran()
		Dim resultData As ResultData = tran.SelectData()
		If (resultData.Success) Then
			result = resultData.ResDataClass
		End If

		Return result
	End Function

End Class


