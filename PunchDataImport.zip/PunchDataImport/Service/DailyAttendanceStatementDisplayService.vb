﻿Imports MainApp.Data.Dto

''' <summary>
''' 日次勤怠明細画面サービスクラス
''' </summary>
Public Class DailyAttendanceStatementDisplayService

    ''' <summary>
    ''' 勤怠情報ドメインサービス
    ''' </summary>
    Private _attendanceDomain As New AttendanceDomain

    ''' <summary>
    ''' 日次勤怠明細画面ドメインサービス
    ''' </summary>
    Private _attendanceService As New AttendanceService

    ''' <summary>
    ''' 勤怠情報リポジトリ
    ''' </summary>
    Private _attendanceRepo As New AttendanceRepository

    ''' <summary>
    ''' 打刻外業務給リポジトリ
    ''' </summary>
    Private hourlyWageManualEntryTran As New HourlyWageManualEntryRepository

    ''' <summary>
    ''' 勤怠情報リポジトリ
    ''' </summary>
    Private _repository As New AttendanceRepository


#Region "画面初期表示処理"

    '''' <summary>
    '''' 画面初期表示データ取得
    '''' </summary>
    '''' <returns></returns>
    'Public Function DataLad(ByVal param As RepositoryFindParameterDto) As AttendanceStatementWinData
    '    Dim displayData As New AttendanceStatementWinData

    '    Try
    '        ' 1日の勤怠明細情報の取得




    '        Dim result As DataTable
    '        'result = _attendanceRepo.DataLoadByDays(param)
    '        'displayData.AttendanceDataTable = _attendanceDomain.AttendanceAnalysis(result)
    '        Dim cond As New LectureDetailsFindParameter
    '        cond.TargetDate = param.TargetDate
    '        cond.LectureDate = param.LectureDate
    '        cond.TeacherCode = param.TeacherCode
    '        displayData.AttendanceDataTable = _attendanceService.DataLoadByDay(cond)


    '        ' エラー・警告等情報
    '        Dim errList As List(Of ValidationRuleResult)
    '        errList = _attendanceDomain.AttendanceValidate(displayData.AttendanceDataTable)
    '        displayData.ErrorInfoDataTable = _attendanceDomain.ListToDataTable(errList)

    '        ' 出講・業務届明細
    '        Dim dt As DataTable = _attendanceRepo.DataLoadByDayDetails(param)
    '        displayData.LectureWorkDataTable = AttentionCheckDomain.LectureAndWorkAnalysis(dt)

    '        ' 打刻外業務給データ
    '        displayData.WorkSalaryDataTable = hourlyWageManualEntryTran.LoadOneDayData(param)





    '    Catch ex As Exception
    '        Throw

    '    End Try

    '    Return displayData
    'End Function



    ''' <summary>
    ''' 表示データ取得（特定日、特定講師）
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoad(ByVal param As LectureDetailsFindParameter) As AttendanceStatementWinData
        Dim displayData As New AttendanceStatementWinData

        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        'Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                ' 1日の勤怠明細情報の取得
                _attendanceDomain = New AttendanceDomain(uow)
                dataList = _attendanceDomain.LoadDataByDay(param)
                modelList = _attendanceDomain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)
                displayData.AttendanceDataTable = _attendanceDomain.WorkListToDataTable(modelList)

                ' エラー・警告等情報
                displayData.ErrorInfoDataTable = _attendanceDomain.ListToDataTable(modelList(0).StatusList)

                ' 出講・業務届明細
                Dim dt As DataTable = _attendanceRepo.DataLoadByDayDetails(param)
                displayData.LectureWorkDataTable = AttentionCheckDomain.LectureAndWorkAnalysis(dt)

                ' 打刻外業務給データ
                displayData.WorkSalaryDataTable = hourlyWageManualEntryTran.LoadOneDayData(param)

            End Using

        Catch ex As Exception

        End Try

        Return displayData
    End Function

#End Region

End Class
