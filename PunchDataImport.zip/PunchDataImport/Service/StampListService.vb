﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 打刻状況画面用サービスクラス
''' </summary>
Public Class StampListService
  Inherits DataGridViewDisplayService

  ''' <summary>
  ''' システム環境設定情報
  ''' </summary>
  ''' <returns></returns>
  Private Property SystemEnvData As New SystemEnvData


  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="targetDate"></param>
  ''' <param name="p_dataGridView"></param>
  Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
    MyBase.New(targetDate, p_dataGridView)
    Me.TargetDate = targetDate
    SystemEnvData = GetErrorColorInfo()
  End Sub

  ''' <summary>
  ''' 表示データ取得クエリ取得
  ''' </summary>
  ''' <returns>表示データ取得クエリ</returns>
  Protected Overrides Function GetQuery(Optional ByVal code As DaoParameter = Nothing) As String
    Return StampListQuery.SelectSql(TargetDate)
  End Function

  ''' <summary>
  ''' DataGridView表示編集
  ''' </summary>
  ''' <param name="reader"></param>
  Protected Overrides Sub GetReaderValue(reader As SqlDataReader)

    Dim jobStTime As String, jobEdTime As String
    Dim dmdStTime As String, dmdEdTime As String
    Dim actStTime As String, actEdTime As String
    Dim reqStTime As String, reqEdTime As String
    Dim plnStTime As String

    Dim dtTable As New DataTable
    dtTable.Columns.Add("講師ｺｰﾄﾞ", GetType(String))
    dtTable.Columns.Add("講師名", GetType(String))
    dtTable.Columns.Add("日付", GetType(String))
    dtTable.Columns.Add("状態", GetType(String))
    dtTable.Columns.Add("出勤(打刻)", GetType(String))
    dtTable.Columns.Add("退勤(打刻)", GetType(String))
    dtTable.Columns.Add("出勤(みなし)", GetType(String))
    dtTable.Columns.Add("退勤(みなし)", GetType(String))
    dtTable.Columns.Add("時間(みなし)", GetType(String))
    dtTable.Columns.Add("開始(実績)", GetType(String))
    dtTable.Columns.Add("終了(実績)", GetType(String))
    dtTable.Columns.Add("開始(業務)", GetType(String))
    dtTable.Columns.Add("終了(業務)", GetType(String))
    dtTable.Columns.Add("開始(予定)", GetType(String))
    dtTable.Columns.Add("終了(予定)", GetType(String))

    ' 交通費
    dtTable.Columns.Add("交通費-1", GetType(String))
    dtTable.Columns.Add("交通費-2", GetType(String))
    dtTable.Columns.Add("交通費-3", GetType(String))

    For i As Integer = 1 To 6
      dtTable.Columns.Add("教室" & i, GetType(String))
      dtTable.Columns.Add("学年" & i, GetType(String))
      dtTable.Columns.Add("ｸﾗｽ" & i, GetType(String))
      dtTable.Columns.Add("コマ" & i, GetType(String))
      dtTable.Columns.Add("開始" & i, GetType(String))
      dtTable.Columns.Add("終了" & i, GetType(String))
      dtTable.Columns.Add("ﾋﾟﾝﾁ" & i, GetType(String))
    Next

    dtTable.Columns.Add("打出勤色", GetType(String))
    dtTable.Columns.Add("打退勤色", GetType(String))
    dtTable.Columns.Add("実出勤色", GetType(String))
    dtTable.Columns.Add("実退勤色", GetType(String))
    dtTable.Columns.Add("日付色", GetType(String))


    Try
      'Dim row As Integer = 0
      With Me.DataGridView
        While reader.Read()
          Dim rowRec As DataRow = dtTable.NewRow()
          rowRec("講師ｺｰﾄﾞ") = SqlDataReaderUtil.GetValue(reader, "講師ｺｰﾄﾞ")
          rowRec("講師名") = SqlDataReaderUtil.GetValue(reader, "講師名")
          Dim dtDate As Date = SqlDataReaderUtil.GetValue(reader, "日付")
          Dim strDay As String = dtDate.ToString("ddd")
          rowRec("日付") = dtDate.ToString("yyyy/MM/dd") & "(" & strDay & ")"

          Dim dateForeColor As Color = Color.Black
          If (Weekday(dtDate) = 1) Then
            dateForeColor = Color.Red
          ElseIf (Weekday(dtDate) = 7) Then
            dateForeColor = Color.Blue
          End If
          rowRec("日付色") = dateForeColor.Name

          rowRec("出勤(打刻)") = SqlDataReaderUtil.GetValue(reader, "出勤(打刻)")
          rowRec("退勤(打刻)") = SqlDataReaderUtil.GetValue(reader, "退勤(打刻)")
          rowRec("出勤(みなし)") = SqlDataReaderUtil.GetValue(reader, "出勤(みなし)")
          rowRec("退勤(みなし)") = SqlDataReaderUtil.GetValue(reader, "退勤(みなし)")
          rowRec("時間(みなし)") = SqlDataReaderUtil.GetValue(reader, "時間(みなし)")
          rowRec("開始(実績)") = SqlDataReaderUtil.GetValue(reader, "開始(実績)")
          rowRec("終了(実績)") = SqlDataReaderUtil.GetValue(reader, "終了(実績)")
          rowRec("開始(業務)") = SqlDataReaderUtil.GetValue(reader, "開始(業務)")
          rowRec("終了(業務)") = SqlDataReaderUtil.GetValue(reader, "終了(業務)")
          rowRec("開始(予定)") = SqlDataReaderUtil.GetValue(reader, "開始(予定)")
          rowRec("終了(予定)") = SqlDataReaderUtil.GetValue(reader, "終了(予定)")

          Dim timeInfo As New WorkTimeEvaluator.PunchingTimeData With {
            .JobStart = rowRec("出勤(打刻)"),
            .JobEnd = rowRec("退勤(打刻)"),
            .ActStart = rowRec("開始(実績)"),
            .ActEnd = rowRec("終了(実績)"),
            .ReqStart = rowRec("開始(業務)"),
            .ReqEnd = rowRec("終了(業務)"),
            .WorkStart = "",
            .WorkEnd = "",
            .WorkTime = ""
          }

          WorkTimeEvaluator.DeemedTimeInfo(timeInfo)
          rowRec("出勤(みなし)") = timeInfo.WorkStart
          rowRec("退勤(みなし)") = timeInfo.WorkEnd
          If StringUtil.IsNullOrWhiteSpace(timeInfo.WorkTime) Then
            rowRec("時間(みなし)") = ""
          Else
            rowRec("時間(みなし)") = Math.Round(Decimal.Parse(timeInfo.WorkTime) / 60, 2, MidpointRounding.AwayFromZero).ToString()
          End If
          rowRec("状態") = timeInfo.Info

          ' 交通費
          Dim roomOffset As Integer = 26
          Dim amountOffset As Integer = 33
          Dim room As String = ""
          Dim amount As String = ""
          Dim transpo As New Dictionary(Of String, String)
          For i As Integer = 0 To 6 - 1
            Dim koma As Integer = i + 1
            room = SqlDataReaderUtil.GetValue(reader, roomOffset + (i * 8))
            amount = SqlDataReaderUtil.GetValue(reader, amountOffset + (i * 8))
            If StringUtil.IsNotNullOrWhiteSpace(room) Then
              If Not transpo.ContainsKey(room) Then
                transpo.Add(room, amount)
              End If
            End If
          Next

          Dim idx As Integer = 1
          If transpo.Count > 0 Then
            'TODO: 交通費金額を表示する場合、コメント解除
            'For Each kvp As KeyValuePair(Of String, String) In transpo
            '	Dim key As String = kvp.Key
            '	Dim value As String = kvp.Value
            '	If StringUtil.IsNullOrWhiteSpace(value) Then
            '		rowRec("交通費-" & idx) = key & "：" & " 未登録 "
            '	Else
            '		Dim roundTrip As Double = Math.Round(Double.Parse(value), 1, MidpointRounding.AwayFromZero) * 2
            '		rowRec("交通費-" & idx) = key & "：" & ("\" & NumberUtil.DigitComma(roundTrip)).PadLeft(8)
            '	End If
            '	idx += 1
            'Next

            For Each kvp As KeyValuePair(Of String, String) In transpo
              Dim key As String = kvp.Key
              Dim value As String = kvp.Value
              If StringUtil.IsNullOrWhiteSpace(value) Then
                rowRec("交通費-" & idx) = key & "：" & "未"
              Else
                Dim roundTrip As Double = Math.Round(Double.Parse(value), 1, MidpointRounding.AwayFromZero) * 2
                rowRec("交通費-" & idx) = key & "" & ""
              End If
              idx += 1
            Next
          End If


          For i As Integer = 0 To 6 - 1
            Dim koma As Integer = i + 1
            rowRec("教室" & koma) = reader.GetValue(roomOffset + (i * 8))
            rowRec("学年" & koma) = reader.GetValue(roomOffset + 1 + (i * 8))
            rowRec("ｸﾗｽ" & koma) = reader.GetValue(roomOffset + 2 + (i * 8))
            rowRec("コマ" & koma) = reader.GetValue(roomOffset + 3 + (i * 8))
            rowRec("開始" & koma) = reader.GetValue(roomOffset + 4 + (i * 8))
            rowRec("終了" & koma) = reader.GetValue(roomOffset + 5 + (i * 8))
            rowRec("ﾋﾟﾝﾁ" & koma) = reader.GetValue(roomOffset + 6 + (i * 8))
          Next

          jobStTime = IIf(IsDBNull(rowRec("出勤(打刻)")), "", rowRec("出勤(打刻)").ToString())
          jobEdTime = IIf(IsDBNull(rowRec("退勤(打刻)")), "", rowRec("退勤(打刻)").ToString())
          actStTime = IIf(IsDBNull(rowRec("開始(実績)")), "", rowRec("開始(実績)").ToString())
          actEdTime = IIf(IsDBNull(rowRec("終了(実績)")), "", rowRec("終了(実績)").ToString())
          reqStTime = IIf(IsDBNull(rowRec("開始(業務)")), "", rowRec("開始(業務)").ToString())
          reqEdTime = IIf(IsDBNull(rowRec("終了(業務)")), "", rowRec("終了(業務)").ToString())
          dmdStTime = IIf(IsDBNull(rowRec("出勤(みなし)")), "", rowRec("出勤(みなし)").ToString())
          dmdEdTime = IIf(IsDBNull(rowRec("退勤(みなし)")), "", rowRec("退勤(みなし)").ToString())
          plnStTime = IIf(IsDBNull(rowRec("開始(予定)")), "", rowRec("開始(予定)").ToString())

          'If (Not LectureFeeTimeValidator.Validate(jobStTime, jobEdTime, actStTime, actEdTime, reqStTime, reqEdTime, dmdStTime, dmdEdTime, plnStTime, SystemEnvData)) Then
          '	rowRec("打出勤色") = LectureFeeTimeValidator.GetErrorColor()(0).Name
          '	rowRec("打退勤色") = LectureFeeTimeValidator.GetErrorColor()(1).Name
          '	rowRec("実出勤色") = LectureFeeTimeValidator.GetErrorColor()(2).Name
          '	rowRec("実退勤色") = LectureFeeTimeValidator.GetErrorColor()(3).Name
          'End If
          'rowRec("状態") = LectureFeeTimeValidator.GetErrorMessage()

          dtTable.Rows.Add(rowRec)

          'row += 1
        End While

        .DataSource = dtTable
      End With

    Catch ex As Exception
      MsgBox("")
    End Try

  End Sub

  Public Function GetErrorColorInfo() As SystemEnvData
    Dim result As New SystemEnvData

    Dim tran As New SystemEnvTran()
    Dim resultData As ResultData = tran.SelectData()
    If (resultData.Success) Then
      result = resultData.ResDataClass
    End If

    Return result
  End Function

End Class


