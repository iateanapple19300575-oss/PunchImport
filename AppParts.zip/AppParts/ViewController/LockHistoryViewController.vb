﻿Imports App.Common.Data.Model

Public Class LockHistoryViewController

    ''' <summary>
    ''' 対象年月度ロックサービス
    ''' </summary>
    Private _service As New YearMonthLockService

    ''' <summary>
    ''' 対象年月の強制ロック解除をします。
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function UnLockedTargetYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel

        model.NowYearMonth = AppState.TargetYearMonth
        result = _service.UnLockedTargetYearMonth(model)

        Return result
    End Function

End Class
