﻿Public Class OperationHistoryService
  Inherits DataGriViewLoader

  Protected Overrides ReadOnly Property SqlQuery As String
    Get
      Return GetSqlQuery()
    End Get
  End Property

  Private Function GetSqlQuery() As String
    Dim sqlString As New System.Text.StringBuilder
    sqlString.Length = 0
    sqlString.Append("SELECT ")
    sqlString.Append("   " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベントID)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベント発生日時)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.画面名)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作内容)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作詳細情報)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.対象年月度)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ファイル名)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ユーザー)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行PC)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行日)).Append(" ")
    sqlString.Append("FROM").Append(" ")
    sqlString.Append("  " & DbMapper.GetTableName(Of T_Operation_LogEnum)).Append(" ")
    sqlString.Append("ORDER BY").Append(" ")
    sqlString.Append("   " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベントID)).Append(" ")
    sqlString.Append(" , " & DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベント発生日時)).Append(" ASC ")
    sqlString.Append(";")

    Return sqlString.ToString()
  End Function


  Protected Overrides Sub BindToGrid(ByRef grid As Windows.Forms.DataGridView, ByRef dtTable As DataTable)
    grid.DataSource = dtTable
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベントID)).HeaderText = "連番"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベント発生日時)).HeaderText = "発生日時"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.画面名)).HeaderText = "画面名"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作内容)).HeaderText = "内容"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作詳細情報)).HeaderText = "詳細"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.対象年月度)).HeaderText = "対象年月"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ファイル名)).HeaderText = "実行ファイル"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ユーザー)).HeaderText = "ユーザー"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行PC)).HeaderText = "操作端末"
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行日)).HeaderText = "最終更新日時"

    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベントID)).Width = 70
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベント発生日時)).Width = 130
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.画面名)).Width = 200
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作内容)).Width = 300
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作詳細情報)).Width = 600
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.対象年月度)).Width = 70
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ファイル名)).Width = 100
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ユーザー)).Width = 70
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行PC)).Width = 90
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行日)).Width = 130

    grid.ReadOnly = True
    grid.AllowUserToAddRows = False
    grid.AllowUserToDeleteRows = False
    grid.AllowUserToOrderColumns = False
    grid.AllowUserToResizeColumns = False
    grid.AllowUserToResizeRows = False
    grid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing
    grid.RowHeadersWidth = 20
    For Each column As DataGridViewColumn In grid.Columns
      column.SortMode = DataGridViewColumnSortMode.NotSortable
    Next

    Dim totalWidth As Integer = grid.RowHeadersWidth
    For Each column As DataGridViewColumn In grid.Columns
      totalWidth += column.Width
    Next
    'totalWidth -= 70
    grid.Width = totalWidth
    grid.Width = totalWidth + 2
    grid.BackgroundColor = Color.White
    grid.ScrollBars = ScrollBars.Vertical

    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベントID)).Visible = False

    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベントID)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベント発生日時)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.画面名)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作内容)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作詳細情報)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.対象年月度)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ファイル名)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ユーザー)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行PC)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行日)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter

    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベントID)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.イベント発生日時)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.画面名)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作内容)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.操作詳細情報)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.対象年月度)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ファイル名)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行ユーザー)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行PC)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Operation_LogEnum)(T_Operation_LogEnum.実行日)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

  End Sub

End Class
