﻿''' <summary>
''' 操作履歴画面
''' </summary>
Public Class FrmImportHistory

	''' <summary>
	''' ヘッダ部パネル高さ
	''' </summary>
	Private Const SIZE_HEAD_HEIGHT As Integer = 40

	''' <summary>
	''' クライアント領域両サイド
	''' </summary>
	Private Const SIZE_CLIENT_SIDE_W As Integer = 12 * 2

	''' <summary>
	''' 枠線サイズ
	''' </summary>
	Private Const SIZE_DIVIDER_LINE As Integer = 8

	''' <summary>
	''' DataGridViewLocationY
	''' </summary>
	Private Const LOCATION_X_GRID As Integer = 50

	''' <summary>
	''' Loadイベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub OperationHistory_Load(sender As Object, e As EventArgs) Handles Me.Load
		' 画面初期表示
		InitDisplay()
	End Sub

	''' <summary>
	''' ReSizeイベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub OperationHistory_Resize(sender As Object, e As EventArgs) Handles Me.Resize

		'If Me.MdiParent Is Nothing Then
		'	DataGridView1.Height = Me.Height - (SIZE_HEAD_HEIGHT + LOCATION_X_GRID)
		'	DataGridView1.Width = Me.Width - SIZE_CLIENT_SIDE_W
		'Else
		'	Dim width As Integer = Me.MdiParent.ClientSize.Width
		'	Dim height As Integer = Me.MdiParent.ClientSize.Height
		'	Dim newHeght As Integer = IIf(Me.Height > height, height, Me.Height)
		'	Dim newWidth As Integer = IIf(Me.Width > width, width, Me.Width)
		'	DataGridView1.Height = newHeght - (SIZE_HEAD_HEIGHT + LOCATION_X_GRID)
		'	DataGridView1.Width = newWidth - SIZE_CLIENT_SIDE_W
		'	Me.Width = width - SIZE_DIVIDER_LINE
		'	Me.Height = height - (SIZE_HEAD_HEIGHT + SIZE_DIVIDER_LINE)
		'End If

		'Dim totalWidth As Integer = DataGridView1.RowHeadersWidth
		'For Each column As DataGridViewColumn In DataGridView1.Columns
		'	totalWidth += column.Width
		'Next
		'totalWidth -= 70
		'DataGridView1.Width = totalWidth
		'Me.Width = Width - SIZE_DIVIDER_LINE
		'Me.Height = Height - (SIZE_HEAD_HEIGHT + SIZE_DIVIDER_LINE)

		'Me.Width = DataGridView1.Width + SIZE_CLIENT_SIDE_W
		'Me.Height = DataGridView1.Height + SIZE_HEAD_HEIGHT + SIZE_DIVIDER_LINE


	End Sub

	''' <summary>
	''' 初期表示処理
	''' </summary>
	Private Sub InitDisplay()
		'Me.MinimumSize = New Size(1280 - 24, 640)

		'With DataGridView1
		'	.AllowUserToResizeColumns = False
		'	.AllowUserToResizeRows = False
		'End With

		Dim ImportHistoryLoader = New ImportHistoryService()
		Dim dt As New DataTable()

		ImportHistoryLoader.LoadAndBind(DataGridView1, dt)


		Dim totalWidth As Integer = DataGridView1.RowHeadersWidth
		For Each column As DataGridViewColumn In DataGridView1.Columns
			If Not "id".Equals(column.Name) Then
				totalWidth += column.Width
			End If
		Next

		Dim mdiClient As MdiClient = Me.MdiParent.Controls.OfType(Of MdiClient)().FirstOrDefault()
		DataGridView1.Width = totalWidth + SIZE_DIVIDER_LINE
		DataGridView1.Height = mdiClient.Height - (SIZE_HEAD_HEIGHT + SIZE_DIVIDER_LINE + LOCATION_X_GRID + 13)

		Me.Width = mdiClient.Width - SIZE_DIVIDER_LINE
		Me.Height = mdiClient.Height - SIZE_DIVIDER_LINE
	End Sub
End Class