﻿Imports Framework.Common.Utilities
Imports Framework.Common.Utilities.ColorUtil
Imports LecturePay.Common.Infrastructure

''' <summary>
''' システム環境設定画面
''' </summary>
Public Class FrmSystemEnvSettings

#Region "フィールド関連"

  ' 画面データ
  Private Property DisplayData As SystemEnvData = AppCommon.GetSystemEnvData()

#End Region

#Region "画面イベント処理"

  ''' <summary>
  ''' Loadイベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub FrmSystemSettings_Load(sender As Object, e As EventArgs) Handles Me.Load
    InitialDisplay()
  End Sub

  ''' <summary>
  ''' [閉じる(F12)]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click

    If (IsDataChanged()) Then
      If (MessageBox.Show(Me, "編集中ですが宜しいですか？", "確認", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = DialogResult.Cancel) Then
        Return
      End If
    End If
    Me.Close()

  End Sub

  ''' <summary>
  ''' [保存(F1)]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
    ' 入力チェック
    If (Not CheckInputData()) Then
      Return
    End If

    Try
      ' My.Setting に保存する
      AppCommon.UpdateEnvPunchingInOut(CmbNoStamp.SelectedValue)
      AppCommon.UpdateEnvPunchingInEarly(CmbClockInEarly.SelectedValue)
      AppCommon.UpdateEnvPunchingInLate(CmbClockInLate.SelectedValue)
      AppCommon.UpdateEnvPunchingOutLate(CmbClockOutLate.SelectedValue)
      AppCommon.UpdateEnvPunchingOutEarly(CmbClockOutEarly.SelectedValue)
      MessageBox.Show(Me, MessageIdConst.MSGID_I2003, "保存", MessageBoxButtons.OK, MessageBoxIcon.Information)
    Catch ex As Exception
      MessageBox.Show(Me, MessageIdConst.MSGID_I1004, "保存", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Try
  End Sub

  ''' <summary>
  ''' (システム設定)[元に戻す]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub BtnSystemDefault_Click(sender As Object, e As EventArgs) Handles BtnSystemDefault.Click
    ' 基本報酬単価
    TxtBBasicUnitPrice.Text = DisplayData.BaseUnitPrice
    ' みなし時間
    TxtBTimeSpan.Text = DisplayData.TimeSpan
  End Sub

  ''' <summary>
  ''' [DrawItem]イベント
  ''' カラー選択コンボボックスの表示文字、背景色を設定する。
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub ComboBox_DrawItem(sender As Object, e As DrawItemEventArgs) Handles CmbNoStamp.DrawItem, CmbClockInEarly.DrawItem, CmbClockInLate.DrawItem, CmbClockOutLate.DrawItem, CmbClockOutEarly.DrawItem

    If e.Index < 0 Then
      Exit Sub
    End If

    ' 選択状態による背景色の設定
    If (e.State And DrawItemState.Selected) = DrawItemState.Selected Then
      e.Graphics.FillRectangle(New SolidBrush(System.Drawing.Color.CornflowerBlue), e.Bounds)
    Else
      e.Graphics.FillRectangle(SystemBrushes.Window, e.Bounds)
    End If

    ' 色イメージ
    Dim combo As ComboBox = CType(sender, ComboBox)
    Dim color As Color = CType(combo.Items(e.Index).Color, Color)
    Dim previewRect As New Rectangle(e.Bounds.X + 2, e.Bounds.Y + 2, 20, e.Bounds.Height - 4)
    e.Graphics.FillRectangle(New SolidBrush(color), previewRect)
    e.Graphics.DrawRectangle(Pens.Black, previewRect)

    ' テキスト
    Dim textRect As New Rectangle(previewRect.Right + 5, e.Bounds.Y + 2, e.Bounds.Width - 10, e.Bounds.Height - 4)
    Dim textHeight As Single = e.Graphics.MeasureString(Text, sender.Controls.Owner.Font).Height
    Dim textColor As Color = If((e.State And DrawItemState.Selected) = DrawItemState.Selected, Color.White, Color.Black)
    TextRenderer.DrawText(e.Graphics, color.Name, combo.Font, textRect, textColor, TextFormatFlags.Left)

  End Sub

  ''' <summary>
  ''' [MeasureItem]イベント
  ''' カラー選択コンボボックスのリスト項目の高さを設定する。
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub ComboBox_MeasureItem(sender As Object, e As MeasureItemEventArgs) Handles CmbNoStamp.MeasureItem, CmbClockInEarly.MeasureItem, CmbClockInLate.MeasureItem, CmbClockOutLate.MeasureItem, CmbClockOutEarly.MeasureItem
    If e.Index < 0 Then
      Exit Sub
    End If
    e.ItemHeight = 20
  End Sub

  ''' <summary>
  ''' [プレビュー]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub BtnPreview_Click(sender As Object, e As EventArgs) Handles BtnPreview.Click
    '--- サンプルデータ設定 ---
    Me.Height = 670

    With DGVPreview
      .Rows.Clear()
      '各列の幅設定
      .RowHeadersWidth = 20
      .Columns(0).Width = 70
      .Columns(1).Width = 120
      .Columns(2).Width = 110
      .Columns(3).Width = 200
      .Columns(4).Width = 80
      .Columns(5).Width = 80
      .Columns(6).Width = 80
      .Columns(7).Width = 80

      .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
      .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
      .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
      .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomLeft
      .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
      .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
      .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
      .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

      ' ソート禁止
      For Each column As DataGridViewColumn In .Columns
        column.SortMode = DataGridViewColumnSortMode.NotSortable
      Next

      '--- サンプルデータ設定 ---
      .Rows.Add("Z999", "Z999 日能研", "2025/07/01(月)", "正常", "08:38", "16:56", "08:20", "17:10", "")
      .Rows.Add("Z999", "Z999 日能研", "2025/07/02(火)", "異常：出勤早", "14:39", "19:14", "14:40", "19:20", "")
      .Rows.Add("Z999", "Z999 日能研", "2025/07/03(水)", "異常：出勤遅", "16:02", "18:30", "14:40", "18:20", "")
      .Rows.Add("Z999", "Z999 日能研", "2025/07/04(木)", "異常：退勤早", "14:50", "18:52", "14:40", "19:20", "")
      .Rows.Add("Z999", "Z999 日能研", "2025/07/05(金)", "異常：退勤遅", "15:54", "18:22", "15:40", "18:20", "")
      .Rows.Add("Z999", "Z999 日能研", "2025/07/06(土)", "打刻なし", "", "", "09:00", "16:20", "")
      .Rows.Add("Z999", "Z999 日能研", "2025/07/07(日)", "打刻忘れ(出勤)", "", "18:42", "13:10", "19:00", "")
      .Rows.Add("Z999", "Z999 日能研", "2025/07/08(月)", "打刻忘れ(退勤)", "09:50", "", "10:05", "16:20", "")
      .Rows.Add("・・・", "・・・", "・・・", "・・・", "・・・", "・・・", "・・・", "・・・", "")

      '--- 土日文字色設定 ---
      .Rows(5).Cells(2).Style.ForeColor = Color.FromName(Color.Blue.Name)
      .Rows(6).Cells(2).Style.ForeColor = Color.FromName(Color.Red.Name)

      '--- 背景色設定 ---
      .Rows(0).Cells(4).Style.BackColor = Color.FromName(Color.White.Name)
      '異常：出勤早
      .Rows(1).Cells(4).Style.BackColor = Color.FromName(CmbClockInEarly.SelectedValue)
      '異常：出勤遅
      .Rows(2).Cells(4).Style.BackColor = Color.FromName(CmbClockInLate.SelectedValue)
      '異常：退勤早
      .Rows(3).Cells(5).Style.BackColor = Color.FromName(CmbClockOutEarly.SelectedValue)
      '異常：退勤遅
      .Rows(4).Cells(5).Style.BackColor = Color.FromName(CmbClockOutLate.SelectedValue)
      '打刻なし
      .Rows(5).Cells(4).Style.BackColor = Color.FromName(CmbNoStamp.SelectedValue)
      .Rows(5).Cells(5).Style.BackColor = Color.FromName(CmbNoStamp.SelectedValue)
      '打刻忘れ(出勤)
      .Rows(6).Cells(4).Style.BackColor = Color.FromName(CmbNoStamp.SelectedValue)
      '打刻忘れ(退勤)
      .Rows(7).Cells(5).Style.BackColor = Color.FromName(CmbNoStamp.SelectedValue)
    End With

    DGVPreview.Visible = True

  End Sub

  ''' <summary>
  ''' (打刻エラー背景色設定)[元に戻す]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  ''' <remarks>
  ''' 打刻エラー背景色設定を画面初期表示の状態に戻す。
  ''' </remarks>
  Private Sub BtnColorDefault_Click(sender As Object, e As EventArgs) Handles BtnColorDefault.Click
    ' 打刻関連エラー時の背景色
    CmbNoStamp.SelectedValue = DisplayData.PunchingInOut
    CmbClockInEarly.SelectedValue = DisplayData.PunchingInEarly
    CmbClockInLate.SelectedValue = DisplayData.PunchingInLate
    CmbClockOutLate.SelectedValue = DisplayData.PunchingOutLate
    CmbClockOutEarly.SelectedValue = DisplayData.PunchingOutEarly
    BtnPreview.PerformClick()
  End Sub

#End Region

#Region "内部処理"

  ''' <summary>
  ''' 画面初期表示処理
  ''' </summary>
  Private Sub InitialDisplay()
    ' 色選択コンボ：データ設定
    setColorSelectionDefault(CmbNoStamp)
    setColorSelectionDefault(CmbClockInEarly)
    setColorSelectionDefault(CmbClockInLate)
    setColorSelectionDefault(CmbClockOutLate)
    setColorSelectionDefault(CmbClockOutEarly)

    ' 色選択コンボ： 初期選択
    TxtBBasicUnitPrice.Text = DisplayData.BaseUnitPrice
    TxtBTimeSpan.Text = DisplayData.TimeSpan
    CmbNoStamp.SelectedValue = DisplayData.PunchingInOut
    CmbClockInEarly.SelectedValue = DisplayData.PunchingInEarly
    CmbClockInLate.SelectedValue = DisplayData.PunchingInLate
    CmbClockOutLate.SelectedValue = DisplayData.PunchingOutLate
    CmbClockOutEarly.SelectedValue = DisplayData.PunchingOutEarly

    ' プレビュー表示部を非表示
    Me.Height = 430
    DGVPreview.Visible = False
  End Sub

  ''' <summary>
  ''' 色選択データ設定
  ''' </summary>
  ''' <param name="comboBox">設定対象のコンボボックス</param>
  Private Sub setColorSelectionDefault(ByVal comboBox As ComboBox)
    Try
      Dim colorUtil As New ColorUtil()
      Dim itemData As List(Of ItemInfo) = colorUtil.GetSystemColorItems()
      comboBox.DrawMode = DrawMode.OwnerDrawVariable
      comboBox.DropDownStyle = ComboBoxStyle.DropDownList
      comboBox.DataSource = itemData
      comboBox.DisplayMember = "Name"
      comboBox.ValueMember = "Name"
      comboBox.DropDownHeight = 200
    Catch ex As Exception
      'sender.Controls.Owner.Items.Add("Error parsing: " & colorName)
    End Try
  End Sub

#End Region

#Region "入力チェック"

  ''' <summary>
  ''' 画面入力項目チェック
  ''' </summary>
  ''' <returns></returns>
  Private Function CheckInputData() As Boolean
    ' 基本報酬単価
    Dim unitPrice As String = TxtBBasicUnitPrice.Text
    If (Not CheckNumberValidate(unitPrice)) Then
      MessageBox.Show(Me, "基本報酬単価は、半角数字で金額を入力してください [必須項目]")
      TxtBBasicUnitPrice.Focus()
      Return False
    End If

    ' みなし時間
    Dim timeSpan As String = TxtBTimeSpan.Text
    If (Not CheckNumberValidate(timeSpan)) Then
      MessageBox.Show(Me, "みなし時間は、半角数字で時間(分)を入力してください [必須項目]")
      TxtBTimeSpan.Focus()
      Return False
    End If

    Return True
  End Function

  ''' <summary>
  ''' 数値チェック
  ''' </summary>
  ''' <param name="value"></param>
  ''' <returns></returns>
  Private Function CheckNumberValidate(ByVal value As String) As Boolean
    ' 必須
    If (Not ValidateChecker.IsNotNullOrWhiteSpace(value)) Then
      Return False
    End If

    ' 半角数字
    If (Not ValidateChecker.IsHalfWidthNumberOnly(value)) Then
      Return False
    End If

    ' 整数値
    If (Not ValidateChecker.IsNumber(value)) Then
      Return False
    End If

    Return True
  End Function

  ''' <summary>
  ''' データ編集チェック
  ''' </summary>
  ''' <returns></returns>
  Private Function IsDataChanged() As Boolean
    Dim srcData As SystemEnvData = AppCommon.GetSystemEnvData()

    ' 基本報酬単価
    If (Not srcData.BaseUnitPrice.ToString().Equals(TxtBBasicUnitPrice.Text)) Then
      Return True
    End If

    ' みなし時間
    If (Not srcData.TimeSpan.ToString().Equals(TxtBTimeSpan.Text)) Then
      Return True
    End If

    ' 打刻なし
    If (Not srcData.PunchingInOut.Equals(CmbNoStamp.SelectedValue)) Then
      Return True
    End If

    ' 出勤打刻早すぎ
    If (Not srcData.PunchingInEarly.Equals(CmbClockInEarly.SelectedValue)) Then
      Return True
    End If

    ' 出勤打刻遅すぎ(遅刻)
    If (Not srcData.PunchingInLate.Equals(CmbClockInLate.SelectedValue)) Then
      Return True
    End If

    ' 退勤打刻遅すぎ
    If (Not srcData.PunchingOutLate.Equals(CmbClockOutLate.SelectedValue)) Then
      Return True
    End If

    ' 退勤打刻早すぎ(早退)
    If (Not srcData.PunchingOutEarly.Equals(CmbClockOutEarly.SelectedValue)) Then
      Return True
    End If

    Return False
  End Function

#End Region

End Class
