﻿Public Class DisplayData
	''' <summary>
	''' コマ単価
	''' </summary>
	''' <returns></returns>
	Public Property BasicUnitPrice As String

	''' <summary>
	''' みなし時間
	''' </summary>
	''' <returns></returns>
	Public Property TimeSpan As String
End Class
