﻿Imports MainApp.Data.Entity
''' <summary>
''' 教室時間割データ確認画面
''' </summary>
Public Class FrmCheckTimeTableSite
    Inherits BaseForm

#Region "フィールド・プロパティ・変数等"

    ' 画面名
    Private Const SCREEN_NAME As String = "教室時間割データ確認"

    ' CSV出力ファイル名接頭辞
    Private Const EXPORT_FILE_NAME_PREFIX = "教室時間割"

    ' 教室時間割データ確認画面サービス
    Private service As New TimetableSiteService()

    ''' <summary>
    ''' 表示条件クラス
    ''' </summary>
    Private Class Conditions
        ''' <summary>年</summary>
        Public Year As String
        ''' <summary>グループ</summary>
        Public Group As String
        ''' <summary>教室</summary>
        Public Site As String
    End Class

#End Region

#Region "コンストラクタ"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New(SCREEN_NAME)
        InitializeComponent()
    End Sub

#End Region

#Region "画面イベント処理"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmSiteTime_Load(sender As Object, e As EventArgs) Handles Me.Load
        EventOff()
        InitDisplay()
        EventOn()
    End Sub

    ''' <summary>
    ''' 年コンボ選択イベント処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbYear_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbYear.SelectionChangeCommitted
        EventOff()
        DisplayTimeTable()
        EventOn()
    End Sub

    ''' <summary>
    ''' グループ選択イベント処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbGroup_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbGroup.SelectionChangeCommitted
        EventOff()
        Dim group As String = cmbGroup.SelectedValue
        SiteFilter(group)
        EventOn()
    End Sub

    ''' <summary>
    ''' 教室選択イベント処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbSite_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbSite.SelectionChangeCommitted
        EventOff()
        DisplayTimeTable()
        EventOn()
    End Sub

    ''' <summary>
    ''' [CSV出力]ボタン押下イベント処理
    ''' DataGridViewに表示されている内容をCSV出力します。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub CsvOut_Click(sender As Object, e As EventArgs) Handles CsvOut.Click
        Dim defaultFileName As String = EXPORT_FILE_NAME_PREFIX & "_" & cmbYear.SelectedText & "年" & ".csv"

        If GridCsvHelper.ExportCsv(defaultFileName, dgvDataList) Then
            MessageBox.Show(Me, EXPORT_FILE_NAME_PREFIX & "データを出力しました")
        End If
    End Sub

#End Region

#Region "画面初期表示処理"

    ''' <summary>
    ''' 初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        ' 年選択
        DisplayYear()
        ' グループ選択
        DisplayGroup()
        ' 教室選択
        DisplaySite("")
        ' 時間割表示
        DisplayTimeTable()
    End Sub

#End Region

#Region "表示条件の選択項目データ設定処理"

    ''' <summary>
    ''' 年コンボデータ設定処理
    ''' </summary>
    Private Sub DisplayYear()
        Dim result As ResultData = service.GetYearHistory()
        Dim dtTable As DataTable = result.ResDataTable

        With cmbYear
            Dim newRow As DataRow = dtTable.NewRow()
            .DataSource = dtTable
            .DisplayMember = "Year_Name"
            .ValueMember = "Year"

            If .Items.Count > 0 Then
                .SelectedIndex = 0
            End If
        End With
    End Sub

    ''' <summary>
    ''' グループコンボデータ設定
    ''' </summary>
    Private Sub DisplayGroup()
        Dim result As ResultData = service.LoadGroupData()
        If result.Success Then
            Dim dtTable As DataTable = result.ResDataTable

            With cmbGroup
                Dim newRow As DataRow = dtTable.NewRow()
                newRow("Division_KND") = ""
                newRow("Division_Name") = "全グループ"
                dtTable.Rows.InsertAt(newRow, 0)

                .DataSource = dtTable
                .DisplayMember = "Division_Name"
                .ValueMember = "Division_KND"

                If .Items.Count > 0 Then
                    .SelectedIndex = 0
                End If
            End With
        End If
    End Sub

    ''' <summary>
    ''' 教室コンボデータ設定
    ''' </summary>
    ''' <param name="group">グループ</param>
    Private Sub DisplaySite(ByVal group As String)
        Dim result As ResultData = service.LoadSiteData(group)
        If result.Success Then
            Dim dtTable As DataTable = result.ResDataTable

            With cmbSite
                Dim newRow As DataRow = dtTable.NewRow()
                newRow("Site_Code") = ""
                newRow("Site_Name") = "全教室"
                dtTable.Rows.InsertAt(newRow, 0)

                .DataSource = dtTable
                .DisplayMember = "Site_Name"
                .ValueMember = "Site_Code"
            End With
        End If
    End Sub

#End Region

#Region "時間割データ表示処理"

    ''' <summary>
    ''' 時間割一覧表示処理
    ''' </summary>
    Private Sub DisplayTimeTable()
        Dim model As TimetableSiteModel = GetSearchConditions()
        Dim result As ResultData = service.LoadTimeTableData(model)
        If result.Success Then
            dgvDataList.DataSource = result.ResDataTable

            Dim def As New GridCheckTimeTableSiteStyle()
            def.Apply(dgvDataList)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgvDataList)

            With dgvDataList
                '' 非表示設定
                '.Columns(.Columns("Year").Index).Visible = False
                If .Rows.Count > 0 Then
                    .Rows(0).Selected = True
                End If
            End With
        End If
    End Sub

#End Region

#Region "フィルター処理"

    ''' <summary>
    ''' 教室のフィルター処理
    ''' </summary>
    ''' <param name="p_group"></param>
    Private Sub SiteFilter(ByVal p_group As String)
        DisplaySite(p_group)
        DisplayTimeTable()
    End Sub

    ''' <summary>
    ''' 時間割のフィルター処理
    ''' </summary>
    ''' <param name="group"></param>
    ''' <param name="room"></param>
    Private Sub TimetableFilter(ByVal group As String, ByVal room As String)
        DisplayTimeTable()

        If dgvDataList.Rows.Count > 0 Then
            dgvDataList.Rows(0).Selected = True
        End If

        ' 再描画(DataGridView反映)
        dgvDataList.Refresh()
    End Sub

#End Region

#Region "内部共通部品"

    ''' <summary>
    ''' 表示条件取得
    ''' </summary>
    ''' <returns></returns>
    Private Function GetSearchConditions() As TimetableSiteModel
        Return New TimetableSiteModel With {
            .TargetYear = IIf(cmbYear.SelectedValue = 0, "", cmbYear.SelectedValue.ToString()),
            .Group_Code = cmbGroup.SelectedValue,
            .Site_Code = cmbSite.SelectedValue
        }
    End Function

    ''' <summary>
    ''' イベント抑止
    ''' </summary>
    Private Sub EventOff()
        RemoveHandler cmbGroup.SelectionChangeCommitted, AddressOf cmbGroup_SelectionChangeCommitted
        RemoveHandler cmbSite.SelectionChangeCommitted, AddressOf cmbSite_SelectionChangeCommitted
    End Sub

    ''' <summary>
    ''' イベント発生
    ''' </summary>
    Private Sub EventOn()
        AddHandler cmbGroup.SelectionChangeCommitted, AddressOf cmbGroup_SelectionChangeCommitted
        AddHandler cmbSite.SelectionChangeCommitted, AddressOf cmbSite_SelectionChangeCommitted
    End Sub

    ''' <summary>
    ''' 画面解像度対応
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmCheckTimeTableSite_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        Dim size As Size = WinApiHelper.ScreenSize(Me)
        Dim mWidth As Integer = 0
        Dim mHeight As Integer = 0

        If Me.Width > size.Width Then
            mWidth = Me.Width - size.Width
            Me.Width = size.Width
            dgvDataList.Width = dgvDataList.Width - mWidth
        End If

        If Me.Height > size.Height Then
            mHeight = Me.Height - size.Height
            Me.Height = size.Height
            dgvDataList.Height = dgvDataList.Height - mHeight
        End If

        CsvOut.Location = New Point(CsvOut.Location.X - mWidth, CsvOut.Location.Y - mHeight)
    End Sub

#End Region

End Class