﻿Imports MainApp.Data.Dto
Imports MasterImport.MainApp.Data.Dto

''' <summary>
''' 時間割設定データ取込画面ViewController
''' 
''' 以下の時間割データのビューコントローラです。
''' ・時間パターン
''' ・教室時間割データ
''' ・クラス別時間割データ
''' </summary>
Public Class ImportTimetableDataViewController
    Implements ICsvImportView

    ''' <summary>時間割設定データ取込画面Form</summary>
    Private ReadOnly _form As FrmImportTimetableData

    ''' <summary>時間割設定データ取込画面Service</summary>
    Private ReadOnly _service As ImportTimetableDataService


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="frm">時間割設定データ取込画面インスタンス</param>
    Public Sub New(ByVal frm As Form)
        _form = frm
        _service = New ImportTimetableDataService
    End Sub


    Public Function InitialDisplayData() As ImportTimetableOutputDto
        Return _service.InitialDisplayData()
    End Function

    ''' <summary>
    ''' 教室時間割[取込]ボタン押下要求
    ''' </summary>
    ''' <param name="param"></param>
    Public Function CsvImport(param As CsvImportParameterDto) As CsvImportResultOutputDto
        Dim result As New ImportResultInfo

        ProcessingService.Show(_form, "データ取込中...")

        result = _service.CsvImport(param)

        ProcessingService.Close()

        ' エラー
        If result.HasError Then
            If result.ErrorType = ImportDataErrorType.DataNotFound Then
                MessageBox.Show(MessageIdConst.MSGID_E3001)
            ElseIf result.ErrorType = ImportDataErrorType.FormatError Then
                MessageBox.Show(MessageIdConst.MSGID_E3002)
            ElseIf result.ErrorType = ImportDataErrorType.DuplicateError Then
                MessageBox.Show(MessageIdConst.MSGID_E3003)
            ElseIf result.ErrorType = ImportDataErrorType.IncludingNonEligible Then
                MessageBox.Show(MessageIdConst.MSGID_E3201)
            ElseIf result.ErrorType = ImportDataErrorType.IncludingNonEligible Then
                MessageBox.Show(MessageIdConst.MSGID_E3202)
            Else
                Dim errorCount As Integer = result.ErrorCount
                If (errorCount > 0) Then
                    Dim factory As New CsvFactory(param.CsvType)
                    Dim frmError As Form = New FrmValidationErrors(result.ValidationResultList, factory.CreateCsv(param.FilePath))
                    frmError.ShowDialog()
                End If
            End If
            Return CsvImportResultOutputDto.Fail(result.ExecutCount, result.ExecutDate, result.ErrorType)
        End If

        'DisplayExecutionResults(result)

        Return CsvImportResultOutputDto.Success(result.ExecutCount, result.ExecutDate)

    End Function

    ''' <summary>
    ''' 画面パラメタ→DTO変換
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Private Function ParamToDto(param As CsvImportParameterDto) As HistoryImportDto
        Dim dto As New HistoryImportDto

        dto.CsvType = DataType(param)
        dto.Category = Category(param)
        dto.DataName = DataName(param)
        dto.FileName = param.FilePath
        dto.FiscalYearMonth = param.TargetDate.Year & param.TargetDate.Month.ToString("D2")
        dto.ExecutionDate = Now
        dto.ExecutionUser = Environment.UserName
        dto.ExecutionPc = Environment.MachineName
        dto.ExecutionStatus = 0
        dto.ExecutionCount = 0
        dto.CreateUser = Environment.UserName
        dto.CreateDate = Now
        Return dto
    End Function

    ''' <summary>
    ''' DTO変換：データタイプ
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Private Function DataType(param As CsvImportParameterDto) As Integer
        Return param.CsvType
    End Function

    ''' <summary>
    ''' DTO変換：データカテゴリ
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Private Function Category(param As CsvImportParameterDto) As String
        If param.CsvType > 0 AndAlso param.CsvType < 100 Then
            Return "M"
        Else
            Return "T"
        End If
    End Function

    ''' <summary>
    ''' DTO変換：データ名
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Private Function DataName(param As CsvImportParameterDto) As String
        Dim dataNameDic As New Dictionary(Of Integer, String) From
        {
          {1, "時間パターン"},
          {2, "教室時間割"},
          {3, "クラス別時間割"},
          {4, ""},
          {5, ""},
          {101, "打刻データ"},
          {102, "出講データ"},
          {103, "出講データ（講習）"},
          {104, "代講実績データ"},
          {105, "業務届データ"},
          {106, "打刻外業務給"}
        }
        Return dataNameDic(param.CsvType)
    End Function

    ''' <summary>
    ''' インポート結果画面表示
    ''' </summary>
    ''' <param name="resultDto"></param>
    Public Sub DisplayExecutionResults(ByVal resultDto As ImportResultInfo)
        Dim dto As New ImportResultsDto
        dto.ExecutDate = resultDto.ExecutDate
        dto.ExecutCount = IIf(resultDto.HasError, resultDto.ErrorCount, resultDto.ExecutCount)
        dto.StatusString = IIf(resultDto.HasError, "状態：異常終了", "状態：正常終了")
        dto.Success = IIf(resultDto.HasError, False, True)
        '_form.DisplayExecutionResults(dto)
        'Return CsvImportResultOutputDto.Success(result.DataCount, result.ProcessDateTime)
    End Sub

End Class
