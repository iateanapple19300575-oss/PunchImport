﻿Imports ImportType
Imports MainApp.Data.Dto
Imports MasterImport.MainApp.Data.Dto

''' <summary>
''' 時間割設定データ取込サービス
''' </summary>
Public Class ImportTimetableDataService

    Private _param As CsvImportParameterDto

    ''' <summary>
    ''' 時間パターントラン
    ''' </summary>
    Private timePatternTran As New TimePatternTran()

    ''' <summary>
    ''' インポート履歴トラン
    ''' </summary>
    Private importHistorysTran As New ImportHistoryRepository()


    Private _components As CsvImportMasterComponents

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="param"></param>
    Public Sub New(ByVal param As CsvImportParameterDto)
        _components = MasterImportComponentFactory.Create(param.CsvType, param)
        _param = param
    End Sub

    ''' <summary>
    ''' 画面初期表示データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function InitialDisplayData() As ImportTimetableOutputDto
        Dim screenData As New InitDisplayData

        '' 対象期間
        'Dim resultData As ResultData
        'resultData = timePatternTran.GetStoragePeriodList()
        'If (Not resultData.Success) Then
        '    Return screenData
        'End If

        ' 対象期間(各月のX日～Y日)
        'screenData.TimePatternPeriodList = resultData.ResDataTable

        Dim model As New ImportTimetableOutputDto
        ' TODO: 対象年月度要修正
        Dim list As List(Of HistoryImportDto)
        list = importHistorysTran.HistoryFinalDateAll()
        For Each rec As HistoryImportDto In list
            ' 時間パターン：最終取込件数、最終取込日時
            If rec.CsvType = ImportCsvType.TimePattern Then
                model.TimePatternInfo = New ProcessResultInfoDto With {
                    .Count = rec.ExecutionCount,
                    .ExecDate = rec.ExecutionDate,
                    .Status = rec.ExecutionStatus
                }
            End If

            ' 教室時間割：最終取込件数、最終取込日時
            If rec.CsvType = ImportCsvType.TimeTableSite Then
                model.TimetableSiteInfo = New ProcessResultInfoDto With {
                    .Count = rec.ExecutionCount,
                    .ExecDate = rec.ExecutionDate,
                    .Status = rec.ExecutionStatus
                }
            End If

            ' クラス時間割：最終取込件数、最終取込日時
            If rec.CsvType = ImportCsvType.TimeTableClass Then
                model.TimetableClassInfo = New ProcessResultInfoDto With {
                    .Count = rec.ExecutionCount,
                    .ExecDate = rec.ExecutionDate,
                    .Status = rec.ExecutionStatus
                }
            End If
        Next

        Return model
    End Function

    ''' <summary>
    ''' CSV取込要求
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function CsvImport(param As CsvImportParameterDto) As ImportResultInfo
        Dim _importer As IMasterCsvImporter
        _components = MasterImportComponentFactory.Create(param.CsvType, param)

        param.Phase = 0
        param.CourseType = 0
        param.TargetDate = AppState.TargetYearMonth
        param.PeriodDates = Nothing

        Select Case param.CsvType
            Case ImportCsvType.TimePattern
                _importer = New ImportTimePatternImporter(param, _components)
                param.DataType = ImportDataType.TimePattern
            Case ImportCsvType.TimeTableSite
                _importer = New ImportTimetableSiteImporter(param, _components)
                param.DataType = ImportDataType.TimeTableSite
            Case ImportCsvType.TimeTableClass
                _importer = New ImportTimetableClassImporter(param, _components)
                param.DataType = ImportDataType.TimeTableClass
            Case Else
                Throw New NotSupportedException("未対応の CSV 種類です: " & param.CsvType)
        End Select

        Dim result As New ImportResultInfo
        result = _importer.Execute()

        Return result
    End Function

End Class
