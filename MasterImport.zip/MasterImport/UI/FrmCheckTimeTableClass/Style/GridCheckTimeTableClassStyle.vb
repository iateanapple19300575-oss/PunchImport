﻿Public Class GridCheckTimeTableClassStyle
    Implements IGridColumnDefinition

    ''' <summary>
    ''' 教室時間割データの一覧に必要な列定義を作成し、指定された DataGridView に適用する。
    ''' </summary>
    ''' <param name="grid"></param>
    Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 教室時間割一覧の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("Site_Code", "教室", 50).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Grade", "学年", 50).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Class_Code", "クラス", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Category_Name", "設定区分", 100).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Target_Period", "対象期間", 100).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build()
        }

        ' 開始1～終了9
        For i As Integer = 1 To 9
            defs.Add(
                New GridColumnBuilder("Start_Time_" & i.ToString(), "開始" & i.ToString(), 60).
                    Align(DataGridViewContentAlignment.MiddleCenter).
                    Sort(False).
                    CellReadOnly().
                    Build())
            defs.Add(
            New GridColumnBuilder("End_Time_" & i.ToString(), "終了" & i.ToString(), 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build())
        Next

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
        grid.AutoGenerateColumns = False

        ' 列定義を DataGridView に追加
        For Each def In defs
            grid.Columns.Add(GridColumnFactory.Create(def))
        Next

    End Sub
End Class
