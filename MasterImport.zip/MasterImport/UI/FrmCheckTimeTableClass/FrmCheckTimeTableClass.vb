﻿Imports MainApp.Data.Entity
''' <summary>
''' クラス別室時間割データ確認画面
''' </summary>
Public Class FrmCheckTimeTableClass
    Inherits BaseForm

#Region "フィールド・プロパティ・変数等"

    ' 画面名
    Private Const SCREEN_NAME As String = "クラス別室時間割データ確認画面"

    ' CSV出力ファイル名接頭辞
    Private Const EXPORT_FILE_NAME_PREFIX = "クラス別時間割"

    ' クラス別室時間割データ確認画面サービス
    Private service As New TimetableClassService()

    ''' <summary>
    ''' 表示条件クラス
    ''' </summary>
    Private Class Conditions
        ''' <summary>グループ</summary>
        Public Group As String
        ''' <summary>教室</summary>
        Public Site As String
        ''' <summary>学年</summary>
        Public Grade As String
        ''' <summary>クラス</summary>
        Public [Class] As String
        ''' <summary>過去データを含まない</summary>
        Public NotIncludingPast As Boolean
    End Class

#End Region

#Region "コンストラクタ"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New(SCREEN_NAME)
        InitializeComponent()
    End Sub

#End Region

#Region "画面イベント処理"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmSiteTime_Load(sender As Object, e As EventArgs) Handles Me.Load
        EventOff()
        InitDisplay()
        EventOn()
    End Sub

    ''' <summary>
    ''' グループ選択イベント処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbGroup_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbGroup.SelectionChangeCommitted
        EventOff()
        Dim group As String = cmbGroup.SelectedValue
        DisplaySite(group)
        DisplayTimeTable()
        'SiteFilter(group)
        EventOn()
    End Sub

    ''' <summary>
    ''' 教室選択イベント処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbSite_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbSite.SelectionChangeCommitted
        EventOff()
        SiteFilter()
        'DisplayGrade()
        'DisplayClass()
        DisplayTimeTable()
        EventOn()
    End Sub

    ''' <summary>
    ''' 学年選択イベント処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbGrade_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbGrade.SelectionChangeCommitted
        EventOff()
        DisplayTimeTable()
        EventOn()
    End Sub

    ''' <summary>
    ''' クラス選択イベント処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbClass_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbClass.SelectionChangeCommitted
        EventOff()
        DisplayTimeTable()
        EventOn()
    End Sub

    ''' <summary>
    ''' [過去データを表示しない]チェックボックス押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub chkNotIncludingPast_CheckedChanged(sender As Object, e As EventArgs) Handles chkNotIncludingPast.CheckedChanged
        EventOff()
        DisplayTimeTable()
        EventOn()
    End Sub

    ''' <summary>
    ''' [CSV出力]ボタン押下イベント処理
    ''' DataGridViewに表示されている内容をCSV出力します。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub CsvOut_Click(sender As Object, e As EventArgs) Handles CsvOut.Click
        Dim defaultFileName As String = EXPORT_FILE_NAME_PREFIX & "_" & DateTime.Now.ToString("yyyyMMdd_HHmmss") & ".csv"

        If GridCsvHelper.ExportCsv(defaultFileName, dgvDataList) Then
            MessageBox.Show(Me, EXPORT_FILE_NAME_PREFIX & "データを出力しました")
        End If
    End Sub

#End Region

#Region "画面初期表示処理"

    ''' <summary>
    ''' 初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        ' グループ選択
        DisplayGroup()
        ' 教室選択
        DisplaySite("")
        ' 学年選択
        DisplayGrade("")
        ' クラス選択
        DisplayClass("")
        ' 時間割表示
        DisplayTimeTable()
    End Sub

#End Region

#Region "表示条件の選択項目データ設定処理"

    ''' <summary>
    ''' グループコンボデータ設定
    ''' </summary>
    Private Sub DisplayGroup()
        Dim result As ResultData = service.LoadGroupData()
        If result.Success Then
            Dim dtTable As DataTable = result.ResDataTable

            With cmbGroup
                Dim newRow As DataRow = dtTable.NewRow()
                newRow("Division_KND") = ""
                newRow("Division_Name") = "全グループ"
                dtTable.Rows.InsertAt(newRow, 0)

                .DataSource = dtTable
                .DisplayMember = "Division_Name"
                .ValueMember = "Division_KND"

                If .Items.Count > 0 Then
                    .SelectedIndex = 0
                End If
            End With
        End If
    End Sub

    ''' <summary>
    ''' 教室コンボデータ設定
    ''' </summary>
    ''' <param name="group">グループ</param>
    Private Sub DisplaySite(ByVal group As String)
        Dim result As ResultData = service.LoadSiteData(group)
        If result.Success Then
            Dim dtTable As DataTable = result.ResDataTable

            With cmbSite
                Dim newRow As DataRow = dtTable.NewRow()
                newRow("Site_Code") = ""
                newRow("Site_Name") = "全教室"
                dtTable.Rows.InsertAt(newRow, 0)

                .DataSource = dtTable
                .DisplayMember = "Site_Name"
                .ValueMember = "Site_Code"
            End With
        End If
    End Sub

    ''' <summary>
    ''' 学年コンボデータ設定
    ''' </summary>
    Private Sub DisplayGrade(ByVal site As String)
        Dim result As ResultData = service.LoadGradeData(site)
        If result.Success Then
            Dim dtTable As DataTable = result.ResDataTable

            With cmbGrade
                Dim newRow As DataRow = dtTable.NewRow()
                newRow("Grade") = ""
                newRow("Grade_Name") = "全学年"
                dtTable.Rows.InsertAt(newRow, 0)

                .DataSource = dtTable
                .DisplayMember = "Grade_Name"
                .ValueMember = "Grade"
            End With
        End If
    End Sub

    ''' <summary>
    ''' クラスコンボデータ設定
    ''' </summary>
    Private Sub DisplayClass(ByVal site As String)
        Dim result As ResultData = service.LoadClassData(site)
        If result.Success Then
            Dim dtTable As DataTable = result.ResDataTable

            With cmbClass
                Dim newRow As DataRow = dtTable.NewRow()
                newRow("Class_Code") = ""
                newRow("Class_Name") = "全クラス"
                dtTable.Rows.InsertAt(newRow, 0)

                .DataSource = dtTable
                .DisplayMember = "Class_Name"
                .ValueMember = "Class_Code"
            End With
        End If
    End Sub

#End Region

#Region "時間割データ表示処理"

    ''' <summary>
    ''' 時間割一覧表示処理
    ''' </summary>
    Private Sub DisplayTimeTable()
        Dim model As TimetableClassModel = GetSearchConditions()
        Dim result As New ResultData
        result = service.LoadTimeTableData(model)
        If result.Success Then
            If dgvDataList.Rows.Count > 0 Then
                dgvDataList.DataSource = Nothing
                dgvDataList.Rows.Clear()
            End If
            dgvDataList.DataSource = result.ResDataTable

            Dim def As New GridCheckTimeTableClassStyle()
            def.Apply(dgvDataList)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgvDataList)

            With dgvDataList
                If .Rows.Count > 0 Then
                    .Rows(0).Selected = True
                End If
            End With
        End If
        dgvDataList.Refresh()
    End Sub

#End Region

#Region "フィルター処理"

    ''' <summary>
    ''' 教室のフィルター処理
    ''' </summary>
    Private Sub SiteFilter()
        Dim site As String = cmbSite.SelectedValue
        DisplayGrade(site)
        DisplayClass(site)
        'DisplayTimeTable()
    End Sub

    ''' <summary>
    ''' 時間割のフィルター処理
    ''' </summary>
    ''' <param name="group"></param>
    ''' <param name="room"></param>
    Private Sub TimetableFilter(ByVal group As String, ByVal room As String)
        DisplayTimeTable()

        If dgvDataList.Rows.Count > 0 Then
            dgvDataList.Rows(0).Selected = True
        End If

        ' 再描画(DataGridView反映)
        dgvDataList.Refresh()
    End Sub

#End Region

#Region "内部共通部品"

    ''' <summary>
    ''' 表示条件取得
    ''' </summary>
    ''' <returns></returns>
    Private Function GetSearchConditions() As TimetableClassModel
        Return New TimetableClassModel With {
            .TargetYear = AppState.TargetYearMonth,
            .Group_Code = cmbGroup.SelectedValue,
            .Site_Code = cmbSite.SelectedValue,
            .Grade = cmbGrade.SelectedValue,
            .Class_Code = cmbClass.SelectedValue,
            .NotIncludingPast = chkNotIncludingPast.Checked
        }
    End Function

    ''' <summary>
    ''' イベント抑止
    ''' </summary>
    Private Sub EventOff()
        RemoveHandler cmbGroup.SelectionChangeCommitted, AddressOf cmbGroup_SelectionChangeCommitted
        RemoveHandler cmbSite.SelectionChangeCommitted, AddressOf cmbSite_SelectionChangeCommitted
        RemoveHandler cmbGrade.SelectionChangeCommitted, AddressOf cmbGrade_SelectionChangeCommitted
        RemoveHandler cmbClass.SelectionChangeCommitted, AddressOf cmbClass_SelectionChangeCommitted
    End Sub

    ''' <summary>
    ''' イベント発生
    ''' </summary>
    Private Sub EventOn()
        AddHandler cmbGroup.SelectionChangeCommitted, AddressOf cmbGroup_SelectionChangeCommitted
        AddHandler cmbSite.SelectionChangeCommitted, AddressOf cmbSite_SelectionChangeCommitted
        AddHandler cmbGrade.SelectionChangeCommitted, AddressOf cmbGrade_SelectionChangeCommitted
        AddHandler cmbClass.SelectionChangeCommitted, AddressOf cmbClass_SelectionChangeCommitted
    End Sub

    ''' <summary>
    ''' 画面解像度対応
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmCheckTimeTableClass_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        Dim size As Size = WinApiHelper.ScreenSize(Me)
        Dim mWidth As Integer = 0
        Dim mHeight As Integer = 0

        If Me.Width > size.Width Then
            mWidth = Me.Width - size.Width
            Me.Width = size.Width
            dgvDataList.Width = dgvDataList.Width - mWidth
        End If

        If Me.Height > size.Height Then
            mHeight = Me.Height - size.Height
            Me.Height = size.Height
            dgvDataList.Height = dgvDataList.Height - mHeight
        End If

        CsvOut.Location = New Point(CsvOut.Location.X - mWidth, CsvOut.Location.Y - mHeight)
    End Sub

#End Region

End Class