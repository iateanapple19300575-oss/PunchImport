﻿Imports LecturePay.Common.Infrastructure
Imports Nts.Freamwork.Common.Utilities

Public Class FrmLectureFeeCoefficient
    Inherits BaseForm

    ' 編集モード
    Private Enum EditMode
        None
        Add
        Edit
    End Enum

    ' 編集モード
    Private _mode As EditMode = EditMode.None


    ''' <summary>
    ''' 更新モード状態管理
    ''' </summary>
    ''' <returns></returns>
    Private Property UpDateMode As Boolean = False

    ''' <summary>
    ''' 更新対象のID
    ''' </summary>
    ''' <returns></returns>
    Private Property TargetID As String = ""

    ''' <summary>
    ''' 画面用サービスクラス
    ''' </summary>
    Dim service As New LectureFeeCoefficientyService


    Dim siteService As New TimetableSiteService

    Dim dtSite As New DataTable

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("授業給係数設定")
        InitializeComponent()
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmTuitionFeeCoefficientSetting_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' 初期表示
        InitDisplay()

        AppCommon.SetComboForHalfYear(cmbHalfYear)
        'AppCommon.SetComboForYear(cmbYear)
        cmbYear.SelectedValue = DateTime.Now.Year
        SetEditMode(EditMode.None)
    End Sub

    Private Sub SetEditMode(mode As EditMode)
        _mode = mode

        btnAdd.Enabled = (mode = EditMode.None)
        btnEdit.Enabled = (mode = EditMode.None AndAlso dgvLectureFee.CurrentRow IsNot Nothing)
        btnDelete.Enabled = (mode = EditMode.None AndAlso dgvLectureFee.CurrentRow IsNot Nothing)
        btnSave.Enabled = (mode <> EditMode.None)
    End Sub


#Region "画面イベント処理"

    ''' <summary>
    ''' [追加]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ClearInput()
        SetEditMode(EditMode.Add)
    End Sub

    ''' <summary>
    ''' 一覧ダブルクリックイベント（修正モードへ）
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub dgvLectureFee_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvLectureFee.CellDoubleClick
        BindRowToInput()
        SetEditMode(EditMode.Edit)
    End Sub

    ''' <summary>
    ''' [編集]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        ' 選択行がないときは捨てる
        If dgvLectureFee.CurrentRow Is Nothing Then
            Return
        End If

        BindRowToInput()
        SetEditMode(EditMode.Edit)
    End Sub

    ''' <summary>
    ''' [削除]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        If MessageBox.Show("削除しますがよろしいですか？", "確認", MessageBoxButtons.YesNo) = DialogResult.No Then Return

        Try
            Dim targetDate As String = dgvLectureFee.SelectedRows.Item(0).Cells(0).Value
            Dim param As New DaoParameter
            param.Add(LectureWagePercentageDao.KEY_YEAR, targetDate)
            param.Add(LectureWagePercentageDao.KEY_HALF_YEAR, targetDate)
            param.Add(LectureWagePercentageDao.KEY_SITE_CODE, targetDate)
            param.Add(LectureWagePercentageDao.KEY_GRADE, targetDate)
            param.Add(LectureWagePercentageDao.KEY_CLASS_CODE, targetDate)
            param.Add(LectureWagePercentageDao.KEY_LECTURE_COEFFICIENT, targetDate)
            param.Add(LectureWagePercentageDao.KEY_REMARKS, targetDate)
            service.Delete(param)
            InitDisplay()
        Catch ex As Exception

        End Try

    End Sub

    ''' <summary>
    ''' [保存]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Try
            ' 入力値取得
            Dim data As New LectureWagePercentageData


            data = GetInputData()

            ' 未入力確認
            Dim message As String = ""
            Dim errorMsg As String = ""
            message = EmptyValidation(data)
            If StringUtil.IsNotNullOrWhiteSpace(message) Then
                errorMsg = message & " を入力してください"
                MessageBox.Show(Me, errorMsg, "入力エラー", MessageBoxButtons.OK, MessageBoxIcon.Hand)
                Return
            End If

            ' 数値の確認
            message = NumberValidation(data)
            If StringUtil.IsNotNullOrWhiteSpace(message) Then
                errorMsg = message & " は、半角数字で入力してください"
                MessageBox.Show(Me, errorMsg, "入力エラー", MessageBoxButtons.OK, MessageBoxIcon.Hand)
                Return
            End If

            If Not UpDateMode Then
                service.Add(data)
            Else
                Dim param As New DaoParameter
                param.Add(LectureWagePercentageDao.KEY_ID, TargetID)
                service.Update(param, data)
            End If

            UpDateMode = False
            InitDisplay()
        Catch ex As Exception
            MessageBox.Show("保存に失敗しました。" & Environment.NewLine & ex.Message)

        End Try
    End Sub

#End Region

#Region "表示処理部品"

    ''' <summary>
    ''' 初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        Clear()
        DbReload()
        Me.dtSite = siteService.SetComboForSiteCodeWithAll(cmbSiteCode)
    End Sub

    ''' <summary>
    ''' 一覧データ再読み込み処理
    ''' </summary>
    Private Sub DbReload()
        Dim dt As New DataTable

        Try
            dt = service.GetInitDisplayData()
            DisplayBasicWorkSalaryDetails(dt)

        Catch ex As Exception
            MessageBox.Show("データの読み込みに失敗しました。" & Environment.NewLine & ex.Message)

        End Try
    End Sub

    ''' <summary>
    ''' 入力項目の初期化
    ''' </summary>
    Private Sub Clear()
        'TargetDate = Date.Today
        'dtpEffectiveDate.Value = TargetDate
        ClearInput()
    End Sub

    ''' <summary>
    ''' DataGridView の表示属性設定
    ''' </summary>
    ''' <param name="dt"></param>
    Private Sub DisplayBasicWorkSalaryDetails(ByVal dt As DataTable)
        Dim def As New GridLectureFeeCoefficientStyle()
        def.Apply(Me.dgvLectureFee)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(Me.dgvLectureFee)
        dgvLectureFee.DataSource = dt
    End Sub


#End Region


    ''' <summary>
    ''' 入力欄クリア
    ''' </summary>
    Private Sub ClearInput()
        txtGrade.Text = ""
        txtClassCode.Text = ""
        txtLectureCoefficient.Text = ""
    End Sub

    ''' <summary>
    ''' 入力データを取得する。
    ''' </summary>
    ''' <returns></returns>
    Private Function GetInputData() As LectureWagePercentageData
        Dim data As New LectureWagePercentageData
        data.Year = cmbYear.SelectedItem
        data.Half_Year = cmbHalfYear.SelectedValue
        data.Site_Code = cmbSiteCode.SelectedValue
        data.Grade = txtGrade.Text
        data.Class_Code = txtClassCode.Text
        data.Lecture_Coefficient = txtLectureCoefficient.Text
        data.Remarks = ""
        Return data
    End Function

    ''' <summary>
    ''' 現在の選択行データを入力フィールドに表示する。
    ''' </summary>
    Private Sub BindRowToInput()
        Dim siteCode As String = dgvLectureFee.SelectedRows.Item(0).Cells(3).Value

        cmbSiteCode.SelectedText = siteCode
        txtGrade.Text = dgvLectureFee.SelectedRows.Item(0).Cells(4).Value
        txtClassCode.Text = dgvLectureFee.SelectedRows.Item(0).Cells(5).Value
        txtLectureCoefficient.Text = dgvLectureFee.SelectedRows.Item(0).Cells(6).Value
        TargetID = dgvLectureFee.SelectedRows.Item(0).Cells(0).Value
    End Sub


    ''' <summary>
    ''' 未入力チェック
    ''' </summary>
    ''' <param name="data"></param>
    ''' <returns></returns>
    Private Function EmptyValidation(ByVal data As LectureWagePercentageData) As String
        Dim result As String = ""

        If cmbYear.SelectedIndex <= 0 Then
            result = "対象期間（年）が選択して下さい"
            Return result
        End If

        If cmbHalfYear.SelectedIndex <= 0 Then
            result = "対象期間（期）を選択して下さい"
            Return result
        End If

        If cmbSiteCode.SelectedIndex <= 0 Then
            result = "教室を選択して下さい"
            Return result
        End If

        If String.IsNullOrEmpty(txtGrade.Text) Then
            result = "学年を入力して下さい"
            Return result
        End If

        If String.IsNullOrEmpty(txtClassCode.Text) Then
            result = "クラスコードを入力して下さい"
            Return result
        End If

        If String.IsNullOrEmpty(txtLectureCoefficient.Text) Then
            result = "係数を入力して下さい"
            Return result
        End If

        Return result
    End Function

    ''' <summary>
    ''' 数値チェック
    ''' </summary>
    ''' <param name="data"></param>
    ''' <returns></returns>
    Private Function NumberValidation(ByVal data As LectureWagePercentageData) As String
        Dim result As String = ""

        If Not ValidateChecker.IsHalfWidthNumberOnly(txtGrade.Text) Then
            result = "学年"
            Return result
        End If

        If Not ValidateChecker.IsHalfWidthNumberOnly(txtClassCode.Text) Then
            result = "クラスコード"
            Return result
        End If

        If Not ValidateChecker.IsHalfWidthNumberOnly(txtLectureCoefficient.Text) Then
            result = "係数"
            Return result
        End If

        Return result
    End Function

End Class