﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmLectureFeeCoefficient
	'Inherits System.Windows.Forms.Form
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()>
	Private Sub InitializeComponent()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.btnDelete = New System.Windows.Forms.Button()
    Me.cmbHalfYear = New System.Windows.Forms.ComboBox()
    Me.cmbYear = New System.Windows.Forms.ComboBox()
    Me.dgvLectureFee = New System.Windows.Forms.DataGridView()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.cmbSiteCode = New System.Windows.Forms.ComboBox()
    Me.GroupBox1 = New System.Windows.Forms.GroupBox()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.txtClassCode = New System.Windows.Forms.TextBox()
    Me.txtLectureCoefficient = New System.Windows.Forms.TextBox()
    Me.btnAdd = New System.Windows.Forms.Button()
    Me.txtGrade = New System.Windows.Forms.TextBox()
    Me.btnEdit = New System.Windows.Forms.Button()
    Me.btnSave = New System.Windows.Forms.Button()
    CType(Me.dgvLectureFee, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox1.SuspendLayout()
    Me.SuspendLayout()
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(190, 90)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(34, 17)
    Me.Label3.TabIndex = 3
    Me.Label3.Text = "学年"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(110, 30)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(21, 17)
    Me.Label2.TabIndex = 1
    Me.Label2.Text = "年"
    '
    'btnDelete
    '
    Me.btnDelete.Location = New System.Drawing.Point(533, 658)
    Me.btnDelete.Name = "btnDelete"
    Me.btnDelete.Size = New System.Drawing.Size(100, 30)
    Me.btnDelete.TabIndex = 11
    Me.btnDelete.Text = "削除"
    Me.btnDelete.UseVisualStyleBackColor = True
    '
    'cmbHalfYear
    '
    Me.cmbHalfYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbHalfYear.FormattingEnabled = True
    Me.cmbHalfYear.Location = New System.Drawing.Point(140, 26)
    Me.cmbHalfYear.Name = "cmbHalfYear"
    Me.cmbHalfYear.Size = New System.Drawing.Size(80, 25)
    Me.cmbHalfYear.TabIndex = 2
    '
    'cmbYear
    '
    Me.cmbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbYear.FormattingEnabled = True
    Me.cmbYear.Location = New System.Drawing.Point(20, 26)
    Me.cmbYear.Name = "cmbYear"
    Me.cmbYear.Size = New System.Drawing.Size(80, 25)
    Me.cmbYear.TabIndex = 0
    '
    'dgvLectureFee
    '
    Me.dgvLectureFee.AllowUserToAddRows = False
    Me.dgvLectureFee.AllowUserToDeleteRows = False
    Me.dgvLectureFee.AllowUserToResizeColumns = False
    Me.dgvLectureFee.AllowUserToResizeRows = False
    Me.dgvLectureFee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.dgvLectureFee.Location = New System.Drawing.Point(13, 157)
    Me.dgvLectureFee.Margin = New System.Windows.Forms.Padding(4)
    Me.dgvLectureFee.MultiSelect = False
    Me.dgvLectureFee.Name = "dgvLectureFee"
    Me.dgvLectureFee.ReadOnly = True
    Me.dgvLectureFee.RowHeadersWidth = 20
    Me.dgvLectureFee.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
    Me.dgvLectureFee.RowTemplate.Height = 21
    Me.dgvLectureFee.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
    Me.dgvLectureFee.Size = New System.Drawing.Size(620, 482)
    Me.dgvLectureFee.TabIndex = 10
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(30, 90)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(34, 17)
    Me.Label1.TabIndex = 1
    Me.Label1.Text = "教室"
    '
    'cmbSiteCode
    '
    Me.cmbSiteCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbSiteCode.FormattingEnabled = True
    Me.cmbSiteCode.Location = New System.Drawing.Point(33, 110)
    Me.cmbSiteCode.Name = "cmbSiteCode"
    Me.cmbSiteCode.Size = New System.Drawing.Size(141, 25)
    Me.cmbSiteCode.TabIndex = 2
    '
    'GroupBox1
    '
    Me.GroupBox1.Controls.Add(Me.cmbHalfYear)
    Me.GroupBox1.Controls.Add(Me.cmbYear)
    Me.GroupBox1.Controls.Add(Me.Label2)
    Me.GroupBox1.Location = New System.Drawing.Point(13, 10)
    Me.GroupBox1.Name = "GroupBox1"
    Me.GroupBox1.Size = New System.Drawing.Size(240, 67)
    Me.GroupBox1.TabIndex = 0
    Me.GroupBox1.TabStop = False
    Me.GroupBox1.Text = "対象期間"
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(258, 90)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(86, 17)
    Me.Label4.TabIndex = 5
    Me.Label4.Text = "クラスコード"
    '
    'Label5
    '
    Me.Label5.AutoSize = True
    Me.Label5.Location = New System.Drawing.Point(370, 90)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(34, 17)
    Me.Label5.TabIndex = 7
    Me.Label5.Text = "係数"
    '
    'txtClassCode
    '
    Me.txtClassCode.ImeMode = System.Windows.Forms.ImeMode.Off
    Me.txtClassCode.Location = New System.Drawing.Point(277, 110)
    Me.txtClassCode.Name = "txtClassCode"
    Me.txtClassCode.Size = New System.Drawing.Size(39, 28)
    Me.txtClassCode.TabIndex = 6
    '
    'txtLectureCoefficient
    '
    Me.txtLectureCoefficient.ImeMode = System.Windows.Forms.ImeMode.Off
    Me.txtLectureCoefficient.Location = New System.Drawing.Point(373, 110)
    Me.txtLectureCoefficient.Name = "txtLectureCoefficient"
    Me.txtLectureCoefficient.Size = New System.Drawing.Size(39, 28)
    Me.txtLectureCoefficient.TabIndex = 8
    '
    'btnAdd
    '
    Me.btnAdd.Location = New System.Drawing.Point(296, 658)
    Me.btnAdd.Name = "btnAdd"
    Me.btnAdd.Size = New System.Drawing.Size(100, 30)
    Me.btnAdd.TabIndex = 9
    Me.btnAdd.Text = "追加"
    Me.btnAdd.UseVisualStyleBackColor = True
    '
    'txtGrade
    '
    Me.txtGrade.ImeMode = System.Windows.Forms.ImeMode.Off
    Me.txtGrade.Location = New System.Drawing.Point(194, 110)
    Me.txtGrade.Name = "txtGrade"
    Me.txtGrade.Size = New System.Drawing.Size(39, 28)
    Me.txtGrade.TabIndex = 4
    '
    'btnEdit
    '
    Me.btnEdit.Location = New System.Drawing.Point(414, 658)
    Me.btnEdit.Name = "btnEdit"
    Me.btnEdit.Size = New System.Drawing.Size(100, 30)
    Me.btnEdit.TabIndex = 12
    Me.btnEdit.Text = "編集"
    Me.btnEdit.UseVisualStyleBackColor = True
    '
    'btnSave
    '
    Me.btnSave.Location = New System.Drawing.Point(533, 110)
    Me.btnSave.Name = "btnSave"
    Me.btnSave.Size = New System.Drawing.Size(100, 30)
    Me.btnSave.TabIndex = 13
    Me.btnSave.Text = "保存"
    Me.btnSave.UseVisualStyleBackColor = True
    '
    'FrmLectureFeeCoefficient
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(648, 700)
    Me.Controls.Add(Me.btnSave)
    Me.Controls.Add(Me.btnEdit)
    Me.Controls.Add(Me.txtGrade)
    Me.Controls.Add(Me.btnAdd)
    Me.Controls.Add(Me.txtLectureCoefficient)
    Me.Controls.Add(Me.txtClassCode)
    Me.Controls.Add(Me.Label5)
    Me.Controls.Add(Me.Label4)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.GroupBox1)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.cmbSiteCode)
    Me.Controls.Add(Me.btnDelete)
    Me.Controls.Add(Me.dgvLectureFee)
    Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.Margin = New System.Windows.Forms.Padding(4)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "FrmLectureFeeCoefficient"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "授業給係数設定"
    CType(Me.dgvLectureFee, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GroupBox1.ResumeLayout(False)
    Me.GroupBox1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents Label3 As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents btnDelete As Button
	Friend WithEvents cmbHalfYear As ComboBox
	Friend WithEvents cmbYear As ComboBox
	Friend WithEvents dgvLectureFee As DataGridView
	Friend WithEvents Label1 As Label
	Friend WithEvents cmbSiteCode As ComboBox
	Friend WithEvents GroupBox1 As GroupBox
	Friend WithEvents Label4 As Label
	Friend WithEvents Label5 As Label
	Friend WithEvents txtClassCode As TextBox
	Friend WithEvents txtLectureCoefficient As TextBox
	Friend WithEvents btnAdd As Button
  Friend WithEvents txtGrade As TextBox
  Friend WithEvents btnEdit As Button
  Friend WithEvents btnSave As Button
End Class
