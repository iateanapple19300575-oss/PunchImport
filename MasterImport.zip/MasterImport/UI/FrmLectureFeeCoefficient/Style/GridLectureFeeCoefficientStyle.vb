﻿Public Class GridLectureFeeCoefficientStyle
  Implements IGridColumnDefinition

  ''' <summary>
  ''' 授業給係数設定の一覧に必要な列定義を作成し、指定された DataGridView に適用する。
  ''' </summary>
  ''' <param name="grid"></param>
  Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

    ' 一覧の項目定義
    Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("Site_Code", "教室", 100).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Grade", "学年", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Class_Code", "クラスコード", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Lecture_Coefficient", "係数", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Remarks", "備考", 300).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build()
        }

    ' 既存列をクリアし、自動生成を無効化
    grid.Columns.Clear()
    grid.AutoGenerateColumns = False

    ' 列定義を DataGridView に追加
    For Each def In defs
      grid.Columns.Add(GridColumnFactory.Create(def))
    Next

  End Sub
End Class
