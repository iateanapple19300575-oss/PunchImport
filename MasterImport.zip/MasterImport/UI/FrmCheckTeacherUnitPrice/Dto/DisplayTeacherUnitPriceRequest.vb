﻿''' <summary>
''' マスタデータ削除時の要求モデル。
''' </summary>
Public Class DisplayTeacherUnitPriceRequest
    Inherits BaseDisplayRequest


    ''' <summary>
    ''' 最新(現在有効のみ)
    ''' </summary>
    ''' <returns></returns>
    Public Property LatestOnly As Boolean = False

    ''' <summary>
    ''' 科目(国語、算数、社会、理科、・・・)
    ''' </summary>
    ''' <returns></returns>
    Public Property Subjects As New Dictionary(Of String, Boolean)

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherCode As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherName As String = ""

End Class