﻿
''' <summary>
''' DTO: M_Teacher_Wage_Dto
''' M_Teacher_Wage
''' </summary>
Public Class M_Teacher_Wage_Dto

    ''' <summary>
    ''' Id
    ''' </summary>
    Public Property Id As Integer?

    ''' <summary>
    ''' Teacher_Code
    ''' </summary>
    Public Property Teacher_Code As String = ""

    ''' <summary>
    ''' Effective_Date
    ''' </summary>
    Public Property Effective_Date As DateTime?

    ''' <summary>
    ''' Lecture_Unit_Price
    ''' </summary>
    Public Property Lecture_Unit_Price As Integer?

    ''' <summary>
    ''' Task_Unit_Price
    ''' </summary>
    Public Property Task_Unit_Price As Nullable(Of Integer)

    ''' <summary>
    ''' Create_Date
    ''' </summary>
    Public Property Create_Date As Nullable(Of DateTime)

    ''' <summary>
    ''' Create_User
    ''' </summary>
    Public Property Create_User As String = ""

    ''' <summary>
    ''' Update_Date
    ''' </summary>
    Public Property Update_Date As Nullable(Of DateTime)

    ''' <summary>
    ''' Update_User
    ''' </summary>
    Public Property Update_User As String = ""

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class
