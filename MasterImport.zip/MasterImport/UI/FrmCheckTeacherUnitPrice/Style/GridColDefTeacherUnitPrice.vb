﻿Public Class GridColDefTeacherUnitPrice
  Implements IGridColumnDefinition

  Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        Dim defs As New List(Of GridColumnDefinition) From {
      New GridColumnBuilder("Teacher_Code", "講師コード", 100).
        Align(DataGridViewContentAlignment.MiddleCenter).
        CellReadOnly().
        Build(),
      New GridColumnBuilder("Teacher_Name", "講師名", 120).
        Align(DataGridViewContentAlignment.MiddleLeft).
        CellReadOnly().
        Build(),
      New GridColumnBuilder("Effective_Date", "適正年月日", 100).
        Align(DataGridViewContentAlignment.MiddleCenter).
        CellReadOnly().
        Format("yyyy/MM/dd").
        Build(),
      New GridColumnBuilder("Lecture_Unit_Price", "授業給単価", 100).
        Align(DataGridViewContentAlignment.MiddleRight).
        CellReadOnly().
        Build(),
      New GridColumnBuilder("Task_Unit_Price", "業務給単価", 100).
        Align(DataGridViewContentAlignment.MiddleRight).
        CellReadOnly().
        Build(),
      New GridColumnBuilder("Id", "ID", 10).
        Align(DataGridViewContentAlignment.MiddleCenter).
        CellReadOnly().
        Hide().
        Build(),
      New GridColumnBuilder("RowVersion", "RowVersion", 10).
        Align(DataGridViewContentAlignment.MiddleCenter).
        CellReadOnly().
        Hide().
        Build()
    }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
    grid.AutoGenerateColumns = False

    ' 列定義を DataGridView に追加
    For Each def In defs
      grid.Columns.Add(GridColumnFactory.Create(def))
    Next

  End Sub
End Class
