﻿''' <summary>
''' 講師単価設定確認画面サービス
''' </summary>
Public Class TeacherUnitPriceService
    Inherits BaseService

    ' 科目識別
    Private Const SUBJECT_KOKU As String = "K"      ' 国語
    Private Const SUBJECT_SANS As String = "M"      ' 算数
    Private Const SUBJECT_SYAK As String = "S"      ' 社会
    Private Const SUBJECT_RIKA As String = "R"      ' 理科
    Private Const SUBJECT_GAKU As String = "G"      ' 学習

    ''' <summary>
    ''' 講師単価設定トラン
    ''' </summary>
    Private _repo As New TeacherWageRepository()


    ''' <summary>
    ''' ViewState を構築して返す（画面初期表示）。
    ''' </summary>
    Public Function LoadViewState(ByVal model As TeacherUnitPriceModel) As TeacherUnitPriceViewState
        Dim entity As TeacherUnitPriceEntity = ModelToEntity(model)
        Dim dto As TeacherUnitPriceDto = EntityToDto(entity)
        Dim dt = _repo.GetAll(dto)
        Dim items = TeacherUnitPriceMapper.ToViewStateList(dt)

        Return New TeacherUnitPriceViewState With {
            .Items = items
        }
    End Function

    ''' <summary>
    ''' 削除処理。
    ''' </summary>
    Public Sub Delete(ByVal req As TeacherUnitPriceModel)
        _repo.DeleteById(req.Id)
    End Sub


    Public Shared Function ModelToEntity(model As TeacherUnitPriceModel) As TeacherUnitPriceEntity
        If model Is Nothing Then
            Return Nothing
        End If

        Dim entity As New TeacherUnitPriceEntity
        entity.Mode = model.Mode
        entity.CondTeacherCode = model.CondTeacherCode
        entity.CondTeacherName = model.CondTeacherName
        entity.CondLatestOnly = model.CondLatestOnly
        entity.CondSubjectsDic.Add(SUBJECT_KOKU, model.CondSubjectK)
        entity.CondSubjectsDic.Add(SUBJECT_SANS, model.CondSubjectM)
        entity.CondSubjectsDic.Add(SUBJECT_SYAK, model.CondSubjectS)
        entity.CondSubjectsDic.Add(SUBJECT_RIKA, model.CondSubjectR)
        entity.CondSubjectsDic.Add(SUBJECT_GAKU, model.CondSubjectG)
        entity.dto.Id = model.Id
        entity.dto.Effective_Date = model.Effective_Date
        entity.dto.Lecture_Unit_Price = NumberUtil.StringNumberToDecimal(model.Lecture_Unit_Price)
        entity.dto.Task_Unit_Price = NumberUtil.StringNumberToDecimal(model.Task_Unit_Price)
        entity.dto.RowVersion = model.RowVersion

        Return entity
    End Function

    Public Shared Function EntityToDto(entity As TeacherUnitPriceEntity) As TeacherUnitPriceDto
        If entity Is Nothing Then
            Return Nothing
        End If

        Return New TeacherUnitPriceDto With {
            .Id = entity.Id,
            .TeacherCode = entity.CondTeacherCode,
            .TeacherName = entity.CondTeacherName,
            .LatestOnly = entity.CondLatestOnly,
            .Subjects = entity.CondSubjectsDic,
            .Dto = entity.dto
        }
    End Function




End Class
