﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmCheckTeacherUnitPrice
    Inherits BaseEditForm

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()>
	Private Sub InitializeComponent()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.dgvDataList = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkSubjectG = New System.Windows.Forms.CheckBox()
        Me.chkSubjectR = New System.Windows.Forms.CheckBox()
        Me.chkSubjectS = New System.Windows.Forms.CheckBox()
        Me.chkSubjectM = New System.Windows.Forms.CheckBox()
        Me.chkSubjectK = New System.Windows.Forms.CheckBox()
        Me.txtTeacherCode = New System.Windows.Forms.TextBox()
        Me.chkLatestOnly = New System.Windows.Forms.CheckBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtTeacherName = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        CType(Me.dgvDataList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 17)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "講師コード"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(459, 633)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(100, 30)
        Me.btnCancel.TabIndex = 12
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'dgvDataList
        '
        Me.dgvDataList.AllowUserToAddRows = False
        Me.dgvDataList.AllowUserToDeleteRows = False
        Me.dgvDataList.AllowUserToResizeColumns = False
        Me.dgvDataList.AllowUserToResizeRows = False
        Me.dgvDataList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDataList.Location = New System.Drawing.Point(20, 120)
        Me.dgvDataList.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvDataList.MultiSelect = False
        Me.dgvDataList.Name = "dgvDataList"
        Me.dgvDataList.ReadOnly = True
        Me.dgvDataList.RowHeadersWidth = 20
        Me.dgvDataList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvDataList.RowTemplate.Height = 21
        Me.dgvDataList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvDataList.Size = New System.Drawing.Size(540, 506)
        Me.dgvDataList.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(177, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "講師名"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkSubjectG)
        Me.GroupBox1.Controls.Add(Me.chkSubjectR)
        Me.GroupBox1.Controls.Add(Me.chkSubjectS)
        Me.GroupBox1.Controls.Add(Me.chkSubjectM)
        Me.GroupBox1.Controls.Add(Me.chkSubjectK)
        Me.GroupBox1.Location = New System.Drawing.Point(20, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(369, 56)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'chkSubjectG
        '
        Me.chkSubjectG.AutoSize = True
        Me.chkSubjectG.Checked = True
        Me.chkSubjectG.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSubjectG.Location = New System.Drawing.Point(300, 23)
        Me.chkSubjectG.Name = "chkSubjectG"
        Me.chkSubjectG.Size = New System.Drawing.Size(53, 21)
        Me.chkSubjectG.TabIndex = 4
        Me.chkSubjectG.Text = "学習"
        Me.chkSubjectG.UseVisualStyleBackColor = True
        '
        'chkSubjectR
        '
        Me.chkSubjectR.AutoSize = True
        Me.chkSubjectR.Checked = True
        Me.chkSubjectR.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSubjectR.Location = New System.Drawing.Point(230, 23)
        Me.chkSubjectR.Name = "chkSubjectR"
        Me.chkSubjectR.Size = New System.Drawing.Size(53, 21)
        Me.chkSubjectR.TabIndex = 3
        Me.chkSubjectR.Text = "理科"
        Me.chkSubjectR.UseVisualStyleBackColor = True
        '
        'chkSubjectS
        '
        Me.chkSubjectS.AutoSize = True
        Me.chkSubjectS.Checked = True
        Me.chkSubjectS.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSubjectS.Location = New System.Drawing.Point(160, 23)
        Me.chkSubjectS.Name = "chkSubjectS"
        Me.chkSubjectS.Size = New System.Drawing.Size(53, 21)
        Me.chkSubjectS.TabIndex = 2
        Me.chkSubjectS.Text = "社会"
        Me.chkSubjectS.UseVisualStyleBackColor = True
        '
        'chkSubjectM
        '
        Me.chkSubjectM.AutoSize = True
        Me.chkSubjectM.Checked = True
        Me.chkSubjectM.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSubjectM.Location = New System.Drawing.Point(90, 23)
        Me.chkSubjectM.Name = "chkSubjectM"
        Me.chkSubjectM.Size = New System.Drawing.Size(53, 21)
        Me.chkSubjectM.TabIndex = 1
        Me.chkSubjectM.Text = "算数"
        Me.chkSubjectM.UseVisualStyleBackColor = True
        '
        'chkSubjectK
        '
        Me.chkSubjectK.AutoSize = True
        Me.chkSubjectK.Checked = True
        Me.chkSubjectK.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSubjectK.Location = New System.Drawing.Point(20, 23)
        Me.chkSubjectK.Name = "chkSubjectK"
        Me.chkSubjectK.Size = New System.Drawing.Size(53, 21)
        Me.chkSubjectK.TabIndex = 0
        Me.chkSubjectK.Text = "国語"
        Me.chkSubjectK.UseVisualStyleBackColor = True
        '
        'txtTeacherCode
        '
        Me.txtTeacherCode.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtTeacherCode.Location = New System.Drawing.Point(100, 14)
        Me.txtTeacherCode.MaxLength = 4
        Me.txtTeacherCode.Name = "txtTeacherCode"
        Me.txtTeacherCode.Size = New System.Drawing.Size(45, 28)
        Me.txtTeacherCode.TabIndex = 1
        '
        'chkLatestOnly
        '
        Me.chkLatestOnly.AutoSize = True
        Me.chkLatestOnly.Location = New System.Drawing.Point(415, 19)
        Me.chkLatestOnly.Name = "chkLatestOnly"
        Me.chkLatestOnly.Size = New System.Drawing.Size(144, 21)
        Me.chkLatestOnly.TabIndex = 4
        Me.chkLatestOnly.Text = "最新データのみ表示"
        Me.chkLatestOnly.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(416, 56)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(144, 48)
        Me.btnSearch.TabIndex = 6
        Me.btnSearch.Tag = "NoLog"
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtTeacherName
        '
        Me.txtTeacherName.ImeMode = System.Windows.Forms.ImeMode.Hiragana
        Me.txtTeacherName.Location = New System.Drawing.Point(230, 14)
        Me.txtTeacherName.MaxLength = 4
        Me.txtTeacherName.Name = "txtTeacherName"
        Me.txtTeacherName.Size = New System.Drawing.Size(159, 28)
        Me.txtTeacherName.TabIndex = 3
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(338, 633)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(100, 30)
        Me.btnSave.TabIndex = 11
        Me.btnSave.Text = "保存"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(232, 633)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 30)
        Me.btnDelete.TabIndex = 10
        Me.btnDelete.Text = "削除"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(126, 633)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 30)
        Me.btnEdit.TabIndex = 9
        Me.btnEdit.Text = "編集"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(20, 633)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 30)
        Me.btnAdd.TabIndex = 8
        Me.btnAdd.Text = "追加"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'FrmCheckTeacherUnitPrice
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(580, 671)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtTeacherName)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.chkLatestOnly)
        Me.Controls.Add(Me.txtTeacherCode)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.dgvDataList)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmCheckTeacherUnitPrice"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "講師単価設定確認"
        CType(Me.dgvDataList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label3 As Label
	Friend WithEvents btnCancel As Button
	Friend WithEvents dgvDataList As DataGridView
	Friend WithEvents Label1 As Label
	Friend WithEvents GroupBox1 As GroupBox
	Friend WithEvents chkSubjectG As CheckBox
	Friend WithEvents chkSubjectR As CheckBox
	Friend WithEvents chkSubjectS As CheckBox
	Friend WithEvents chkSubjectM As CheckBox
	Friend WithEvents chkSubjectK As CheckBox
	Friend WithEvents txtTeacherCode As TextBox
	Friend WithEvents chkLatestOnly As CheckBox
	Friend WithEvents btnSearch As Button
	Friend WithEvents txtTeacherName As TextBox
    Friend WithEvents btnSave As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnEdit As Button
    Friend WithEvents btnAdd As Button
End Class
