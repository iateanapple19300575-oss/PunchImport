﻿Imports MasterImport.MainApp.Data.Dto
''' <summary>
''' 講師単価設定確認画面の入力欄モデル。
''' ・入力欄の値
''' ・UI ⇔ Model の変換
''' ・クリア処理
''' を担当する。
''' </summary>
Public Class TeacherUnitPriceEntity

    ''' <summary>
    ''' 追加／編集モード
    ''' </summary>
    Public Property Mode As EditMode

    ''' <summary>
    ''' ID
    ''' </summary>
    Public Property Id As Integer?

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property CondTeacherCode As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    Public Property CondTeacherName As String = ""

    ''' <summary>
    ''' 最新のみ
    ''' </summary>
    Public Property CondLatestOnly As Boolean = False

    ''' <summary>
    ''' 国語
    ''' </summary>
    Public Property CondSubjectK As Boolean = True

    ''' <summary>
    ''' 算数
    ''' </summary>
    Public Property CondSubjectM As Boolean = True

    ''' <summary>
    ''' 社会
    ''' </summary>
    Public Property CondSubjectS As Boolean = True

    ''' <summary>
    ''' 理科
    ''' </summary>
    Public Property CondSubjectR As Boolean = True

    ''' <summary>
    ''' 学習
    ''' </summary>
    Public Property CondSubjectG As Boolean = True

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property Teacher_Code As String = ""

    ''' <summary>
    ''' 最新のみ
    ''' </summary>
    Public Property LatestOnly As Boolean = False

    ''' <summary>
    ''' 科目(国語、算数、社会、理科、・・・)
    ''' </summary>
    ''' <returns></returns>
    Public Property CondSubjectsDic As New Dictionary(Of String, Boolean)

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Public Property dto As New M_Teacher_Wage_Dto

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class