﻿Imports MainApp.Data.Dto
Imports MasterImport.MainApp.Data.Dto

''' <summary>
''' 講師単価設定データ取込ViewController
''' </summary>
Public Class ImportLectureFeeDataViewController
    Implements ICsvImportView

    ''' <summary>講師単価設定データ取込画面Form</summary>
    Private ReadOnly _form As FrmImportLectureFeeData

    ''' <summary>講師単価設定データ取込画面Service</summary>
    Private ReadOnly _service As ImportLectureFeeDataService


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="frm">出講料設定データ取込画面インスタンス</param>
    Public Sub New(ByVal frm As Form)
        _form = frm
        _service = New ImportLectureFeeDataService()
    End Sub

    ''' <summary>
    ''' 初期表示データ取得要求
    ''' </summary>
    ''' <returns></returns>
    Public Function GetInitDisplayData() As ImportTimetableOutputDto
        Dim model As New ImportTimetableOutputDto
        model = _service.GetInitDisplayData()
        '_form.DisplayLastResults(model)
        Return model
    End Function

    ''' <summary>
    ''' [取込]ボタン押下要求
    ''' </summary>
    ''' <param name="param"></param>
    Public Function Import(param As CsvImportParameterDto) As ImportTimetableOutputDto
        Dim model As New ImportTimetableOutputDto
        model = _service.CsvImport(param)
        '_form.DisplayExecutionResults(model)
        Return model
    End Function

    ''' <summary>
    ''' 取込結果応答
    ''' </summary>
    ''' <param name="model"></param>
    Public Sub DisplayExecutionResults(ByVal model As ImportTimetableOutputDto)
        'Dim dto As New ImportResultsDto
        'dto.Execution_Date = resultDto.ExecutionDate
        'dto.Data_Count = IIf(resultDto.HasError, resultDto.ErrorCount, resultDto.ExecutionCount)
        'model.StatusStr = IIf(resultDto.HasError, "状態：異常終了", "状態：正常終了")
        'dto.Execution_Status = IIf(resultDto.HasError, False, True)
        'Return CsvImportResultOutputDto.Success(result.DataCount, result.ProcessDateTime)
    End Sub

End Class
