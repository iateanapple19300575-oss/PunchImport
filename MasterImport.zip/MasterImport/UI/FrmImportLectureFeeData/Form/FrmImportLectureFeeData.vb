﻿Imports Freamwork.Common.Helper
Imports ImportType
Imports MainApp.Data.Dto
Imports MasterImport.MainApp.Data.Dto
Imports UserControl

''' <summary>
''' 時間割設定データ取込画面
''' </summary>
Public Class FrmImportLectureFeeData
    Inherits BaseForm

#Region "フィールド"

    ''' <summary>出講料設定データ取込画面 ViewController</summary>
    Private _viewController As ImportLectureFeeDataViewController

#End Region

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("出講料設定データ取込")
        InitializeComponent()
    End Sub

#Region "初期表示"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmLectureFeeImport_Load(sender As Object, e As EventArgs) Handles Me.Load
        _viewController = New ImportLectureFeeDataViewController(Me)

        ' 画面初期表示処理
        InitDisplay()
    End Sub

    ''' <summary>
    ''' 画面初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        Dim model As New ImportTimetableOutputDto

        ' 初期表示データ取得
        model = _viewController.GetInitDisplayData()

        ' 初期データ設定
        DisplayLastResults(model)
    End Sub

    ''' <summary>
    ''' 画面初期表示
    ''' </summary>
    ''' <param name="model"></param>
    Public Sub DisplayLastResults(ByVal model As ImportTimetableOutputDto)
        ''Dim lastDate As String = DisplayFormatDate(dto.Execution_Date, True)
        'Dim lastDate As String = DateUtil.EmptyDateToDefaultLong(model.LectureUnitPriceInfo.ExecDate)
        'Dim lastCount As String = NumberUtil.DigitComma(model.LectureUnitPriceInfo.Count)
        'Dim lastStatus As String = model.LectureUnitPriceInfo.StatusStr
        'ctlTeacherUnitPrice.SetLastImportResult(lastDate, lastCount, lastStatus)
        'ctlTeacherUnitPrice.ImportButton.Enabled = False
        ' [講師単価設定]
        ' 前回の取込状態表示(前回日時、前回件数)
        Dim info As ProcessResultInfoDto = model.LectureUnitPriceInfo
        ctlTeacherUnitPrice.SetLastImportResult(
                DateUtil.EmptyDateToDefaultLong(info.ExecDate),
                NumberUtil.DigitComma(info.Count),
                info.StatusStr
            )
    End Sub

#End Region

#Region "[取込]ボタン押下イベント"

    ''' <summary>
    ''' 講師単価設定[取込]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlTeacherUnitPrice_ImportButtonClick(ByVal sender As Object, e As EventArgs) Handles ctlTeacherUnitPrice.ImportButtonClick
        Dim param As New CsvImportParameterDto With {
          .FilePath = ctlTeacherUnitPrice.FilePath,
          .CsvType = ImportCsvType.TeacherUnitPrice
        }

        ' 取込実行
        Dim model As ImportTimetableOutputDto
        model = _viewController.Import(param)

        ' 実行結果表示
        DisplayExecutionResults(model)
    End Sub

    ''' <summary>
    ''' CSV取込結果表示
    ''' </summary>
    ''' <param name="model"></param>
    Public Sub DisplayExecutionResults(ByVal model As ImportTimetableOutputDto)
        ''Dim lastDate As String = DisplayFormatDate(dto.Execution_Date, True)
        'Dim lastDate As String = DateUtil.EmptyDateToDefaultLong(model.LectureUnitPriceInfo.ExecDate)
        'Dim lastCount As String = model.LectureUnitPriceInfo.Count
        'Dim lastStatus As String = model.LectureUnitPriceInfo.StatusStr
        'ctlTeacherUnitPrice.SetCurrentImportResult(lastDate, lastCount, lastStatus)
        'ctlTeacherUnitPrice.ImportButton.Enabled = False

        ' 前回の取込状態表示(前回日時、前回件数)
        Dim info As ProcessResultInfoDto = model.LectureUnitPriceInfo
        ctlTeacherUnitPrice.SetCurrentImportResult(
                DateUtil.EmptyDateToDefaultLong(info.ExecDate),
                NumberUtil.DigitComma(info.Count),
                info.StatusStr
            )

        If model.LectureUnitPriceInfo.Status = 0 Then
            MessageBox.Show(Me, "データの取込が完了しました。")
        End If
    End Sub

#End Region

#Region "[データ確認]ボタン押下イベント"

    ''' <summary>
    ''' 講師単価設定[データ確認]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlTeacherUnitPrice_ViewButtonClick(sender As Object, e As EventArgs) Handles ctlTeacherUnitPrice.ViewButtonClick
        Dim frm As Form = New FrmCheckTeacherUnitPrice()
        frm.ShowDialog()
    End Sub

    ''' <summary>
    ''' [業務給基本設定]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnBusinessSalaryBasic_Click(sender As Object, e As EventArgs) Handles btnBusinessSalaryBasic.Click
        Dim frm As Form = New FrmBasicWorkSalary
        frm.ShowDialog()
    End Sub

    ''' <summary>
    ''' [授業給係数設定(本科・日特・特選)]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnTuitionFeeCoefficient_Click(sender As Object, e As EventArgs) Handles btnLectureFeeCoefficientSpecial.Click
        Dim frm As Form = New FrmLectureFeeCoefficient
        frm.ShowDialog()
    End Sub

    ''' <summary>
    ''' [授業給係数設定(期間講習)]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnLectureFeeCoefficientPeriod_Click(sender As Object, e As EventArgs) Handles btnLectureFeeCoefficientPeriod.Click
        Dim frm As Form = New FrmLectureFeeCoefficient
        frm.ShowDialog()
    End Sub

#End Region


#Region "インポート処理結果表示処理部品"

    ''' <summary>
    ''' 処理終了メッセージ表示
    ''' </summary>
    Private Sub ExitMessage(ByVal isSuccess As Boolean, ByVal statusLabel As Label)
        MouseCursor.DefaultCursor(Me)
        If (isSuccess) Then
            MessageBox.Show(Me, MessageIdConst.MSGID_I2002, Me.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    ''' <summary>
    ''' エラー件数を表示する。
    ''' </summary>
    ''' <param name="count"></param>
    ''' <returns></returns>
    Private Function DisplayFormatErrorCount(ByVal count As Integer) As String
        Return String.Format("結果：データエラー（{0}件）", NumberUtil.DigitComma(count))
    End Function


#End Region

End Class