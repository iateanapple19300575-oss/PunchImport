﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmImportLectureFeeData
	'Inherits System.Windows.Forms.Form
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.btnLectureFeeCoefficientSpecial = New System.Windows.Forms.Button()
    Me.btnBusinessSalaryBasic = New System.Windows.Forms.Button()
    Me.lblFinalClassTimeTableDate = New System.Windows.Forms.Label()
    Me.lblBusinessSalaryBasic = New System.Windows.Forms.Label()
    Me.lblFinalRoomTimeTableDate = New System.Windows.Forms.Label()
    Me.lblTuitionFeeCoefficient = New System.Windows.Forms.Label()
    Me.btnLectureFeeCoefficientPeriod = New System.Windows.Forms.Button()
    Me.ctlTeacherUnitPrice = New UserControl.ImportCheckControl()
    Me.SuspendLayout()
    '
    'btnLectureFeeCoefficientSpecial
    '
    Me.btnLectureFeeCoefficientSpecial.Location = New System.Drawing.Point(324, 208)
    Me.btnLectureFeeCoefficientSpecial.Name = "btnLectureFeeCoefficientSpecial"
    Me.btnLectureFeeCoefficientSpecial.Size = New System.Drawing.Size(220, 100)
    Me.btnLectureFeeCoefficientSpecial.TabIndex = 21
    Me.btnLectureFeeCoefficientSpecial.Text = "授業給係数設定" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "（本科・日特・特選）"
    Me.btnLectureFeeCoefficientSpecial.UseVisualStyleBackColor = True
    '
    'btnBusinessSalaryBasic
    '
    Me.btnBusinessSalaryBasic.Location = New System.Drawing.Point(45, 208)
    Me.btnBusinessSalaryBasic.Name = "btnBusinessSalaryBasic"
    Me.btnBusinessSalaryBasic.Size = New System.Drawing.Size(220, 100)
    Me.btnBusinessSalaryBasic.TabIndex = 14
    Me.btnBusinessSalaryBasic.Text = "業務給基本設定"
    Me.btnBusinessSalaryBasic.UseVisualStyleBackColor = True
    '
    'lblFinalClassTimeTableDate
    '
    Me.lblFinalClassTimeTableDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.lblFinalClassTimeTableDate.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.lblFinalClassTimeTableDate.ForeColor = System.Drawing.Color.Black
    Me.lblFinalClassTimeTableDate.Location = New System.Drawing.Point(298, 188)
    Me.lblFinalClassTimeTableDate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.lblFinalClassTimeTableDate.Name = "lblFinalClassTimeTableDate"
    Me.lblFinalClassTimeTableDate.Size = New System.Drawing.Size(512, 200)
    Me.lblFinalClassTimeTableDate.TabIndex = 19
    '
    'lblBusinessSalaryBasic
    '
    Me.lblBusinessSalaryBasic.AutoSize = True
    Me.lblBusinessSalaryBasic.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.lblBusinessSalaryBasic.ForeColor = System.Drawing.Color.Black
    Me.lblBusinessSalaryBasic.Location = New System.Drawing.Point(65, 323)
    Me.lblBusinessSalaryBasic.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.lblBusinessSalaryBasic.Name = "lblBusinessSalaryBasic"
    Me.lblBusinessSalaryBasic.Size = New System.Drawing.Size(190, 51)
    Me.lblBusinessSalaryBasic.TabIndex = 20
    Me.lblBusinessSalaryBasic.Text = "業務給基本設定" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "　・デフォルトの業務給単価" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "　・みなし勤務として扱う時間"
    '
    'lblFinalRoomTimeTableDate
    '
    Me.lblFinalRoomTimeTableDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.lblFinalRoomTimeTableDate.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.lblFinalRoomTimeTableDate.ForeColor = System.Drawing.Color.Black
    Me.lblFinalRoomTimeTableDate.Location = New System.Drawing.Point(20, 188)
    Me.lblFinalRoomTimeTableDate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.lblFinalRoomTimeTableDate.Name = "lblFinalRoomTimeTableDate"
    Me.lblFinalRoomTimeTableDate.Size = New System.Drawing.Size(270, 200)
    Me.lblFinalRoomTimeTableDate.TabIndex = 12
    '
    'lblTuitionFeeCoefficient
    '
    Me.lblTuitionFeeCoefficient.AutoSize = True
    Me.lblTuitionFeeCoefficient.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.lblTuitionFeeCoefficient.ForeColor = System.Drawing.Color.Black
    Me.lblTuitionFeeCoefficient.Location = New System.Drawing.Point(350, 323)
    Me.lblTuitionFeeCoefficient.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.lblTuitionFeeCoefficient.Name = "lblTuitionFeeCoefficient"
    Me.lblTuitionFeeCoefficient.Size = New System.Drawing.Size(242, 34)
    Me.lblTuitionFeeCoefficient.TabIndex = 22
    Me.lblTuitionFeeCoefficient.Text = "授業給係数設定" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "　係数で授業給を支払う対象を設定する" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
    '
    'btnLectureFeeCoefficientPeriod
    '
    Me.btnLectureFeeCoefficientPeriod.Location = New System.Drawing.Point(564, 208)
    Me.btnLectureFeeCoefficientPeriod.Name = "btnLectureFeeCoefficientPeriod"
    Me.btnLectureFeeCoefficientPeriod.Size = New System.Drawing.Size(220, 100)
    Me.btnLectureFeeCoefficientPeriod.TabIndex = 23
    Me.btnLectureFeeCoefficientPeriod.Text = "授業給係数設定" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "（期間講習）"
    Me.btnLectureFeeCoefficientPeriod.UseVisualStyleBackColor = True
    '
    'ctlTeacherUnitPrice
    '
    Me.ctlTeacherUnitPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.ctlTeacherUnitPrice.CurrentCount = "--,---件"
    Me.ctlTeacherUnitPrice.CurrentResult = "状態"
    Me.ctlTeacherUnitPrice.CurrentTime = "----/--/-- --:--"
    Me.ctlTeacherUnitPrice.DataTypeLabel = "講師単価設定"
    Me.ctlTeacherUnitPrice.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.ctlTeacherUnitPrice.LastImportCount = "--,---件"
    Me.ctlTeacherUnitPrice.LastImportTime = "----/--/-- --:--"
    Me.ctlTeacherUnitPrice.LastResult = "状態"
    Me.ctlTeacherUnitPrice.Location = New System.Drawing.Point(20, 20)
    Me.ctlTeacherUnitPrice.Margin = New System.Windows.Forms.Padding(4)
    Me.ctlTeacherUnitPrice.Name = "ctlTeacherUnitPrice"
    Me.ctlTeacherUnitPrice.Size = New System.Drawing.Size(790, 140)
    Me.ctlTeacherUnitPrice.TabIndex = 24
    '
    'FrmImportLectureFeeData
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(830, 409)
    Me.Controls.Add(Me.ctlTeacherUnitPrice)
    Me.Controls.Add(Me.btnLectureFeeCoefficientPeriod)
    Me.Controls.Add(Me.lblTuitionFeeCoefficient)
    Me.Controls.Add(Me.btnLectureFeeCoefficientSpecial)
    Me.Controls.Add(Me.btnBusinessSalaryBasic)
    Me.Controls.Add(Me.lblFinalClassTimeTableDate)
    Me.Controls.Add(Me.lblBusinessSalaryBasic)
    Me.Controls.Add(Me.lblFinalRoomTimeTableDate)
    Me.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.KeyPreview = True
    Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "FrmImportLectureFeeData"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "出講料設定データ取込"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents lblFinalClassTimeTableDate As Label
	Friend WithEvents lblBusinessSalaryBasic As Label
	Friend WithEvents lblFinalRoomTimeTableDate As Label
  Friend WithEvents btnBusinessSalaryBasic As Button
  Friend WithEvents btnLectureFeeCoefficientSpecial As Button
  Friend WithEvents lblTuitionFeeCoefficient As Label
  Friend WithEvents btnLectureFeeCoefficientPeriod As Button
  Friend WithEvents ctlTeacherUnitPrice As UserControl.ImportCheckControl
End Class
