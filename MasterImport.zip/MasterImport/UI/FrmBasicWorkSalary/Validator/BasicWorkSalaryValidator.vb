﻿Public Class BasicWorkSalaryValidator
    Implements IValidator(Of HourlyWageDto)

    '' <summary>
    '' 保存要求のバリデーションを行う。
    '' </summary>
    Public Function Validate(dto As HourlyWageDto) As List(Of String) Implements IValidator(Of HourlyWageDto).Validate
        Dim errors As New List(Of String)

        ' --- 必須チェック ---
        If String.IsNullOrEmpty(dto.Effective_Date) Then
            errors.Add("適用開始日は必須です。")
        End If

        If String.IsNullOrEmpty(dto.Task_Base_Unit_Price) Then
            errors.Add("標準単価は必須です。")
        End If

        'If String.IsNullOrEmpty(dto.Deemed_Time_Before) Then
        '    errors.Add("みなし勤務時間（授業前）は必須です。")
        'End If

        'If String.IsNullOrEmpty(dto.Deemed_Time_After) Then
        '    errors.Add("みなし勤務時間（授業後）は必須です。")
        'End If

        ' 必須エラーがある場合はここで終了
        If errors.Count > 0 Then
            Return errors
        End If

        '' --- 形式チェック（TryParse） ---
        'Dim chkDate As Date
        Dim chkNumeric As Integer

        If Not Date.TryParse(dto.Effective_Date, dto.Effective_Date) Then
            errors.Add("適用開始日の形式が不正です。（例：YYYY/MM/DD）")
        End If

        If Not Integer.TryParse(dto.Task_Base_Unit_Price, chkNumeric) Then
            errors.Add("標準単価の入力形式が不正です。（例：2000）")
        End If

        If Not Integer.TryParse(dto.Task_Base_Unit_Price, chkNumeric) Then
            errors.Add("みなし勤務時間（授業前）の入力形式が不正です。（例：20）")
        End If

        If Not Integer.TryParse(dto.Task_Base_Unit_Price, chkNumeric) Then
            errors.Add("みなし勤務時間（授業後）の入力形式が不正です。（例：20）")
        End If

        ' 形式エラーがある場合はここで終了
        If errors.Count > 0 Then
            Return errors
        End If

        '' --- 範囲チェック ---

        '' --- 整合性チェック ---

        Return errors
    End Function
End Class
