﻿Imports MasterImport.MainApp.Data.Model

''' <summary>
''' 業務給基本設定 Service
''' </summary>
Public Class BasicWorkSalaryService
    Inherits BaseService

    ''' <summary>
    ''' 業務給基本設定データ Repository
    ''' </summary>
    Private ReadOnly _repo As New HourlyWageRepository

    Private ReadOnly _validator As New BasicWorkSalaryValidator()

    ''' <summary>
    ''' ViewState を構築して返す（画面初期表示）。
    ''' </summary>
    Public Function LoadViewState() As BasicWorkSalaryViewState
        Dim dt = _repo.GetAll()
        Dim items = BasicWorkSalaryMapper.ToViewStateList(dt)

        Return New BasicWorkSalaryViewState With {
            .Items = items
        }
    End Function

    ''' <summary>
    ''' 削除処理。
    ''' </summary>
    Public Sub Delete(model As BasicWorkSalaryModel)
        Dim entity As BasicWorkSalaryEntity = ModelToEntity(model)
        Dim dto As HourlyWageDto = EntityToDto(entity)
        _repo.DeleteById(dto)
    End Sub

    ''' <summary>
    ''' 保存処理（追加／更新）。
    ''' </summary>
    ''' <param name="model"></param>
    Public Sub Save(model As BasicWorkSalaryModel)
        Dim entity As BasicWorkSalaryEntity = ModelToEntity(model)
        Dim dto As HourlyWageDto = EntityToDto(entity)
        'Return ExecuteWithValidation(
        '    Function() _validator.Validate(dto),
        '    Sub()
        '        Select Case entity.Mode
        '            Case EditMode.Add
        '                dto.Create_User = Environment.UserDomainName
        '                _repo.Insert(dto)
        '            Case EditMode.Edit
        '                dto.Update_User = Environment.UserDomainName
        '                _repo.Update(dto)
        '        End Select
        '    End Sub
        ')

        Select Case entity.Mode
            Case EditMode.Add
                dto.Create_User = Environment.UserDomainName
                _repo.Insert(dto)
            Case EditMode.Edit
                dto.Update_User = Environment.UserDomainName
                _repo.Update(dto)
        End Select

    End Sub

    Public Shared Function ModelToEntity(model As BasicWorkSalaryModel) As BasicWorkSalaryEntity
        If model Is Nothing Then
            Return Nothing
        End If

        Return New BasicWorkSalaryEntity With {
            .Mode = model.Mode,
            .Id = model.Id,
            .Effective_Date_Str = model.Effective_Date_Str,
            .Task_Base_Unit_Price_Str = model.Task_Base_Unit_Price_Str,
            .Deemed_Time_Before_Str = model.Deemed_Time_Before_Str,
            .Deemed_Time_After_Str = model.Deemed_Time_After_Str,
            .Deemed_Time_Before = TimeUtil.TimeStringToTimeSpan(model.Deemed_Time_Before_Str),
            .Deemed_Time_After = TimeUtil.TimeStringToTimeSpan(model.Deemed_Time_After_Str),
            .Create_Date = model.Create_Date,
            .Create_User = model.Create_User,
            .Update_Date = model.Update_Date,
            .Update_User = model.Update_User,
            .RowVersion = model.RowVersion
        }
    End Function

    Public Shared Function EntityToDto(entity As BasicWorkSalaryEntity) As HourlyWageDto
        If entity Is Nothing Then
            Return Nothing
        End If

        Return New HourlyWageDto With {
            .Id = entity.Id,
            .Effective_Date = DateUtil.DateStringToTryDate(entity.Effective_Date_Str),
            .Task_Base_Unit_Price = NumberUtil.StringNumberToDecimal(entity.Task_Base_Unit_Price_Str),
            .Deemed_Time_Before = TimeUtil.TimeStringToTimeSpan(entity.Deemed_Time_Before_Str),
            .Deemed_Time_After = TimeUtil.TimeStringToTimeSpan(entity.Deemed_Time_After_Str),
            .Create_Date = entity.Create_Date,
            .Create_User = entity.Create_User,
            .Update_Date = entity.Update_Date,
            .Update_User = entity.Update_User,
            .RowVersion = entity.RowVersion
        }
    End Function

End Class