﻿Imports MasterImport.MainApp.Data.Model

Public Class BasicWorkSalaryViewController

    '' <summary>
    '' 保存要求のバリデーションを行う。
    '' </summary>
    Public Function Validate(ByVal model As BasicWorkSalaryModel) As List(Of String)
        Dim errors As New List(Of String)

        ' --- 必須チェック ---
        If String.IsNullOrEmpty(model.Effective_Date_Str) Then
            errors.Add("適用開始日は必須です。")
        End If

        If String.IsNullOrEmpty(model.Task_Base_Unit_Price_Str) Then
            errors.Add("標準単価は必須です。")
        End If

        If String.IsNullOrEmpty(model.Deemed_Time_Before_Str) Then
            errors.Add("みなし勤務時間（授業前）は必須です。")
        End If

        If String.IsNullOrEmpty(model.Deemed_Time_After_Str) Then
            errors.Add("みなし勤務時間（授業後）は必須です。")
        End If

        ' 必須エラーがある場合はここで終了
        If errors.Count > 0 Then
            Return errors
        End If

        ' --- 形式チェック（TryParse） ---
        Dim chkDate As Date
        Dim chkNumeric As Integer

        If Not Date.TryParse(model.Effective_Date_Str, chkDate) Then
            errors.Add("適用開始日の形式が不正です。（例：YYYY/MM/DD）")
        End If

        If Not Integer.TryParse(model.Task_Base_Unit_Price_Str, chkNumeric) Then
            errors.Add("標準単価の入力形式が不正です。（例：2000）")
        End If

        If Not Integer.TryParse(model.Deemed_Time_Before_Str, chkNumeric) Then
            errors.Add("みなし勤務時間（授業前）の入力形式が不正です。（例：20）")
        End If

        If Not Integer.TryParse(model.Deemed_Time_After_Str, chkNumeric) Then
            errors.Add("みなし勤務時間（授業後）の入力形式が不正です。（例：20）")
        End If

        ' 形式エラーがある場合はここで終了
        If errors.Count > 0 Then
            Return errors
        End If

        '' --- 範囲チェック ---

        '' --- 整合性チェック ---

        Return errors
    End Function
End Class
