Namespace MainApp.Data.Dto

    ''' <summary>
    ''' DTO�B
    ''' </summary>
    Public Class BasicWorkSalaryDto

        ''' <summary>
        ''' ID
        ''' </summary>
        Public Property Id As Integer?

        ''' <summary>
        ''' �K�p�J�n��
        ''' </summary>
        Public Property Effective_Date As Date?

        ''' <summary>
        ''' �Ɩ����W���P��
        ''' </summary>
        Public Property Task_Base_Unit_Price As Integer?

        ''' <summary>
        ''' �݂Ȃ��Ζ�����(���O��)
        ''' </summary>
        Public Property Deemed_Time_Before As Integer?

        ''' <summary>
        ''' �݂Ȃ��Ζ�����(���㕪)
        ''' </summary>
        Public Property Deemed_Time_After As Integer?

        ''' <summary>
        ''' �쐬��
        ''' </summary>
        Public Property Create_Date As DateTime?

        ''' <summary>
        ''' �쐬��
        ''' </summary>
        Public Property Create_User As String = ""

        ''' <summary>
        ''' �X�V��
        ''' </summary>
        Public Property Update_Date As DateTime?

        ''' <summary>
        ''' �X�V��
        ''' </summary>
        Public Property Update_User As String = ""

        ''' <summary>
        ''' RowVersion
        ''' </summary>
        Public Property RowVersion As Byte?()

    End Class

End Namespace
