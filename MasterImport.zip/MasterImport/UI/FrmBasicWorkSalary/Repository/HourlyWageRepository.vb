﻿Imports System.Data.SqlClient

Public Class HourlyWageRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


#Region "一括取得"

    ''' <summary>
    ''' 条件指定一括取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetAll() As DataTable
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Id").Append(" ")
        sqlString.Append("  , Effective_Date").Append(" ")
        sqlString.Append("  , Task_Base_Unit_Price").Append(" ")
        sqlString.Append("  , DATEDIFF(MINUTE, 0, Deemed_Time_Before) AS Deemed_Time_Before").Append(" ")
        sqlString.Append("  , DATEDIFF(MINUTE, 0, Deemed_Time_After) AS Deemed_Time_After").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append("  , RowVersion").Append(" ")
        sqlString.Append("FROM M_Hourly_Wage").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Effective_Date").Append(" ")

        Return ExecuteDataTable(sqlString.ToString(), Nothing)
    End Function

#End Region


    ''' <summary>
    ''' 1件追加
    ''' </summary>
    ''' <param name="dto">追加情報</param>
    ''' <returns></returns>
    Public Function Insert(ByVal dto As HourlyWageDto) As Integer
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO").Append(" ")
        sqlString.Append("  M_Hourly_Wage").Append(" ")
        sqlString.Append("  (").Append(" ")
        sqlString.Append("    Effective_Date").Append(" ")
        sqlString.Append("    , Task_Base_Unit_Price").Append(" ")
        sqlString.Append("    , Deemed_Time_Before").Append(" ")
        sqlString.Append("    , Deemed_Time_After").Append(" ")
        sqlString.Append("    , Create_Date").Append(" ")
        sqlString.Append("    , Create_User").Append(" ")
        sqlString.Append("    , Update_Date").Append(" ")
        sqlString.Append("    , Update_User").Append(" ")
        sqlString.Append("  ) VALUES (").Append(" ")
        sqlString.Append("    @Effective_Date").Append(" ")
        sqlString.Append("    , @Task_Base_Unit_Price").Append(" ")
        sqlString.Append("    , @Deemed_Time_Before").Append(" ")
        sqlString.Append("    , @Deemed_Time_After").Append(" ")
        sqlString.Append("    , GETDATE()").Append(" ")
        sqlString.Append("    , @Create_User").Append(" ")
        sqlString.Append("    , NULL").Append(" ")
        sqlString.Append("    , NULL").Append(" ")
        sqlString.Append("  )").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Effective_Date", .Value = dto.Effective_Date})
        params.Add(New SqlParameter() With {.ParameterName = "@Task_Base_Unit_Price", .Value = dto.Task_Base_Unit_Price})
        params.Add(New SqlParameter() With {.ParameterName = "@Deemed_Time_Before", .Value = dto.Deemed_Time_Before})
        params.Add(New SqlParameter() With {.ParameterName = "@Deemed_Time_After", .Value = dto.Deemed_Time_After})
        'params.Add(New SqlParameter() With {.ParameterName = "@Create_Date", .Value = dto.Create_Date})
        params.Add(New SqlParameter() With {.ParameterName = "@Create_User", .Value = dto.Create_User})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 1件更新
    ''' </summary>
    ''' <param name="dto">更新情報</param>
    ''' <returns></returns>
    Public Function Update(ByVal dto As HourlyWageDto) As Integer
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("UPDATE").Append(" ")
        sqlString.Append("  M_Hourly_Wage").Append(" ")
        sqlString.Append("  SET").Append(" ")
        sqlString.Append("    Effective_Date = @Effective_Date").Append(" ")
        sqlString.Append("    , Task_Base_Unit_Price = @Task_Base_Unit_Price").Append(" ")
        sqlString.Append("    , Deemed_Time_Before = @Deemed_Time_Before").Append(" ")
        sqlString.Append("    , Deemed_Time_After = @Deemed_Time_After").Append(" ")
        sqlString.Append("    , Update_Date = GETDATE()").Append(" ")
        sqlString.Append("    , Update_User = @Update_User").Append(" ")
        sqlString.Append("  WHERE").Append(" ")
        sqlString.Append("    1=1").Append(" ")
        sqlString.Append("    AND Id = @Id").Append(" ")
        sqlString.Append("    AND RowVersion = @RowVersion").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        params.Add(New SqlParameter() With {.ParameterName = "@Effective_Date", .Value = dto.Effective_Date})
        params.Add(New SqlParameter() With {.ParameterName = "@Task_Base_Unit_Price", .Value = dto.Task_Base_Unit_Price})
        params.Add(New SqlParameter() With {.ParameterName = "@Deemed_Time_Before", .Value = dto.Deemed_Time_Before})
        params.Add(New SqlParameter() With {.ParameterName = "@Deemed_Time_After", .Value = dto.Deemed_Time_After})
        'params.Add(New SqlParameter() With {.ParameterName = "@Update_Date", .Value = dto.Update_Date})
        params.Add(New SqlParameter() With {.ParameterName = "@Update_User", .Value = dto.Update_User})
        params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.Rowversion})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 条件指定一括取得
    ''' </summary>
    ''' <param name="dto">条件情報</param>
    ''' <returns></returns>
    Public Function DeleteById(ByVal dto As HourlyWageDto) As Integer
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    M_Hourly_Wage").Append(" ")
        sqlString.Append("  WHERE").Append(" ")
        sqlString.Append("        1=1").Append(" ")
        sqlString.Append("    AND Id = @Id").Append(" ")
        sqlString.Append("    AND RowVersion = @RowVersion").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.RowVersion})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

End Class