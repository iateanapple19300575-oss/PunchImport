﻿Imports Framework

Public Class LectureFreeCoefficientRepository

  Private Shared ReadOnly Def As New TableDefinition(
      "Master1",
      New List(Of String) From {"School", "Koma", "WeekPattern", "StartTime", "EndTime"},
      New List(Of String) From {"School", "Koma", "WeekPattern"}
  )

  'Public Function GetAll() As List(Of LectureFreeCoefficientEntity)
  '  Dim sql As String = QueryBuilder.BuildSelect(Def)
  '  Return SqlExecutor.Query(sql, AddressOf LectureFreeCoefficientPeriodMapper.Map)
  'End Function

  Public Sub Insert(e As LectureFreeCoefficientEntity)
    Dim sql As String = QueryBuilder.BuildInsert(Def)
    SqlCommandExecutor.Execute(sql, e)
  End Sub

  Public Sub Update(e As LectureFreeCoefficientEntity)
    Dim sql As String = QueryBuilder.BuildUpdate(Def)
    SqlCommandExecutor.Execute(sql, e)
  End Sub

  Public Sub Delete(e As LectureFreeCoefficientEntity)
    Dim sql As String = QueryBuilder.BuildDelete(Def)
    SqlCommandExecutor.Execute(sql, e)
  End Sub

End Class