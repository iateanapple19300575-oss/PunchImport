﻿Public Class ConfirmDisplayData

	''' <summary>
	''' インポート情報
	''' </summary>
	''' <returns></returns>
	Public Property ImportInfo As New ImportInfoData

	''' <summary>
	''' インポートデータ(DataTable)
	''' </summary>
	''' <returns></returns>
	Public Property TeacherDataTable As DataTable

	''' <summary>
	''' インポートデータ(DataTable)
	''' </summary>
	''' <returns></returns>
	Public Property ImportDataTable As DataTable

End Class
