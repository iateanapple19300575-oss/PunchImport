﻿Public Class CsvErrorFactory

  ''' <summary>
  ''' データタイプ
  ''' </summary>
  ''' <returns></returns>
  Private Property DataType As Integer

  ''' <summary>
  ''' CSVファイル名
  ''' </summary>
  ''' <returns></returns>
  Private Property CsvDataDic As List(Of Dictionary(Of String, String))

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New()
    Me.DataType = DataType
    Me.CsvDataDic = CsvDataDic
  End Sub

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="dataType">データタイプ</param>
  ''' <param name="csvErrorDic">CSVデータ</param>
  Public Sub New(ByVal dataType As Integer, ByVal csvErrorDic As Dictionary(Of Integer, List(Of ValidationResult)))
    Me.DataType = dataType
    Me.CsvDataDic = CsvDataDic
  End Sub

  '''' <summary>
  '''' インポートクラスのインスタンス作成
  '''' </summary>
  '''' <returns>CSVインポートクラスインスタンス</returns>
  'Public Function CreateCsvError(ByVal dataType As Integer, ByVal csvErrorDic As Dictionary(Of Integer, List(Of ValidationResult))) As FrmValidationErrors
  '  'Select Case dataType
  '  '	Case TableImportHistoryConst.TYPE_TIME_PATTERN
  '  '		Return New TimePatternCsvError(csvErrorDic, New TimePatternCsv)
  '  '	Case TableImportHistoryConst.TYPE_TIME_TABLE
  '  '		Return New TimeTableCsvError(csvErrorDic, New TimeTableCsv)
  '  '	Case Else
  '  '		Return Nothing
  '  'End Select
  'End Function

End Class
