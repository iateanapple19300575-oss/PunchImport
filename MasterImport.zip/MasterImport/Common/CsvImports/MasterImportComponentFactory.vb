﻿Imports ImportType
Imports MainApp.Data.Dto

Public Class MasterImportComponentFactory

    Public Shared Function Create(type As ImportCsvType, param As CsvImportParameterDto) As CsvImportMasterComponents
        Select Case type

            Case ImportCsvType.TimePattern
                Return New CsvImportMasterComponents(
                            New TimePatternCsv(param.FilePath),
                            New TimePatternCsvValidation(New TimePatternCsv(param.FilePath))
                            )
            Case ImportCsvType.TimeTableSite
                Return New CsvImportMasterComponents(
                            New TimeTableSiteCsv(param.FilePath),
                            New TimeTableSiteCsvValidation(New TimeTableSiteCsv(param.FilePath))
                            )
            Case ImportCsvType.TimeTableClass
                Return New CsvImportMasterComponents(
                            New TimeTableClassCsv(param.FilePath),
                            New TimeTableClassCsvValidation(New TimeTableClassCsv(param.FilePath))
                            )
            Case ImportCsvType.TeacherUnitPrice
                Return New CsvImportMasterComponents(
                            New TeacherWageCsv(param.FilePath),
                            New TeacherWageCsvValidation(New TeacherWageCsv(param.FilePath))
                            )
            Case Else
                Throw New NotSupportedException("未対応の CSV 種類です: " & type)
        End Select
    End Function

End Class