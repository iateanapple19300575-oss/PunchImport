﻿Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class LnstructorUnitPriceCsvImporter
    Inherits CsvImporterBase

    Private ReadOnly Property _parameter As CsvImportParameterDto

    Private ReadOnly _components As CsvImportMasterComponents

    Public Sub New(parameter As CsvImportParameterDto, components As CsvImportMasterComponents)
        MyBase.New(parameter, components.Csv, components.Validator)
        _parameter = parameter
    End Sub

    Protected Overrides ReadOnly Property TargetTableName As String
        Get
            Return MasterImportTable.TEACHER_WAGE_WORK
        End Get
    End Property

    Protected Overrides ReadOnly Property ImportTypeName As String
        Get
            Return MasterImportTypes.Lecturer
        End Get
    End Property

    Protected Overrides ReadOnly Property DataType As String
        Get
            Return TableImportHistoryConst.TYPE_TEACHER_WAGE
        End Get
    End Property

    Protected Overrides Function GetDtoType() As Type
        Return Nothing
    End Function

    Protected Overrides Sub DeleteSwapData(ByVal sqlDbConn As DbTransactionScope, targetDates As List(Of String))
        Dim repo As New TeacherWageWorkRepository(sqlDbConn)
        repo.DeleteSwapData()
        Return
    End Sub

    ''' <summary>
    ''' 講師単価設定データのマージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Function AppendJob(ByVal sqlDbConn As DbTransactionScope) As Integer
        Dim repo As New TeacherWageRepository(sqlDbConn)
        repo.MergeTeacherWage(sqlDbConn)
        DeleteSwapData(sqlDbConn, Nothing)
        Return 0
    End Function

    Protected Overrides Sub PreparatoryWork(sqlDbConn As DbTransactionScope, impDataDic As List(Of Dictionary(Of String, String)), delMonths As List(Of String))
        DeleteSwapData(sqlDbConn, Nothing)
    End Sub

    Protected Overrides Function ValidationMonthPeriod(ByRef delKeys As List(Of String), impDataList As List(Of Dictionary(Of String, String))) As ImportDataErrorType
        Return ImportDataErrorType.Success
    End Function

    ''' <summary>
    ''' 重複データがあるか否かを判定します。
    ''' </summary>
    ''' <param name="impDataDic"></param>
    ''' <returns></returns>
    Protected Overrides Function DuplicateValidation(ByVal impDataDic As List(Of Dictionary(Of String, String))) As Boolean
        ' 重複チェック
        Dim duplicates = impDataDic.
            GroupBy(Function(d) String.Join("|", {
                d("講師コード"),
                d("適用年月日")
            })).
            Where(Function(g) g.Count() > 1).
            ToList()
        Return duplicates.Any()
    End Function

End Class