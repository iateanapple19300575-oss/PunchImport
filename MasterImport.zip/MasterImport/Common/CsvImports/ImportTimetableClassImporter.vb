﻿Imports System.Globalization
Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class ImportTimetableClassImporter
    Inherits CsvImporterBase

    Private ReadOnly Property _parameter As CsvImportParameterDto

    Private ReadOnly _components As CsvImportMasterComponents


    Private _delKeys As New List(Of DeleteTargetData)


    Public Sub New(parameter As CsvImportParameterDto, components As CsvImportMasterComponents)
        MyBase.New(parameter, components.Csv, components.Validator)
        _parameter = parameter
    End Sub

    Protected Overrides ReadOnly Property TargetTableName As String
        Get
            Return MasterImportTable.TIMETABLE_CLASS
        End Get
    End Property

    Protected Overrides ReadOnly Property ImportTypeName As String
        Get
            Return MasterImportTypes.TimeTableClass
        End Get
    End Property

    Protected Overrides ReadOnly Property DataType As String
        Get
            Return TableImportHistoryConst.TYPE_TIME_TABLE_CLASS
        End Get
    End Property

    Protected Overrides Function GetDtoType() As Type
        Return Nothing
    End Function

    Protected Overrides Sub DeleteSwapData(ByVal sqlDbConn As DbTransactionScope, delKeys As List(Of String))
        Dim repo As New TimetableClassRepository(sqlDbConn)
        For Each key As DeleteTargetData In _delKeys.ToArray
            repo.DeleteSwapData(key)
        Next
        Return
    End Sub

    Protected Overrides Function ValidationMonthPeriod(ByRef delKeys As List(Of String), impDataList As List(Of Dictionary(Of String, String))) As ImportDataErrorType
        Return ValidationDataPeriod(_delKeys, impDataList)
    End Function

    Private Function ValidationDataPeriod(ByRef delKeys As List(Of DeleteTargetData), impDataList As List(Of Dictionary(Of String, String))) As ImportDataErrorType
        ' 事前削除対象の年月日を取得する
        'Dim storedDates As List(Of String) = GetYearMonthList(impDataList)
        Dim storedKeys As List(Of DeleteTargetData) = GetCategoryAndPeriod(impDataList)

        If storedKeys.Count <= 0 Then
            Return ImportDataErrorType.DataNotFound
        End If

        ' 現在選択中の対象年月を元に現在の年度の開始年月、終了年月を取得する。
        Dim dtStartDate As Date
        Dim dtEndDate As Date
        DateUtil.NendoToMonthPeriod(dtStartDate, dtEndDate, _parameter.TargetDate)

        Dim strStartY As String = String.Format("{0:0000}", dtStartDate.Year)
        Dim strEndY As String = String.Format("{0:0000}", dtEndDate.Year)
        Dim strStartYM As String = String.Format("{0}{1:00}", dtStartDate.Year, dtStartDate.Month)
        Dim strEndYM As String = String.Format("{0}{1:00}", dtEndDate.Year, dtEndDate.Month)
        Dim strYM As String = ""
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0

        ' 年度の範囲外のデータが存在するならばエラーとして処理しない。
        For Each row As DeleteTargetData In storedKeys.ToArray
            Select Case row.Setting_Category
                Case "1"
                    If row.Target_Period >= strStartY AndAlso row.Target_Period <= strEndY Then
                        delKeys.Add(row)
                        trueCnt += 1
                    Else
                        falseCnt += 1
                    End If
                Case "2", "3"
                    strYM = row.Target_Period.Substring(0, 6)
                    If strYM >= strStartYM AndAlso strYM <= strEndYM Then
                        delKeys.Add(row)
                        trueCnt += 1
                    Else
                        falseCnt += 1
                    End If
            End Select
        Next

        If trueCnt > 0 AndAlso falseCnt = 0 Then
            Return ImportDataErrorType.Success
        ElseIf trueCnt > 0 AndAlso falseCnt > 0 Then
            Return ImportDataErrorType.IncludingNonEligible
        ElseIf trueCnt = 0 AndAlso falseCnt > 0 Then
            Return ImportDataErrorType.OnlyNonEligible
        End If

        Return ImportDataErrorType.OtherError
    End Function

    Protected Overrides Sub PreparatoryWork(sqlDbConn As DbTransactionScope, impDataDic As List(Of Dictionary(Of String, String)), delMonths As List(Of String))
        DeleteSwapData(sqlDbConn, Nothing)
    End Sub

    ''' <summary>
    ''' 事前削除対象の年月日を収集します。
    ''' CSVファイル内の年月日項目のサマリを取得して事前削除対象の年月日とします。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Private Function GetYearMonthList(list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYearMonths =
                  list.
                  Where(Function(d) d.ContainsKey("Target_Period") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("Target_Period"))).
                  Select(Function(d)
                             Dim strYmd As String
                             strYmd = d("Target_Period")
                             Return strYmd.Substring(0, 4) ' 年だけに変換
                         End Function).
                  Where(Function(s) s IsNot Nothing).
                  Distinct().
                  OrderBy(Function(s) s).
                  ToList()
        Return distinctYearMonths
    End Function

    Private Function GetCategoryAndPeriod(list As List(Of Dictionary(Of String, String))) As List(Of DeleteTargetData)
        Dim delKeys As New List(Of DeleteTargetData)
        For Each dic As Dictionary(Of String, String) In list
            Dim item As New DeleteTargetData
            item.Setting_Category = dic("Setting_Category")
            item.Site_Code = dic("Site_Code")
            item.Target_Period = dic("Target_Period")
            item.Grade = dic("Grade")
            item.Class_Code = dic("Class_Code")
            delKeys.Add(item)
        Next

        Return delKeys
    End Function

    ''' <summary>
    ''' 重複データがあるか否かを判定します。
    ''' </summary>
    ''' <param name="impDataDic"></param>
    ''' <returns></returns>
    Protected Overrides Function DuplicateValidation(ByVal impDataDic As List(Of Dictionary(Of String, String))) As Boolean
        ' 重複チェック
        Dim duplicates = impDataDic.
            GroupBy(Function(d) String.Join("|", {
                d("Setting_Category"),
                d("Target_Period"),
                d("Site_Code"),
                d("Grade"),
                d("Class_Code"),
                d("Koma_Seq")
            })).
            Where(Function(g) g.Count() > 1).
            ToList()
        Return duplicates.Any()
    End Function
End Class


