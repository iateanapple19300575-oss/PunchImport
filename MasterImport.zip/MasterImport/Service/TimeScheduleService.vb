﻿Public Class TimeScheduleService

    Private tran As New TimeScheduleTran

    Public Sub New()

    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="p_dataGridView"></param>
    Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
    End Sub

    Public Function LoadTimePatternData(ByVal targetYearMonth As Date) As ResultData
        Dim result As New ResultData
        Try
            result = tran.LoadTimePatternData(targetYearMonth)
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadYearData() As ResultData
        Dim result As New ResultData
        Try
            'result = tran.LoadYearData()
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadMonthData() As ResultData
        Dim result As New ResultData
        Try
            'result = tran.LoadMonthData()
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

End Class
