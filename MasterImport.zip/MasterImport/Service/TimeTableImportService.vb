﻿'Imports ClassLibrary

'''' <summary>
'''' 教室時間割サービス
'''' </summary>
'Public Class TimeTableImportService

'    ''' <summary>
'    ''' 取込履歴トラン
'    ''' </summary>
'    Private masterHistory As New ImportHistoryTran()


'    ''' <summary>
'    ''' コンストラクタ
'    ''' </summary>
'    Public Sub New()

'    End Sub

'    ''' <summary>
'    ''' 教室時間割CSVデータのインポートを行う。
'    ''' </summary>
'    ''' <param name="csvFile">CSVファイル名</param>
'    ''' <returns></returns>
'    Public Function Import(ByVal csvFile As String) As ImportResultData
'        Dim resultData As New ImportResultData

'        ' CSVデータ検証
'        Dim validation = New TimeTableCsvValidation(csvFile)
'        resultData.ValidationResult = validation.ValidationCheck()
'        resultData.Success = resultData.ValidationResult.Success

'        ' CSVデータインポート
'        If (resultData.Success) Then
'            Dim bulkCopy = New CsvImportBulkCopy(New TimeTableDataImport("", ""))
'            resultData.ImportResult = bulkCopy.Import(csvFile)
'            resultData.Success = resultData.ImportResult.Success
'            resultData.Exclusive = resultData.ImportResult.Exclusive
'            resultData.ProcessDateTime = resultData.ImportResult.ProcessDateTime
'        End If

'        Return resultData
'    End Function

'    ''' <summary>
'    ''' 履歴情報取得
'    ''' </summary>
'    ''' <param name="type">データ種別</param>
'    ''' <returns>履歴情報</returns>
'    Public Function GetImportHistorys(ByVal type As Integer) As DataTable
'        Return masterHistory.GetImportHistorys(type).ResDataTable
'    End Function
'End Class
