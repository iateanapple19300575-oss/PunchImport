﻿''' <summary>
''' 画面表示時の要求モデル基底クラス。
''' </summary>
Public Class BaseDisplayRequest

End Class