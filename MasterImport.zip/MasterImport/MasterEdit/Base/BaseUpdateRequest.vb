﻿''' <summary>
''' 1件データ更新時の要求モデル基底クラス。
''' </summary>
Public Class BaseUpdateRequest

    ''' <summary>更新対象の ID</summary>
    Public Property Id As Integer

    ''' <summary>更新対象の RowVersion</summary>
    Public Property RowVersion As Byte()

End Class