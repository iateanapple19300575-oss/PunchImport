﻿Imports System.Data.SqlClient

Public Class TeacherRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Public Function GetAll() As DataTable
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT" & " ")
        sqlString.Append("  TR.[講師コード]" & " As Teacher_Code" & " ")
        sqlString.Append("  , TR.[講師名] As Teacher_Name" & " ")
        sqlString.Append("FROM ")
        sqlString.Append("  [TeacherRegistry] TR " & " ")
        sqlString.Append("ORDER BY" & " ")
        sqlString.Append("  TR.[講師コード] ASC" & " ")
        sqlString.Append("; ")

        Return ExecuteDataTable(sqlString.ToString(), Nothing)
    End Function

    Private Function DataTableMapping(ByVal reader As SqlDataReader) As DataTable
        Dim dtTable As New DataTable
        DataTableDefinition(dtTable)

        While reader.Read()
            Dim rowRec As DataRow = dtTable.NewRow()
            Dim code As String = SqlDataReaderUtil.GetValue(reader, "Teacher_Code")
            rowRec("Teacher_Code") = code
            rowRec("Teacher_Name") = code & ":" & SqlDataReaderUtil.GetValue(reader, "Teacher_Name")
            dtTable.Rows.Add(rowRec)
        End While

        Return dtTable
    End Function

    ''' <summary>
    ''' 教室データ格納用 DataTable定義
    ''' </summary>
    Private Sub DataTableDefinition(ByRef dtTable As DataTable)
        dtTable.Columns.Add("Teacher_Code", GetType(String))
        dtTable.Columns.Add("Teacher_Name", GetType(String))
    End Sub

End Class
