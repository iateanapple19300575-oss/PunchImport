﻿Imports System.Data.SqlClient

Public Class SiteTimeTran
  Inherits TransactionBase


    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    '   ''' <summary>
    '   ''' 地区情報取得
    '   ''' </summary>
    '   ''' <returns></returns>
    '   Public Function LoadDistrictData() As ResultData
    '	Dim resultData As New ResultData
    '	Dim recData As New Dictionary(Of String, String)

    '	Dim sqlString As New System.Text.StringBuilder
    '	sqlString.Length = 0
    '	sqlString.Append("SELECT" & " ")
    '	sqlString.Append("  ID As District_Id" & " ")
    '	sqlString.Append("  , 地区名 As District_Name" & " ")
    '	sqlString.Append("FROM ")
    '	sqlString.Append("    " & DBTableConst.TABLE_NAME_SITE_GROUP_LIST & " ")
    '	sqlString.Append("ORDER BY" & " ")
    '	sqlString.Append("  ID ASC" & " ")
    '	sqlString.Append("; ")

    '	Using sqlConnection As New SqlConnection(ConnectString)
    '		Try
    '			sqlConnection.Open()
    '			Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
    '				Using reader As SqlDataReader = commandSourceData.ExecuteReader()
    '					resultData.ResDataTable = DistrictMapping(reader)
    '				End Using
    '				resultData.Success = True
    '				resultData.DataCount = resultData.ResDataTable.Rows.Count
    '			End Using

    '		Catch ex As Exception
    '			System.Console.WriteLine(ex.Message)
    '			Throw

    '		Finally
    '			If sqlConnection.State = ConnectionState.Open Then
    '				sqlConnection.Close()
    '			End If
    '		End Try
    '	End Using

    '	Return resultData
    'End Function

    '   ''' <summary>
    '   ''' 教室情報取得
    '   ''' </summary>
    '   ''' <returns></returns>
    '   Public Function LoadClassRoomData() As ResultData
    '	Dim resultData As New ResultData
    '	Dim recData As New Dictionary(Of String, String)

    '	Dim sqlString As New System.Text.StringBuilder
    '	sqlString.Length = 0
    '	sqlString.Append("SELECT" & " ")
    '	sqlString.Append("  SGL.[ID] As District_Id" & " ")
    '	sqlString.Append("  , SGL.[地区名] As District_Name" & " ")
    '	sqlString.Append("  , S.[教室コード] As Site_Code" & " ")
    '	sqlString.Append("  , CONCAT(S.[教室コード], ':', REPLACE(S.[教室名],'　','')) As Site_Name" & " ")
    '	sqlString.Append("FROM " & " ")
    '	sqlString.Append("    " & DBTableConst.TABLE_NAME_SITE_GROUP_LIST & " SGL " & " ")
    '	sqlString.Append("    LEFT JOIN (" & " ")
    '	sqlString.Append("      SELECT" & " ")
    '	sqlString.Append("        [教室コード]" & " ")
    '	sqlString.Append("        , [教室名]" & " ")
    '	sqlString.Append("        , [教室区分]" & " ")
    '	sqlString.Append("        , [本校教室コード]" & " ")
    '	sqlString.Append("      FROM" & " ")
    '	sqlString.Append("        " & DBTableConst.TABLE_NAME_SITE & ") S " & " ")
    '	sqlString.Append("        ON (" & " ")
    '	sqlString.Append("          SGL.ID = S.教室区分" & " ")
    '	sqlString.Append("        )" & " ")
    '	sqlString.Append("ORDER BY " & " ")
    '	sqlString.Append("  SGL.[ID] ASC" & " ")
    '	sqlString.Append("; ")

    '	Using sqlConnection As New SqlConnection(ConnectString)
    '		Try
    '			sqlConnection.Open()
    '			Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
    '				Dim count As Integer = 0
    '				Using reader As SqlDataReader = commandSourceData.ExecuteReader()
    '					resultData.ResDataTable = ClassRoomMapping(reader)
    '				End Using
    '				resultData.Success = True
    '				resultData.DataCount = resultData.ResDataTable.Rows.Count
    '			End Using

    '		Catch ex As Exception
    '			System.Console.WriteLine(ex.Message)
    '			Throw

    '		Finally
    '			If sqlConnection.State = ConnectionState.Open Then
    '				sqlConnection.Close()
    '			End If
    '		End Try
    '	End Using

    '	Return resultData
    'End Function

    '   ''' <summary>
    '   ''' 教室時間割取得
    '   ''' </summary>
    '   ''' <returns></returns>
    '   Public Function LoadTimeTableData() As ResultData
    '	Dim resultData As New ResultData
    '	Dim recData As New Dictionary(Of String, String)

    '	Dim sqlString As New System.Text.StringBuilder
    '	sqlString.Length = 0
    '	sqlString.Append("SELECT" & " ")
    '	sqlString.Append("  SGL.[ID] As District_Id" & " ")
    '	sqlString.Append("  , SGL.[地区名] As District_Name" & " ")
    '	sqlString.Append("  , S.[教室コード] As Site_Code" & " ")
    '	sqlString.Append("  , S.[教室名] As Site_Name" & " ")
    '	sqlString.Append("  , TT.[Schedule_Pattern] As Schedule_Pattern" & " ")
    '	'sqlString.Append("  , TT.[koma_seq] As コマ" & " ")
    '	'sqlString.Append("  , TT.[start_time] As 開始時間" & " ")
    '	'sqlString.Append("  , TT.[end_time] As 終了時間" & " ")

    '	For i As Integer = 1 To 9
    '		sqlString.Append("  , CONVERT(CHAR (5), TT.[Koma" & i & "_st_tm]) As [Koma" & i & "_st_tm]" & " ")
    '		sqlString.Append("  , CONVERT(CHAR (5), TT.[Koma" & i & "_ed_tm]) As [Koma" & i & "_ed_tm]" & " ")
    '	Next

    '	sqlString.Append("FROM " & " ")
    '	sqlString.Append("    " & DBTableConst.TABLE_NAME_SITE_GROUP_LIST & " SGL " & " ")
    '	sqlString.Append("    LEFT JOIN (" & " ")
    '	sqlString.Append("      SELECT" & " ")
    '	sqlString.Append("        [教室コード]" & " ")
    '	sqlString.Append("        , [教室名]" & " ")
    '	sqlString.Append("        , [教室区分]" & " ")
    '	sqlString.Append("        , [本校教室コード]" & " ")
    '	sqlString.Append("      FROM" & " ")
    '	sqlString.Append("        " & DBTableConst.TABLE_NAME_SITE & ") S " & " ")
    '	sqlString.Append("        ON (" & " ")
    '	sqlString.Append("          SGL.ID = S.教室区分" & " ")
    '	sqlString.Append("        )" & " ")
    '	sqlString.Append("    LEFT JOIN (" & " ")
    '	sqlString.Append("      SELECT" & " ")
    '	sqlString.Append("        TT1.Site_Code" & " ")
    '	sqlString.Append("        , TT1.Schedule_Pattern" & " ")

    '	For i As Integer = 1 To 9
    '		sqlString.Append("        , MAX(TT1.Start_Time" & i & ") As Koma" & i & "_st_tm" & " ")
    '		sqlString.Append("        , MAX(TT1.End_Time" & i & ") As Koma" & i & "_ed_tm" & " ")
    '	Next

    '	sqlString.Append("      FROM (" & " ")
    '	sqlString.Append("        SELECT" & " ")
    '	sqlString.Append("          [Site_Code]" & " ")
    '	sqlString.Append("          , [Schedule_Pattern]" & " ")

    '	For i As Integer = 1 To 9
    '		sqlString.Append("          , Case When Koma_Seq = " & i & " Then Start_Time Else NULL End As [Start_Time" & i & "]" & " ")
    '		sqlString.Append("          , Case When Koma_Seq = " & i & " Then End_Time Else NULL End As [End_Time" & i & "]" & " ")
    '	Next
    '	sqlString.Append("        FROM" & " ")
    '	sqlString.Append("          " & DBTableConst.TABLE_NAME_TIMETABLE_SITE & "" & " ")
    '	sqlString.Append("      ) TT1" & " ")
    '	sqlString.Append("      GROUP BY" & " ")
    '	sqlString.Append("        Site_Code" & " ")
    '	sqlString.Append("        , Schedule_Pattern" & " ")
    '	sqlString.Append("    ) TT" & " ")
    '	sqlString.Append("        ON (" & " ")
    '	sqlString.Append("          S.[教室コード]=TT.[Site_Code]" & " ")
    '	sqlString.Append("        )" & " ")
    '	sqlString.Append("ORDER BY " & " ")
    '	sqlString.Append("  SGL.[ID] ASC" & " ")
    '	sqlString.Append("  , S.[教室コード] ASC" & " ")
    '	sqlString.Append("  , TT.[Schedule_Pattern] ASC" & " ")
    '	'sqlString.Append("  , TT.[koma_seq] ASC" & " ")
    '	sqlString.Append("; ")

    '	Using sqlConnection As New SqlConnection(ConnectString)
    '		Try
    '			sqlConnection.Open()
    '			Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
    '				Dim count As Integer = 0
    '				Using reader As SqlDataReader = commandSourceData.ExecuteReader()
    '					resultData.ResDataTable = TimeTableMapping(reader)
    '				End Using
    '				resultData.Success = True
    '				resultData.DataCount = resultData.ResDataTable.Rows.Count
    '			End Using

    '		Catch ex As Exception
    '			System.Console.WriteLine(ex.Message)
    '			Throw

    '		Finally
    '			If sqlConnection.State = ConnectionState.Open Then
    '				sqlConnection.Close()
    '			End If
    '		End Try
    '	End Using

    '	Return resultData
    'End Function

    ''' <summary>
    ''' 地区データ格納用 DataTable定義
    ''' </summary>
    Private Sub DistrictDefinition(ByRef dtTable As DataTable)
		dtTable.Columns.Add("District_Id", GetType(String))
		dtTable.Columns.Add("District_Name", GetType(String))
	End Sub

	''' <summary>
	''' 教室データ格納用 DataTable定義
	''' </summary>
	Private Sub ClassRoomDefinition(ByRef dtTable As DataTable)
		dtTable.Columns.Add("District_Id", GetType(String))
		dtTable.Columns.Add("District_Name", GetType(String))
		dtTable.Columns.Add("Site_Code", GetType(String))
		dtTable.Columns.Add("Site_Name", GetType(String))
	End Sub

	''' <summary>
	''' 教室データ格納用 DataTable定義
	''' </summary>
	Private Sub TimeTableDefinition(ByRef dtTable As DataTable)
		dtTable.Columns.Add("District_Id", GetType(String))
		dtTable.Columns.Add("District_Name", GetType(String))
		dtTable.Columns.Add("Site_Code", GetType(String))
		dtTable.Columns.Add("Site_Name", GetType(String))
		dtTable.Columns.Add("Schedule_Pattern", GetType(String))
		For i As Integer = 1 To 9
			dtTable.Columns.Add("開始" & i.ToString(), GetType(String))
			dtTable.Columns.Add("終了" & i.ToString(), GetType(String))
		Next
	End Sub

	Private Function DistrictMapping(ByVal reader As SqlDataReader) As DataTable
		Dim dtTable As New DataTable
		DistrictDefinition(dtTable)

		While reader.Read()
			Dim rowRec As DataRow = dtTable.NewRow()
			rowRec("District_Id") = SqlDataReaderUtil.GetValue(reader, "District_Id")
			rowRec("District_Name") = SqlDataReaderUtil.GetValue(reader, "District_Name")
			dtTable.Rows.Add(rowRec)
		End While

		Return dtTable
	End Function

	Private Function ClassRoomMapping(ByVal reader As SqlDataReader) As DataTable
		Dim dtTable As New DataTable
		ClassRoomDefinition(dtTable)

		While reader.Read()
			Dim rowRec As DataRow = dtTable.NewRow()
			rowRec("District_Id") = SqlDataReaderUtil.GetValue(reader, "District_Id")
			rowRec("District_Name") = SqlDataReaderUtil.GetValue(reader, "District_Name")
			rowRec("Site_Code") = SqlDataReaderUtil.GetValue(reader, "Site_Code")
			rowRec("Site_Name") = SqlDataReaderUtil.GetValue(reader, "Site_Name")
			dtTable.Rows.Add(rowRec)
		End While

		Return dtTable
	End Function

	Private Function TimeTableMapping(ByVal reader As SqlDataReader) As DataTable
		Dim dtTable As New DataTable
		TimeTableDefinition(dtTable)

		While reader.Read()
			Dim rowRec As DataRow = dtTable.NewRow()
			rowRec("District_Id") = SqlDataReaderUtil.GetValue(reader, "District_Id")
			rowRec("District_Name") = SqlDataReaderUtil.GetValue(reader, "District_Name")
			rowRec("Site_Code") = SqlDataReaderUtil.GetValue(reader, "Site_Code")
			rowRec("Site_Name") = SqlDataReaderUtil.GetValue(reader, "Site_Name").ToString().Replace("　", "")
			rowRec("Schedule_Pattern") = SqlDataReaderUtil.GetValue(reader, "Schedule_Pattern")
			For i As Integer = 1 To 9
				rowRec("開始" & i.ToString()) = SqlDataReaderUtil.GetValue(reader, "Koma" & i.ToString() & "_st_tm")
				rowRec("終了" & i.ToString()) = SqlDataReaderUtil.GetValue(reader, "Koma" & i.ToString() & "_ed_tm")
			Next
			dtTable.Rows.Add(rowRec)
		End While

		Return dtTable
	End Function
End Class
