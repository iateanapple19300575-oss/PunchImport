﻿Public Class LectureFreeCoefficientEntity
  Public Property Year As String
  Public Property Half_Year As Integer
  Public Property Site_Code As String
  Public Property Grade As Integer
  Public Property Class_Code As String
  Public Property Lecture_Coefficient As String
  Public Property Remarks As Double
End Class
