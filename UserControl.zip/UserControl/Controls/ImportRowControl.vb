﻿''' <summary>
''' インポート用(拡張)ユーザコントロール
''' </summary>
Public Class ImportRowControl

    Public Event FileSelected(ByVal sender As Object, ByVal e As EventArgs)
    Public Event ImportButtonClick(ByVal sender As Object, ByVal e As EventArgs)
    Public Event ViewButtonClick(ByVal sender As Object, ByVal e As EventArgs)

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        InitializeComponent()

        txtFilePath.ReadOnly = True
        btnImport.Enabled = False
        cmbCategory.Visible = False
        lblCategoryTitle.Visible = False
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal visible As Boolean)
        InitializeComponent()

        txtFilePath.ReadOnly = True
        btnImport.Enabled = False
        cmbCategory.Visible = visible
        lblCategoryTitle.Visible = visible
    End Sub


#Region "プロパティ"

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Property DataTypeLabel As String
        Get
            Return lblDataType.Text
        End Get
        Set(ByVal value As String)
            lblDataType.Text = value
        End Set
    End Property

    ''' <summary>
    ''' ファイルパス
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property FilePath As String
        Get
            Return txtFilePath.Text
        End Get
    End Property

    ''' <summary>
    ''' 前回日時
    ''' </summary>
    ''' <returns></returns>
    Public Property LastImportTime As String
        Get
            Return lblLastTime.Text
        End Get
        Set(ByVal value As String)
            lblLastTime.Text = value
        End Set
    End Property

    ''' <summary>
    ''' 前回取込件数
    ''' </summary>
    ''' <returns></returns>
    Public Property LastImportCount As String
        Get
            Return lblLastCount.Text
        End Get
        Set(ByVal value As String)
            lblLastCount.Text = value
        End Set
    End Property

    ''' <summary>
    ''' 前回処理結果
    ''' </summary>
    ''' <returns></returns>
    Public Property LastResult As String
        Get
            Return lblLastResult.Text
        End Get
        Set(ByVal value As String)
            lblLastResult.Text = value
        End Set
    End Property

    ''' <summary>
    ''' 今回日時
    ''' </summary>
    ''' <returns></returns>
    Public Property CurrentTime As String
        Get
            Return lblCurrentTime.Text
        End Get
        Set(ByVal value As String)
            lblCurrentTime.Text = value
        End Set
    End Property

    ''' <summary>
    ''' 今回取込件数
    ''' </summary>
    ''' <returns></returns>
    Public Property CurrentCount As String
        Get
            Return lblCurrentCount.Text
        End Get
        Set(ByVal value As String)
            lblCurrentCount.Text = value
        End Set
    End Property

    ''' <summary>
    ''' 今回処理結果
    ''' </summary>
    ''' <returns></returns>
    Public Property CurrentResult As String
        Get
            Return lblCurrentResult.Text
        End Get
        Set(ByVal value As String)
            lblCurrentResult.Text = value
        End Set
    End Property

    ''' <summary>
    ''' [取込]ボタン
    ''' </summary>
    ''' <returns></returns>
    Public Property ImportButton As Button
        Get
            Return btnImport
        End Get
        Set(ByVal value As Button)
            btnImport = value
        End Set
    End Property

    ''' <summary>
    ''' カテゴリコンボ表示/非表示設定
    ''' </summary>
    ''' <returns></returns>
    <System.ComponentModel.Browsable(True)>
    <System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)>
    Public Property Category As ComboBox
        Get
            Return cmbCategory
        End Get
        Set(ByVal value As ComboBox)
            cmbCategory = value
            lblCategoryTitle.Visible = cmbCategory.Visible
        End Set
    End Property

#End Region

#Region "イベント処理"

    ''' <summary>
    ''' [参照]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BtnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        Dim dlg As New OpenFileDialog()
        dlg.Filter = "CSV(カンマ区切り)(*.csv)|*.csv"
        If dlg.ShowDialog() = DialogResult.OK Then
            txtFilePath.Text = dlg.FileName
            DisplayControl()
            RaiseEvent FileSelected(Me, e)
        End If
    End Sub

    ''' <summary>
    ''' [取込]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BtnImport_Click(sender As Object, e As EventArgs) Handles btnImport.Click
        If txtFilePath.Text <> "" Then
            RaiseEvent ImportButtonClick(Me, e)
        End If
    End Sub

#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' 前回の処理結果一括表示
    ''' </summary>
    ''' <param name="time"></param>
    ''' <param name="count"></param>
    ''' <param name="result"></param>
    Public Sub SetLastImportResult(ByVal time As String, ByVal count As String, ByVal result As String)
        lblLastTime.Text = time
        lblLastCount.Text = count
        lblLastResult.Text = result
    End Sub

    ''' <summary>
    ''' 今回の処理結果一括表示
    ''' </summary>
    ''' <param name="time"></param>
    ''' <param name="count"></param>
    ''' <param name="result"></param>
    Public Sub SetCurrentImportResult(ByVal time As String, ByVal count As String, ByVal result As String)
        lblCurrentTime.Text = time
        lblCurrentCount.Text = count
        lblCurrentResult.Text = result
    End Sub

    ''' <summary>
    ''' 講習区分データロード
    ''' </summary>
    ''' <param name="dt"></param>
    Public Sub SetLectureCategory(ByVal dt As DataTable)
        cmbCategory.DataSource = dt
        cmbCategory.DisplayMember = "Name"
        cmbCategory.ValueMember = "ID"
    End Sub

    ''' <summary>
    ''' 初期表示
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ImportRowControl_Load(sender As Object, e As EventArgs) Handles Me.Load
        If cmbCategory.Visible Then
            'cmbCategory.DataSource = AppCommon.GetLectureCategory()
        End If
    End Sub

    ''' <summary>
    ''' コンボボックスの選択変更。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub cmbCategory_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbCategory.SelectionChangeCommitted
        DisplayControl()
    End Sub

    ''' <summary>
    ''' [取込]ボタンの活性／非活性制御
    ''' </summary>
    Private Sub DisplayControl()
        btnImport.Enabled = False

        ' コンボボックス選択状態
        If cmbCategory.Visible Then
            If cmbCategory.SelectedValue <= 0 Then
                Return
            End If
        End If

        ' ファイル選択状態
        If String.IsNullOrEmpty(txtFilePath.Text.Trim()) Then
            Return
        End If

        btnImport.Enabled = True
    End Sub

#End Region

End Class
