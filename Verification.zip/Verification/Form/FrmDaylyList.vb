﻿''' <summary>
''' 日単位報酬確認画面
''' </summary>
Public Class FrmDaylyList
    Implements IObserber

	''' <summary>
	''' 対象年月度
	''' </summary>
	''' <returns></returns>
	Private Property TargetDate As Date

	''' <summary>
	''' 対象講師コード
	''' </summary>
	''' <returns></returns>
	Private Property TargetTeacherCode As String

	' コンストラクタ
	Public Sub New(ByVal p_TargetDate As Date, Optional ByVal keyCode As String = Nothing)
		' この呼び出しはデザイナーで必要です。
		InitializeComponent()

		' 対象年月度
		TargetDate = p_TargetDate
		TargetTeacherCode = keyCode
	End Sub

	''' <summary>
	''' Loadイベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub FrmDaylyList_Load(sender As Object, e As EventArgs) Handles Me.Load
		'InitDisplay()
	End Sub

	''' <summary>
	''' 画面サイズ変更イベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub FrmDaylyList_Resize(sender As Object, e As EventArgs) Handles Me.Resize
		DataGridView1.Height = Size.Height - DataGridView1.Top - 50
	End Sub

	''' <summary>
	''' 初期表示処理
	''' </summary>
	Private Sub InitDisplay()
		Dim width As Integer = Me.MdiParent.ClientSize.Width
		Dim height As Integer = Me.MdiParent.ClientSize.Height
		Me.Left = Me.MdiParent.MdiChildren.FirstOrDefault(Function(f) f.Name = "FrmMonthlyList").Size.Width
		Me.Top = 0
		Me.Height = height - 4

		' 情報表示
		DataGridView1.SuspendLayout()
		DataGridView1.MultiSelect = False
		DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
		DataGridView1.DefaultCellStyle.SelectionBackColor = Color.Yellow
		DataGridView1.Rows.Clear()
    Dim service As New DaylyListService(TargetDate, DataGridView1)
    Dim param As New DaoParameter
    param.TeacherCode = TargetTeacherCode
    service.Display(param)
    SetColor()
		DataGridView1.ResumeLayout()
	End Sub

	''' <summary>
	''' 表示対象変更通知
	''' </summary>
	Public Sub Notify(ByVal key As Date) Implements IObserber.Notify
		TargetDate = key
		InitDisplay()
	End Sub

	''' <summary>
	''' 講師選択通知受信
	''' </summary>
	''' <param name="keyCode"></param>
	Public Sub TeacherSelectNotify(keyCode As String) Implements IObserber.TeacherSelectNotify
		TargetTeacherCode = keyCode
		InitDisplay()
    End Sub

	''' <summary>
	''' Windowクローズイベント受信
	''' </summary>
	Public Sub WindowCloseNotify() Implements IObserber.WindowCloseNotify
		Close()
	End Sub

	''' <summary>
	''' セルの色設定
	''' </summary>
	Public Sub SetColor()
		DataGridView1.EnableHeadersVisualStyles = False
		Dim targetColumn As DataGridViewColumn
		Dim backColor As Color

		DataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue

		' 合計報酬
		backColor = ColorTranslator.FromHtml("#99CCCC")
		backColor = Color.PaleGreen
		DataGridView1.Columns(10).HeaderCell.Style.BackColor = backColor
		DataGridView1.Columns(10).HeaderCell.Style.ForeColor = Color.DarkBlue
		targetColumn = DataGridView1.Columns(10)
		targetColumn.DefaultCellStyle.BackColor = backColor
		targetColumn.DefaultCellStyle.ForeColor = Color.Black
		targetColumn.DefaultCellStyle.Font = New Font("游ゴシック", 9, FontStyle.Bold)

		' 基本報酬
		backColor = ColorTranslator.FromHtml("#CCFFCC")
		DataGridView1.Columns(11).HeaderCell.Style.BackColor = backColor
		DataGridView1.Columns(11).HeaderCell.Style.ForeColor = Color.DarkBlue
		targetColumn = DataGridView1.Columns(11)
		targetColumn.DefaultCellStyle.BackColor = backColor
		targetColumn.DefaultCellStyle.ForeColor = Color.DarkBlue
		' コマ報酬
		DataGridView1.Columns(12).HeaderCell.Style.BackColor = backColor
		DataGridView1.Columns(12).HeaderCell.Style.ForeColor = Color.DarkBlue
		targetColumn = DataGridView1.Columns(12)
		targetColumn.DefaultCellStyle.BackColor = backColor
		targetColumn.DefaultCellStyle.ForeColor = Color.DarkBlue

		' 再描画を強制して変更を反映
		DataGridView1.Invalidate()
	End Sub

End Class