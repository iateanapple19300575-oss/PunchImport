﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmDaylyList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
		Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Me.DataGridView1 = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'DataGridView1
		'
		Me.DataGridView1.AllowUserToAddRows = False
		Me.DataGridView1.AllowUserToDeleteRows = False
		Me.DataGridView1.AllowUserToResizeRows = False
		Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle1.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent
		DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
		Me.DataGridView1.ColumnHeadersHeight = 25
		Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column20, Me.Column13, Me.Column14, Me.Column15, Me.Column16, Me.Column17, Me.Column18, Me.Column19})
		DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle21.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		DataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.LightSkyBlue
		DataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle21
		Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
		Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
		Me.DataGridView1.Name = "DataGridView1"
		Me.DataGridView1.ReadOnly = True
		Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle22.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		DataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight
		DataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText
		DataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle22
		Me.DataGridView1.RowHeadersWidth = 20
		Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
		DataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle23
		Me.DataGridView1.RowTemplate.Height = 21
		Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
		Me.DataGridView1.Size = New System.Drawing.Size(1112, 806)
		Me.DataGridView1.TabIndex = 0
		'
		'Column1
		'
		DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle2.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Column1.DefaultCellStyle = DataGridViewCellStyle2
		Me.Column1.HeaderText = "講師ｺｰﾄﾞ"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column1.Width = 65
		'
		'Column2
		'
		DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle3.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Column2.DefaultCellStyle = DataGridViewCellStyle3
		Me.Column2.HeaderText = "講師名"
		Me.Column2.Name = "Column2"
		Me.Column2.ReadOnly = True
		Me.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column2.Width = 120
		'
		'Column3
		'
		Me.Column3.HeaderText = "日付"
		Me.Column3.Name = "Column3"
		Me.Column3.ReadOnly = True
		Me.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		'
		'Column4
		'
		DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle4.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle4.Format = "#,##0.00""H"""
		DataGridViewCellStyle4.NullValue = Nothing
		Me.Column4.DefaultCellStyle = DataGridViewCellStyle4
		Me.Column4.HeaderText = "勤務時間"
		Me.Column4.Name = "Column4"
		Me.Column4.ReadOnly = True
		Me.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column4.Width = 65
		'
		'Column5
		'
		DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle5.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle5.Format = "C0"
		DataGridViewCellStyle5.NullValue = Nothing
		Me.Column5.DefaultCellStyle = DataGridViewCellStyle5
		Me.Column5.HeaderText = "出勤"
		Me.Column5.Name = "Column5"
		Me.Column5.ReadOnly = True
		Me.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column5.Width = 70
		'
		'Column6
		'
		DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle6.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle6.Format = "C0"
		DataGridViewCellStyle6.NullValue = Nothing
		Me.Column6.DefaultCellStyle = DataGridViewCellStyle6
		Me.Column6.HeaderText = "退勤"
		Me.Column6.Name = "Column6"
		Me.Column6.ReadOnly = True
		Me.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column6.Width = 70
		'
		'Column7
		'
		DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle7.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle7.Format = "C0"
		DataGridViewCellStyle7.NullValue = Nothing
		Me.Column7.DefaultCellStyle = DataGridViewCellStyle7
		Me.Column7.HeaderText = "勤務開始"
		Me.Column7.Name = "Column7"
		Me.Column7.ReadOnly = True
		Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column7.Width = 70
		'
		'Column8
		'
		DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle8.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle8.Format = "N0"
		DataGridViewCellStyle8.NullValue = Nothing
		Me.Column8.DefaultCellStyle = DataGridViewCellStyle8
		Me.Column8.HeaderText = "勤務終了"
		Me.Column8.Name = "Column8"
		Me.Column8.ReadOnly = True
		Me.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column8.Width = 70
		'
		'Column9
		'
		DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		Me.Column9.DefaultCellStyle = DataGridViewCellStyle9
		Me.Column9.HeaderText = "実績出勤"
		Me.Column9.Name = "Column9"
		Me.Column9.ReadOnly = True
		Me.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column9.Visible = False
		Me.Column9.Width = 70
		'
		'Column10
		'
		DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		Me.Column10.DefaultCellStyle = DataGridViewCellStyle10
		Me.Column10.HeaderText = "実績退勤"
		Me.Column10.Name = "Column10"
		Me.Column10.ReadOnly = True
		Me.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column10.Visible = False
		Me.Column10.Width = 70
		'
		'Column11
		'
		DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle11.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		DataGridViewCellStyle11.Format = "C0"
		DataGridViewCellStyle11.NullValue = Nothing
		Me.Column11.DefaultCellStyle = DataGridViewCellStyle11
		Me.Column11.HeaderText = "合計報酬"
		Me.Column11.Name = "Column11"
		Me.Column11.ReadOnly = True
		Me.Column11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column11.Width = 72
		'
		'Column12
		'
		DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle12.Format = "C0"
		DataGridViewCellStyle12.NullValue = Nothing
		Me.Column12.DefaultCellStyle = DataGridViewCellStyle12
		Me.Column12.HeaderText = "業務給"
		Me.Column12.Name = "Column12"
		Me.Column12.ReadOnly = True
		Me.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column12.Width = 60
		'
		'Column20
		'
		DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle13.Format = "C0"
		DataGridViewCellStyle13.NullValue = Nothing
		Me.Column20.DefaultCellStyle = DataGridViewCellStyle13
		Me.Column20.HeaderText = "授業給"
		Me.Column20.Name = "Column20"
		Me.Column20.ReadOnly = True
		Me.Column20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column20.Width = 60
		'
		'Column13
		'
		DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle14.Format = "N0"
		DataGridViewCellStyle14.NullValue = Nothing
		Me.Column13.DefaultCellStyle = DataGridViewCellStyle14
		Me.Column13.HeaderText = "1年"
		Me.Column13.Name = "Column13"
		Me.Column13.ReadOnly = True
		Me.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column13.Width = 35
		'
		'Column14
		'
		DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle15.Format = "N0"
		DataGridViewCellStyle15.NullValue = Nothing
		Me.Column14.DefaultCellStyle = DataGridViewCellStyle15
		Me.Column14.HeaderText = "2年"
		Me.Column14.Name = "Column14"
		Me.Column14.ReadOnly = True
		Me.Column14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column14.Width = 35
		'
		'Column15
		'
		DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle16.Format = "N0"
		Me.Column15.DefaultCellStyle = DataGridViewCellStyle16
		Me.Column15.HeaderText = "3年"
		Me.Column15.Name = "Column15"
		Me.Column15.ReadOnly = True
		Me.Column15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column15.Width = 35
		'
		'Column16
		'
		DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle17.Format = "N0"
		Me.Column16.DefaultCellStyle = DataGridViewCellStyle17
		Me.Column16.HeaderText = "4年"
		Me.Column16.Name = "Column16"
		Me.Column16.ReadOnly = True
		Me.Column16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column16.Width = 35
		'
		'Column17
		'
		DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle18.Format = "N0"
		Me.Column17.DefaultCellStyle = DataGridViewCellStyle18
		Me.Column17.HeaderText = "5年"
		Me.Column17.Name = "Column17"
		Me.Column17.ReadOnly = True
		Me.Column17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column17.Width = 35
		'
		'Column18
		'
		DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle19.Format = "N0"
		Me.Column18.DefaultCellStyle = DataGridViewCellStyle19
		Me.Column18.HeaderText = "6年"
		Me.Column18.Name = "Column18"
		Me.Column18.ReadOnly = True
		Me.Column18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column18.Width = 35
		'
		'Column19
		'
		DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle20.Format = "N0"
		DataGridViewCellStyle20.NullValue = Nothing
		Me.Column19.DefaultCellStyle = DataGridViewCellStyle20
		Me.Column19.HeaderText = "計"
		Me.Column19.Name = "Column19"
		Me.Column19.ReadOnly = True
		Me.Column19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column19.Width = 40
		'
		'FrmDaylyList
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1112, 806)
		Me.Controls.Add(Me.DataGridView1)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "FrmDaylyList"
		Me.Text = "日単位報酬確認"
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents DataGridView1 As DataGridView
	Friend WithEvents Column1 As DataGridViewTextBoxColumn
	Friend WithEvents Column2 As DataGridViewTextBoxColumn
	Friend WithEvents Column3 As DataGridViewTextBoxColumn
	Friend WithEvents Column4 As DataGridViewTextBoxColumn
	Friend WithEvents Column5 As DataGridViewTextBoxColumn
	Friend WithEvents Column6 As DataGridViewTextBoxColumn
	Friend WithEvents Column7 As DataGridViewTextBoxColumn
	Friend WithEvents Column8 As DataGridViewTextBoxColumn
	Friend WithEvents Column9 As DataGridViewTextBoxColumn
	Friend WithEvents Column10 As DataGridViewTextBoxColumn
	Friend WithEvents Column11 As DataGridViewTextBoxColumn
	Friend WithEvents Column12 As DataGridViewTextBoxColumn
	Friend WithEvents Column20 As DataGridViewTextBoxColumn
	Friend WithEvents Column13 As DataGridViewTextBoxColumn
	Friend WithEvents Column14 As DataGridViewTextBoxColumn
	Friend WithEvents Column15 As DataGridViewTextBoxColumn
	Friend WithEvents Column16 As DataGridViewTextBoxColumn
	Friend WithEvents Column17 As DataGridViewTextBoxColumn
	Friend WithEvents Column18 As DataGridViewTextBoxColumn
	Friend WithEvents Column19 As DataGridViewTextBoxColumn
End Class
