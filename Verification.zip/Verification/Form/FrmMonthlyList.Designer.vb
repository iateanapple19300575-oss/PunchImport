﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMonthlyList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Me.DataGridView1 = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'DataGridView1
		'
		Me.DataGridView1.AllowUserToAddRows = False
		Me.DataGridView1.AllowUserToDeleteRows = False
		Me.DataGridView1.AllowUserToResizeRows = False
		Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle1.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent
		DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
		Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
		Me.DataGridView1.ColumnHeadersHeight = 25
		Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7})
		DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle9.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.LightSkyBlue
		DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle9
		Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
		Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
		Me.DataGridView1.Name = "DataGridView1"
		Me.DataGridView1.ReadOnly = True
		Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle10.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
		DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
		DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
		Me.DataGridView1.RowHeadersWidth = 20
		Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
		DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle11
		Me.DataGridView1.RowTemplate.Height = 21
		Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
		Me.DataGridView1.Size = New System.Drawing.Size(610, 753)
		Me.DataGridView1.TabIndex = 0
		'
		'Column1
		'
		DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
		DataGridViewCellStyle2.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Column1.DefaultCellStyle = DataGridViewCellStyle2
		Me.Column1.HeaderText = "講師ｺｰﾄﾞ"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column1.Width = 65
		'
		'Column2
		'
		DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle3.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Column2.DefaultCellStyle = DataGridViewCellStyle3
		Me.Column2.HeaderText = "講師名"
		Me.Column2.Name = "Column2"
		Me.Column2.ReadOnly = True
		Me.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column2.Width = 120
		'
		'Column3
		'
		DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle4.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle4.Format = "#,##0.00""H"""
		DataGridViewCellStyle4.NullValue = Nothing
		Me.Column3.DefaultCellStyle = DataGridViewCellStyle4
		Me.Column3.HeaderText = "勤務時間"
		Me.Column3.Name = "Column3"
		Me.Column3.ReadOnly = True
		Me.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column3.Width = 75
		'
		'Column4
		'
		DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle5.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle5.Format = "C0"
		DataGridViewCellStyle5.NullValue = Nothing
		Me.Column4.DefaultCellStyle = DataGridViewCellStyle5
		Me.Column4.HeaderText = "合計報酬金額"
		Me.Column4.Name = "Column4"
		Me.Column4.ReadOnly = True
		Me.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column4.Width = 90
		'
		'Column5
		'
		DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle6.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle6.Format = "C0"
		DataGridViewCellStyle6.NullValue = Nothing
		Me.Column5.DefaultCellStyle = DataGridViewCellStyle6
		Me.Column5.HeaderText = "基本報酬"
		Me.Column5.Name = "Column5"
		Me.Column5.ReadOnly = True
		Me.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column5.Width = 90
		'
		'Column6
		'
		DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle7.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle7.Format = "C0"
		DataGridViewCellStyle7.NullValue = Nothing
		Me.Column6.DefaultCellStyle = DataGridViewCellStyle7
		Me.Column6.HeaderText = "コマ報酬"
		Me.Column6.Name = "Column6"
		Me.Column6.ReadOnly = True
		Me.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column6.Width = 80
		'
		'Column7
		'
		DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
		DataGridViewCellStyle8.Font = New System.Drawing.Font("游ゴシック", 9.0!)
		DataGridViewCellStyle8.Format = "N0"
		DataGridViewCellStyle8.NullValue = Nothing
		Me.Column7.DefaultCellStyle = DataGridViewCellStyle8
		Me.Column7.HeaderText = "コマ数"
		Me.Column7.Name = "Column7"
		Me.Column7.ReadOnly = True
		Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
		Me.Column7.Width = 50
		'
		'FrmMonthlyList
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(610, 753)
		Me.Controls.Add(Me.DataGridView1)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "FrmMonthlyList"
		Me.Text = "月単位報酬確認"
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents DataGridView1 As DataGridView
	Friend WithEvents Column1 As DataGridViewTextBoxColumn
	Friend WithEvents Column2 As DataGridViewTextBoxColumn
	Friend WithEvents Column3 As DataGridViewTextBoxColumn
	Friend WithEvents Column4 As DataGridViewTextBoxColumn
	Friend WithEvents Column5 As DataGridViewTextBoxColumn
	Friend WithEvents Column6 As DataGridViewTextBoxColumn
	Friend WithEvents Column7 As DataGridViewTextBoxColumn
End Class
