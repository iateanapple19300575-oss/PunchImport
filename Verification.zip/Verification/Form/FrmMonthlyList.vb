﻿Imports Freamwork.Common.Helper
Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 月単位報酬確認画面
''' </summary>
Public Class FrmMonthlyList
  Implements IObserber

  ' 対象年月度
  Private Property TargetDate As Date

  ''' <summary>
  ''' 日単位報酬確認画面
  ''' </summary>
  Private frmDayly As FrmDaylyList

  ''' <summary>
  ''' 講師ｺｰﾄﾞ通知先管理
  ''' </summary>
  Private m_NotifyControl As New KeyDestinationSelector()

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New(ByVal p_TargetDate As Date)
    ' この呼び出しはデザイナーで必要です。
    InitializeComponent()

    ' 対象年月度
    TargetDate = p_TargetDate
  End Sub

  ''' <summary>
  ''' Loadイベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub FrmMonthlyList_Load(sender As Object, e As EventArgs) Handles Me.Load
    InitDisplay()
    SelectedRowChange()
  End Sub

  ''' <summary>
  ''' 画面サイズ変更イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub FrmMonthlyList_Resize(sender As Object, e As EventArgs) Handles Me.Resize
    DataGridView1.Height = Size.Height - DataGridView1.Top - 50
  End Sub

  ''' <summary>
  ''' 対象年月変更通知受信
  ''' </summary>
  Public Sub Notify(ByVal key As Date) Implements IObserber.Notify
    TargetDate = key
    InitDisplay()
    SelectedRowChange()
    Me.Activate()
  End Sub

  ''' <summary>
  ''' 初期表示処理
  ''' </summary>
  Private Sub InitDisplay()
    ' 情報表示
    DataGridView1.SuspendLayout()
    DataGridView1.MultiSelect = False
    DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
    DataGridView1.DefaultCellStyle.SelectionBackColor = Color.Yellow
    DataGridView1.Rows.Clear()
    Dim service As New MonthlyListService(TargetDate, DataGridView1)
    service.Display()
    SetColor()
    DataGridView1.ResumeLayout()
  End Sub

  ''' <summary>
  ''' セルの色設定
  ''' </summary>
  Public Sub SetColor()
    ' 奇数行の背景色
    DataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue
  End Sub

  ''' <summary>
  ''' DataGridView セルダブルクリックイベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
    TeacherSelectNotify(e.RowIndex)
  End Sub

  ''' <summary>
  ''' DataGridView 選択変更イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView1.SelectionChanged
    SelectedRowChange()
  End Sub

  ''' <summary>
  ''' 選択講師変更時の通知判定
  ''' </summary>
  Private Sub SelectedRowChange()
    If DataGridView1.SelectedRows.Count <= 0 Then
      m_NotifyControl.WindowCloseNotify()
      Return
    End If

    Dim row As DataGridViewRow = DataGridView1.SelectedRows.Item(0)
    TeacherSelectNotify(row.Index)
  End Sub

  ''' <summary>
  ''' 対象講師コード変更通知処理
  ''' </summary>
  ''' <param name="rowIndex"></param>
  Private Sub TeacherSelectNotify(ByVal rowIndex As Integer)
    If rowIndex >= 0 Then
      Dim keyCode As String = DataGridView1.Rows(rowIndex).Cells(0).Value
      MouseCursor.WaitCursor(Me)
      If StringUtil.IsNotNullOrWhiteSpace(keyCode) Then
        If Not m_NotifyControl.IsWindowsExist("FrmDaylyList") Then
          frmDayly = New FrmDaylyList(TargetDate, keyCode)
          m_NotifyControl.Add(frmDayly)
          frmDayly.Left = Me.Width
          frmDayly.Top = 0
          frmDayly.Height = Height - 50
          frmDayly.StartPosition = FormStartPosition.Manual
          frmDayly.MdiParent = Me.MdiParent
          frmDayly.Show()
        End If
      End If

      m_NotifyControl.TeacherSelectNotify(keyCode)
      Me.Activate()

      MouseCursor.DefaultCursor(Me)
    End If
  End Sub

  ''' <summary>
  ''' 通知は無いので、何も処理しない。
  ''' </summary>
  ''' <param name="keyCode"></param>
  Public Sub TeacherSelectNotify(keyCode As String) Implements IObserber.TeacherSelectNotify
    Throw New NotImplementedException()
  End Sub

  ''' <summary>
  ''' 通知は無いので、何も処理しない。
  ''' </summary>
  Public Sub WindowCloseNotify() Implements IObserber.WindowCloseNotify
    Throw New NotImplementedException()
  End Sub
End Class