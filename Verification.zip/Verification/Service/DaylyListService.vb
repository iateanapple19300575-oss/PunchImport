﻿Imports System.Data.SqlClient

''' <summary>
''' 日単位報酬画面用サービス
''' </summary>
Public Class DaylyListService
    Inherits DataGridViewDisplayService

    ''' <summary>
    ''' システム環境設定データ
    ''' </summary>
    ''' <returns></returns>
    Private Property SystemEnvData As New SystemEnvData

    ''' <summary>
    ''' 基本報酬単価
    ''' </summary>
    ''' <returns></returns>
    Private Property BaseUnitAmount As Double = 0

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="p_dataGridView"></param>
    Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
        MyBase.New(targetDate, p_dataGridView)
        SystemEnvData = GetErrorColorInfo()
        BaseUnitAmount = SystemEnvData.BaseUnitPrice
    End Sub


    ''' <summary>
    ''' 表示データ取得クエリ取得
    ''' </summary>
    ''' <returns>表示データ取得クエリ</returns>
    Protected Overrides Function GetQuery(Optional ByVal param As DaoParameter = Nothing) As String
        Dim firstDay As String = DateUtil.FirstDayOfMonth(TargetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(TargetDate, "yyyy/MM/dd")

        Return DaylyListQuery.SelectSql(TargetDate, SystemEnvData.TimeSpan, SystemEnvData.BaseUnitPrice, param)
    End Function

    ''' <summary>
    ''' DataGridView表示編集
    ''' </summary>
    ''' <param name="reader"></param>
    Protected Overrides Sub GetReaderValue(reader As SqlDataReader)

        Dim row As Integer = 0
        With Me.DataGridView
            While reader.Read()
                .Rows.Add(1)
                .Rows(row).Cells(0).Value = reader.GetValue(0)
                .Rows(row).Cells(1).Value = reader.GetValue(1)
                Dim dtDate As Date
                Dim strDay As String
                dtDate = reader.GetValue(2)
                strDay = dtDate.ToString("ddd")
                .Rows(row).Cells(2).Value = dtDate.ToString("yyyy/MM/dd") & "(" & strDay & ")"
                If (Weekday(dtDate) = 1) Then
                    .Rows(row).Cells(2).Style.ForeColor = Color.Red
                ElseIf (Weekday(dtDate) = 7) Then
                    .Rows(row).Cells(2).Style.ForeColor = Color.Blue
                Else
                    .Rows(row).Cells(2).Style.ForeColor = Color.Black
                End If
                .Rows(row).Cells(3).Value = reader.GetValue(24)
                .Rows(row).Cells(4).Value = reader.GetValue(3)
                .Rows(row).Cells(5).Value = reader.GetValue(4)
                .Rows(row).Cells(6).Value = reader.GetValue(13)
                .Rows(row).Cells(7).Value = reader.GetValue(14)
                .Rows(row).Cells(8).Value = reader.GetValue(7)
                .Rows(row).Cells(9).Value = reader.GetValue(8)

                ' ①基本報酬（基本単価 * みなし勤務時間）
                Dim baseTotalAmount As Double = 0
                .Rows(row).Cells(11).Value = ""
                If (Not reader.IsDBNull(24)) Then
                    ' 基本報酬＝基本単価 * みなし勤務時間
                    Dim baseTotaltime As Double = IIf(reader.IsDBNull(24), 0, reader.GetValue(24))
                    baseTotalAmount = Math.Round(BaseUnitAmount * baseTotaltime, 2, MidpointRounding.AwayFromZero)
                    .Rows(row).Cells(11).Value = baseTotalAmount
                End If

                ' ②コマ報酬
                Dim komaTotalAmount As Double = 0
                .Rows(row).Cells(12).Value = ""
                If (Not reader.IsDBNull(23)) Then
                    komaTotalAmount = reader.GetValue(23)
                End If
                .Rows(row).Cells(12).Value = komaTotalAmount

                ' ③合計報酬＝①基本報酬 + ②コマ報酬
                Dim dayTotalAmount As Double = baseTotalAmount + komaTotalAmount
                .Rows(row).Cells(10).Value = dayTotalAmount

                .Rows(row).Cells(13).Value = reader.GetValue(15)
                .Rows(row).Cells(14).Value = reader.GetValue(16)
                .Rows(row).Cells(15).Value = reader.GetValue(17)
                .Rows(row).Cells(16).Value = reader.GetValue(18)
                .Rows(row).Cells(17).Value = reader.GetValue(19)
                .Rows(row).Cells(18).Value = reader.GetValue(20)
                .Rows(row).Cells(19).Value = reader.GetValue(21)
                row += 1
            End While
        End With
    End Sub

    ''' <summary>
    ''' システム環境設定データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetErrorColorInfo() As SystemEnvData
        Dim result As New SystemEnvData

        Dim tran As New SystemEnvTran()
        Dim resultData As ResultData = tran.SelectData()
        If (resultData.Success) Then
            result = resultData.ResDataClass
        End If

        Return result
    End Function

End Class
