﻿Imports System.Data.SqlClient

''' <summary>
''' 月単位報酬画面用サービス
''' </summary>
Public Class MonthlyListService
    Inherits DataGridViewDisplayService

    ''' <summary>
    ''' システム環境設定データ
    ''' </summary>
    ''' <returns></returns>
    Private Property SystemEnvData As New SystemEnvData

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="p_dataGridView"></param>
    Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
        MyBase.New(targetDate, p_dataGridView)
        SystemEnvData = GetErrorColorInfo()
    End Sub

    ''' <summary>
    ''' 表示データ取得クエリ取得
    ''' </summary>
    ''' <returns>表示データ取得クエリ</returns>
    Protected Overrides Function GetQuery(Optional ByVal param As DaoParameter = Nothing) As String

        Dim firstDay As String = DateUtil.FirstDayOfMonth(MyBase.TargetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(MyBase.TargetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("SELECT ")
        sqlString.Append("    Staff_Code As 講師コード ")
        sqlString.Append("    , Full_Name As 講師名 ")
        sqlString.Append("    , SUM([みなし勤務時間]) As 月実時間 ")
        sqlString.Append("    , SUM([日基本報酬額]) + SUM(コマ報酬額) As 月報酬酬額 ")
        sqlString.Append("    , SUM([日基本報酬額]) As 月基本報酬額 ")
        sqlString.Append("    , SUM(コマ報酬額) As コマ報酬 ")
        sqlString.Append("    , SUM(コマ数計) As 月コマ数計 ")
        sqlString.Append("FROM ")
        sqlString.Append("    ( ")
        sqlString.Append("        SELECT ")
        sqlString.Append("            SD.Lecture_Date ")
        sqlString.Append("            , SD.Staff_Code ")
        sqlString.Append("            , SD.Full_Name ")
        sqlString.Append("            , ADLJ1.実績出勤 ")
        sqlString.Append("            , ADLJ1.実績退勤 ")
        sqlString.Append("            , ADLJ1.みなし出勤 ")
        sqlString.Append("            , ADLJ1.みなし退勤 ")
        sqlString.Append("            , ADLJ1.[みなし勤務時間] ")
        sqlString.Append("            , ADLJ1.[みなし勤務時間] * " & SystemEnvData.BaseUnitPrice & " + (AD.KomaCount * UP.Unit_Price) As [日報酬金額] ")
        sqlString.Append("            , ADLJ1.[みなし勤務時間] * " & SystemEnvData.BaseUnitPrice & " As [日基本報酬額] ")
        sqlString.Append("            , AD.KomaCount * UP.Unit_Price As コマ報酬額 ")
        sqlString.Append("            , AD.KomaCount As コマ数計 ")
        sqlString.Append("            , UP.Unit_Price As コマ単価 ")
        sqlString.Append("        FROM ")
        '                             -- 打刻データTBL ")
        sqlString.Append("            " & DBTableConst.TABLE_NAME_STAMP_DATA & " SD ")
        sqlString.Append("             ")
        '                             -- 出講実績の[みなし出勤]、[みなし退勤] ")
        sqlString.Append("            LEFT JOIN ( ")
        sqlString.Append("                SELECT ")
        sqlString.Append("                    Lecture_Date ")
        sqlString.Append("                    , Teacher_Code ")
        sqlString.Append("                    , MIN(Start_Time) As 実績出勤 ")
        sqlString.Append("                    , MAX(End_Time) As 実績退勤 ")
        sqlString.Append("                    , SUBSTRING(CONVERT(VARCHAR, DATEADD(minute, -")
        sqlString.Append("                        (SELECT TOP 1 MAX([Deemed_Time_Before]) FROM [GH2000].[dbo].[M_Hourly_Wage] WHERE [Effective_Date]<=Lecture_Date) ")
        sqlString.Append("                        , MIN(Start_Time)), 108), 1,5) As [みなし出勤] ")
        sqlString.Append("                    , SUBSTRING(CONVERT(VARCHAR, DATEADD(minute, ")
        sqlString.Append("                        (SELECT TOP 1 MAX([Deemed_Time_After]) FROM [GH2000].[dbo].[M_Hourly_Wage] WHERE [Effective_Date]<=Lecture_Date) ")
        sqlString.Append("                        , MAX(End_Time)), 108), 1,5) As [みなし退勤] ")
        sqlString.Append("                    , CAST(")
        sqlString.Append("                        ROUND(")
        sqlString.Append("                          CAST(")
        sqlString.Append("                            DATEDIFF(minute, DATEADD(minute, -" & SystemEnvData.TimeSpan & ", MIN(Start_Time)), DATEADD(minute, " & SystemEnvData.TimeSpan & ", MAX(End_Time))) As Decimal(10, 2)) / 60 ")
        sqlString.Append("                        , 2) As Decimal(10, 2) ")
        sqlString.Append("                      ) As [みなし勤務時間]  ")
        sqlString.Append("                FROM ")
        sqlString.Append("                        " & W_Lecture_ActualEnum.フェーズ.Table & " AD ")
        sqlString.Append("                    WHERE ")
        sqlString.Append("                        1 = 1 ")
        sqlString.Append("                        And AD.Lecture_Date >= '" & firstDay & "' ")
        sqlString.Append("                        AND AD.Lecture_Date <= '" & lastDay & "' ")
        sqlString.Append("                        AND AD.[Phase] = " & LectureFeeConst.PHASE_ACTUAL & " ")
        'sqlString.Append("                        AND (AD.[data_type] = " & LectureFeeConst.DATA_PLAN & " ")
        'sqlString.Append("                        OR   AD.[data_type] = " & LectureFeeConst.DATA_REQUEST & ") ")
        sqlString.Append("                GROUP BY ")
        sqlString.Append("                    Lecture_Date ")
        sqlString.Append("                    , Teacher_Code ")
        sqlString.Append("            ) ADLJ1 ")
        sqlString.Append("                ON ( ")
        sqlString.Append("                    SD.Staff_Code = ADLJ1.Teacher_Code ")
        sqlString.Append("                    AND SD.Lecture_Date = ADLJ1.Lecture_Date ")
        sqlString.Append("                ) ")
        '                             -- [コマ数]、[コマ給] ")
        sqlString.Append("            LEFT JOIN ( ")
        sqlString.Append("                SELECT ")
        sqlString.Append("                    AD.[Teacher_Code] ")
        sqlString.Append("                    , AD.Lecture_Date ")
        sqlString.Append("                    , COUNT(*) As KomaCount ")
        sqlString.Append("                FROM ")
        sqlString.Append("                    " & W_Lecture_ActualEnum.フェーズ.Table & " AD ")
        sqlString.Append("                WHERE ")
        sqlString.Append("                    1 = 1 ")
        sqlString.Append("                    AND AD.Lecture_Date >= '" & firstDay & "' ")
        sqlString.Append("                    AND AD.Lecture_Date <= '" & lastDay & "' ")
        sqlString.Append("                    AND AD.[Phase] = " & LectureFeeConst.PHASE_ACTUAL & " ")
        sqlString.Append("                    AND AD.[Data_Type] = " & LectureFeeConst.DATA_CLASSWORK & " ")
        sqlString.Append("                GROUP BY ")
        sqlString.Append("                    AD.Teacher_Code ")
        sqlString.Append("                    , AD.Lecture_Date ")
        sqlString.Append("            ) AD ")
        sqlString.Append("                ON ( ")
        sqlString.Append("                    SD.Staff_Code = AD.Teacher_Code ")
        sqlString.Append("                    AND SD.Lecture_Date = AD.Lecture_Date ")
        sqlString.Append("                ) ")
        sqlString.Append("            LEFT JOIN " & DBTableConst.TABLE_NAME_KOMA_PRICE & " UP ")
        sqlString.Append("                ON (AD.Teacher_Code = UP.Teacher_Code) ")
        sqlString.Append("        WHERE ")
        sqlString.Append("            1 = 1 ")
        sqlString.Append("            AND SD.Lecture_Date >= '" & firstDay & "' ")
        sqlString.Append("            AND SD.Lecture_Date <= '" & lastDay & "' ")
        sqlString.Append("    ) AA ")
        sqlString.Append("WHERE ")
        sqlString.Append("  1=1 ")

        If param IsNot Nothing AndAlso Not String.IsNullOrEmpty(param.TeacherCode) Then
            sqlString.Append("  AND [講師コード] = '" & param.TeacherCode & "' ")
        End If

        sqlString.Append("GROUP BY ")
        sqlString.Append("    Staff_Code ")
        sqlString.Append("    , Full_Name ")
        sqlString.Append("ORDER BY ")
        sqlString.Append("    [講師コード] ")
        sqlString.Append("; ")

        Return sqlString.ToString()
    End Function

    ''' <summary>
    ''' DataGridView表示編集
    ''' </summary>
    ''' <param name="reader"></param>
    Protected Overrides Sub GetReaderValue(reader As SqlDataReader)

        Dim row As Integer = 0
        With DataGridView
            While reader.Read()
                .Rows.Add(1)
                .Rows(row).Cells(0).Value = reader.GetValue(0)
                .Rows(row).Cells(1).Value = reader.GetValue(1)
                .Rows(row).Cells(2).Value = reader.GetValue(2)
                .Rows(row).Cells(3).Value = reader.GetValue(3)
                .Rows(row).Cells(4).Value = reader.GetValue(4)
                .Rows(row).Cells(5).Value = reader.GetValue(5)
                .Rows(row).Cells(6).Value = reader.GetValue(6)
                row += 1
            End While
        End With

    End Sub

    ''' <summary>
    ''' システム環境設定データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetErrorColorInfo() As SystemEnvData
        Dim result As New SystemEnvData

        Dim tran As New SystemEnvTran()
        Dim resultData As ResultData = tran.SelectData()
        If (resultData.Success) Then
            result = resultData.ResDataClass
        End If

        Return result
    End Function

End Class
