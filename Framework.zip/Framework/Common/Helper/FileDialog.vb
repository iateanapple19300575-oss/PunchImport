﻿Imports System.Windows.Forms

Public Class FileDialog

	''' <summary>
	''' 共通ファイル選択
	''' </summary>
	''' <returns></returns>
	Public Shared Function SelectCsvFile() As String
		' OpenFileDialog のインスタンスを作成
		Dim openFileDialog As New OpenFileDialog()
		' フィルタを設定
		openFileDialog.Filter = "CSV(カンマ区切り) (*.csv)|*.csv|すべてのファイル (*.*)|*.*" ' ファイルの種類を制限
		' ダイアログの説明文を設定
		openFileDialog.Title = "ファイルを選択してください" ' ダイアログのタイトル

		Dim pathName As String = ""
		If openFileDialog.ShowDialog() = DialogResult.OK Then
			Dim selectedFile As String = openFileDialog.FileName
			pathName = selectedFile
		End If

		Return pathName
	End Function

	''' <summary>
	''' 共通ファイル保存
	''' </summary>
	''' <returns></returns>
	Public Shared Function SelectSaveFile(Optional fileName As String = "TimetableSite.csv", Optional folder As String = "") As String
		' SaveFileDialog のインスタンスを作成
		Dim saveFileDialog As New SaveFileDialog()

		' デフォルトのファイル名
		saveFileDialog.FileName = fileName
		' フィルタを設定
		saveFileDialog.Filter = "CSV(カンマ区切り)(*.csv)|*.csv|Excelブック (*.xlsx)|*.xlsx|すべてのファイル (*.*)|*.*"
		' ダイアログの説明文を設定
		saveFileDialog.Title = "保存先のファイルを選択してください"
		' ダイアログの初期表示フォルダを設定(デスクトップ)
		saveFileDialog.InitialDirectory = IIf(folder <> "", folder, Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory))

		Dim pathName As String = ""
		If saveFileDialog.ShowDialog() = DialogResult.OK Then
			Dim selectedFile As String = saveFileDialog.FileName
			pathName = selectedFile
		End If

		Return pathName
	End Function

	''' <summary>
	''' 共通EXCELファイル保存
	''' </summary>
	''' <param name="defaultFileNme"></param>
	''' <param name="defaultPath"></param>
	''' <returns></returns>
	Public Shared Function SaveFileForExcel(ByVal defaultFileNme As String, ByVal defaultPath As String) As String
		' SaveFileDialog のインスタンスを作成
		Dim saveFileDialog As New SaveFileDialog()

		' デフォルトのファイル名
		saveFileDialog.FileName = defaultFileNme
		' フィルタを設定
		saveFileDialog.Filter = "Excelブック(*.xlsx)|*.xlsx"
		' ダイアログの説明文を設定
		saveFileDialog.Title = "保存先のファイル名を指定してください"
		' ダイアログの初期表示フォルダを設定
		If defaultPath <> "" Then
			saveFileDialog.InitialDirectory = defaultPath
		Else
			saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
		End If

		Dim pathName As String = ""
		If saveFileDialog.ShowDialog() = DialogResult.OK Then
			Dim selectedFile As String = saveFileDialog.FileName
			pathName = selectedFile
		End If

		Return pathName
	End Function

	''' <summary>
	''' 共通フォルダ選択
	''' </summary>
	''' <returns></returns>
	Public Shared Function SelectFolder() As String
		' FolderBrowserDialog のインスタンスを作成
		Dim folderBrowser As New FolderBrowserDialog()
		' ダイアログの説明文を設定
		folderBrowser.Description = "フォルダを選択してください。"
		' ダイアログの初期表示フォルダを設定(デスクトップ)
		folderBrowser.SelectedPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
		' 新しいフォルダ作成ボタンを表示（デフォルトはTrue）
		folderBrowser.ShowNewFolderButton = True

		Dim pathName As String = ""
		If folderBrowser.ShowDialog() = DialogResult.OK Then
			pathName = folderBrowser.SelectedPath
		End If

		Return pathName
	End Function
End Class
