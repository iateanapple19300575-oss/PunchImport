﻿Imports System.Windows.Forms

Public Class Mdihelper

	''' <summary>
	''' MDIクライアント背景色を設定する
	''' </summary>
	''' <param name="frm">背景色を設定する対象のフォーム</param>
	''' <param name="backColor">設定する背景色</param>
	''' <remarks></remarks>
	Public Shared Sub ChangeMdiClientBackColor(ByVal frm As System.Windows.Forms.Form, ByVal backColor As System.Drawing.Color)
		Dim mdiClient As System.Windows.Forms.MdiClient = GetMdiClient(frm)
		mdiClient.BackColor = backColor
	End Sub

	''' <summary>
	''' フォームのMdiClientコントロールを取得する
	''' </summary>
	''' <param name="frm">MdiClientコントロール取得対象のフォーム</param>
	''' <returns>MdiClientコントロール</returns>
	''' <remarks>
	''' MDIフォームのMDIクライアント領域の背景色を変更する際に使用するために用意
	''' </remarks>
	Public Shared Function GetMdiClient(ByVal frm As System.Windows.Forms.Form) As System.Windows.Forms.MdiClient
		Dim control As System.Windows.Forms.Control
		For Each control In frm.Controls
			If TypeOf control Is System.Windows.Forms.MdiClient Then
				Return CType(control, System.Windows.Forms.MdiClient)
			End If
		Next control

		Return Nothing
	End Function

	''' <summary>
	''' MDI子フォーム群に指定MDI子フォームが存在するか検索する。
	''' </summary>
	''' <param name="mdiChildren">MDI子フォーム群</param>
	''' <param name="mdiChild">検索対象のMDI子フォーム</param>
	''' <returns></returns>
	Public Shared Function FindChildForm(ByRef mdiChildren() As Form, ByRef mdiChild As Form) As Boolean
		For Each hMdiChild As Form In mdiChildren
			If (mdiChild Is hMdiChild) Then
				Return True
			End If
		Next hMdiChild

		Return False
	End Function

	''' <summary>
	''' MIDチャイルドフォームを左上に初期表示する。
	''' </summary>
	''' <param name="mdiParent">MDI親フォーム</param>
	''' <param name="mdiChild">MDI子フォーム</param>
	''' <param name="startPosition">表示位置</param>
	Public Shared Sub ShowMdiChildFormStart(ByRef mdiParent As Form, ByRef mdiChild As Form, ByRef mdiChildren() As Form, Optional ByVal startPosition As FormStartPosition = FormStartPosition.Manual)
		If FindChildForm(mdiChildren, mdiChild) Then
			mdiChild.Activate()
			mdiChild.Focus()
		Else
			mdiChild.MdiParent = mdiParent
			If (startPosition = FormStartPosition.Manual) Then
				mdiChild.StartPosition = FormStartPosition.Manual
				mdiChild.Left = 0
				mdiChild.Top = 0
			Else
				mdiChild.StartPosition = startPosition
			End If
			mdiChild.Show()
		End If
	End Sub

End Class
