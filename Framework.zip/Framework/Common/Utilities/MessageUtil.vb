﻿Imports System.Reflection
Imports System.Windows.Forms

Public Class MessageUtil

    ''' <summary>
    ''' メッセージ表示（情報）
    ''' </summary>
    ''' <param name="owner"></param>
    ''' <param name="msgId"></param>
    ''' <param name="caption"></param>
    ''' <returns></returns>
    Public Shared Function ShowMessageInfo(ByVal owner As IWin32Window, ByVal msgId As String, Optional ByVal caption As String = "") As DialogResult
        Return DisplayMessage(owner, msgId, MessageBoxButtons.OK, MessageBoxIcon.Information, caption)
    End Function

    ''' <summary>
    ''' メッセージ表示（警告）
    ''' </summary>
    ''' <param name="owner"></param>
    ''' <param name="msgId"></param>
    ''' <param name="caption"></param>
    ''' <returns></returns>
    Public Shared Function ShowMessageWarning(ByVal owner As IWin32Window, ByVal msgId As String, Optional ByVal caption As String = "") As DialogResult
        Return DisplayMessage(owner, msgId, MessageBoxButtons.OK, MessageBoxIcon.Warning, caption)
    End Function

    ''' <summary>
    ''' メッセージ表示（エラー）
    ''' </summary>
    ''' <param name="owner"></param>
    ''' <param name="msgId"></param>
    ''' <param name="caption"></param>
    ''' <returns></returns>
    Public Shared Function ShowMessageError(ByVal owner As IWin32Window, ByVal msgId As String, Optional ByVal caption As String = "") As DialogResult
        Return DisplayMessage(owner, msgId, MessageBoxButtons.OK, MessageBoxIcon.Error, caption)
    End Function

    ''' <summary>
    ''' メッセージ表示（エラー）
    ''' </summary>
    ''' <param name="owner"></param>
    ''' <param name="msgId"></param>
    ''' <param name="caption"></param>
    ''' <returns></returns>
    Public Shared Function ShowMessageCritical(ByVal owner As IWin32Window, ByVal msgId As String, Optional ByVal caption As String = "") As DialogResult
        Return DisplayMessage(owner, msgId, MessageBoxButtons.OK, MessageBoxIcon.Stop, caption)
    End Function

    ''' <summary>
    ''' メッセージ表示
    ''' </summary>
    ''' <param name="owner"></param>
    ''' <param name="msgId"></param>
    ''' <param name="caption"></param>
    ''' <returns></returns>
    Public Shared Function ShowMessage(ByVal owner As IWin32Window, ByVal msgId As String, Optional ByVal caption As String = "") As DialogResult
        Return DisplayMessage(owner, msgId, MessageBoxButtons.OK, MessageBoxIcon.Stop, caption)
    End Function

    ''' <summary>
    ''' メッセージ表示
    ''' </summary>
    ''' <param name="owner"></param>
    ''' <param name="msgId"></param>
    ''' <returns></returns>
    Private Shared Function DisplayMessage(ByVal owner As IWin32Window, ByVal msgId As String, Optional ByVal buttons As MessageBoxButtons = MessageBoxButtons.OK, Optional ByVal icon As MessageBoxIcon = MessageBoxIcon.Information, Optional ByVal caption As String = "") As DialogResult
        Dim result As DialogResult
        Dim messageString As String = msgId
        Dim assemblyName As String = If(String.IsNullOrEmpty(caption), GetAssemblyName(), caption)

        result = MessageBox.Show(owner, messageString, assemblyName, buttons, icon)

        Return result
    End Function

    ''' <summary>
    ''' アセンブリ名取得
    ''' </summary>
    ''' <returns></returns>
    Private Shared Function GetAssemblyName() As String
        Dim currentAssembly As Assembly = Assembly.GetExecutingAssembly()
        Return currentAssembly.GetName().Name
    End Function

End Class
