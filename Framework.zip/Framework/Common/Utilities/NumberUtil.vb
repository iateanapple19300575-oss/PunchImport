﻿Public Class NumberUtil

    ''' <summary>
    ''' 数字を3桁カンマの書式文字列に変換
    ''' </summary>
    ''' <param name="number"></param>
    ''' <returns></returns>
    Public Shared Function DigitComma(ByVal number As Integer) As String
        Return String.Format("{0:#,0}", number)
    End Function

    Public Shared Function StringNumberToDecimal(ByVal strNumber As String) As Decimal?
        Dim tryDecimal As Decimal
        If Not Decimal.TryParse(strNumber, tryDecimal) Then
            Return Nothing
        End If

        Return tryDecimal
    End Function





End Class
