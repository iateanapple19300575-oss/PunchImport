﻿Imports System.Windows.Forms
Imports System.Drawing

Public Class WinApiHelper

#Region "*** WIN32 API宣言 ***"

	Private Declare Auto Function SendMessage Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
	Private Declare Auto Function ReleaseCapture Lib "user32.dll" () As Boolean

#End Region


	''' <summary>
	''' 画面表示管理変数：画面表示サイズ：高さ
	''' </summary>
	Private Property CcreenHeight As Integer = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height

	''' <summary>
	''' 画面表示管理変数：画面表示サイズ：幅
	''' </summary>
	''' <returns></returns>
	Private Property ScreenWidth As Integer = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width

	''' <summary>
	''' 画面サイズ取得
	''' </summary>
	''' <param name="frm"></param>
	Public Shared Function ScreenSize(ByVal frm As Form) As Size
		Dim resultSize As New Size(0, 0)
		Dim monitor As New Size(0, 0)
		monitor.Height = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height
		monitor.Width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width

		If frm.WindowState = Windows.Forms.FormWindowState.Normal Then
			resultSize.Height = IIf(frm.Height > monitor.Height, monitor.Height, frm.Height)
			resultSize.Width = IIf(frm.Width > monitor.Width, monitor.Width, frm.Width)
		ElseIf frm.WindowState = FormWindowState.Maximized Then
			resultSize.Height = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height
			resultSize.Width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width
		End If
		Return resultSize
	End Function


End Class
