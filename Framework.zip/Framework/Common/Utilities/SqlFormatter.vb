﻿Imports System.Text

Public Class SqlFormatter

    Private Sub New()
    End Sub

    ''' <summary>
    ''' SQL文内の連続尾する複数の半角スペースを１つの半角スペースに変換する。
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <returns></returns>
    Public Shared Function Normalize(ByVal sql As String) As String

        If sql Is Nothing Then
            Return String.Empty
        End If

        Dim normalized As String = sql.Replace(vbCrLf, " ").Replace(vbLf, " ").Replace(vbCr, " ").Replace(vbTab, " ")
        Dim sb As New StringBuilder()
        Dim prevSpase As Boolean = False

        For Each ch As Char In normalized
            If ch = " "c Then
                If Not prevSpase Then
                    sb.Append(ch)
                    prevSpase = True
                End If
            Else
                sb.Append(ch)
                prevSpase = False
            End If
        Next

        Return sb.ToString().Trim()

    End Function
End Class
