﻿''' <summary>
''' CSV項目順番属性
''' </summary>
<AttributeUsage(AttributeTargets.Property)>
Public Class CsvOrderAttrbute
    Inherits Attribute

	''' <summary>
	''' 項目順番
	''' </summary>
	''' <returns></returns>
	Public Property Order As Integer
    Public Sub New(ByVal order As Integer)
        Me.Order = order
    End Sub

End Class
