﻿Public Interface IDataSourceStrategy
	Function LoadData(ByVal sourcePath As String) As System.Data.DataTable
End Interface
