﻿Imports System.IO
Imports System.Text
Imports Nts.Freamwork.Common.Utilities

Public Class CsvStrategy
  Implements IDataSourceStrategy

  ''' <summary>
  ''' CSVファイルのデータをDataTableに読み込み
  ''' </summary>
  ''' <param name="sourcePath"></param>
  ''' <returns></returns>
  Public Function LoadData(ByVal sourcePath As String) As System.Data.DataTable Implements IDataSourceStrategy.LoadData
    Dim dt As System.Data.DataTable = New System.Data.DataTable()

    Try
      Using reader As New StreamReader(sourcePath, Encoding.GetEncoding("Shift_JIS"))
        ' ヘッダ行読込
        Dim headerLine As String = reader.ReadLine()
        If headerLine Is Nothing Then
          Return dt
        End If

        ' 同じ名前でカラム定義
        Dim headers = ParseCsvLine(headerLine)
        For Each h In headers
          dt.Columns.Add(h)
        Next

        ' データ行読込
        While Not reader.EndOfStream
          ' 1行読込
          Dim line = reader.ReadLine()
          ' 空行はスキップ
          If StringUtil.IsNullOrEmpty(line) Then
            Continue While
          End If
          ' データ行を格納
          Dim fields = ParseCsvLine(line)
          If fields.Length = dt.Columns.Count Then
            dt.Rows.Add(fields)
          End If
        End While
      End Using

    Catch ex As Exception
      Throw
    Finally
    End Try

    Return dt
  End Function

  ''' <summary>
  ''' 1データを解析し
  ''' </summary>
  ''' <param name="line"></param>
  ''' <returns></returns>
  Private Function ParseCsvLine(ByVal line As String) As String()
    Dim result As New List(Of String)()
    Dim sb As New StringBuilder()
    Dim inQuotes As Boolean = False
    Dim i As Integer

    While i < line.Length
      Dim c = line(i)
      If c = """"c Then
        If inQuotes AndAlso i + 1 < line.Length AndAlso line(i + 1) = """"c Then
          ' エスケープのための[""]は、["]に変換してポインタを1つ飛ばす。
          sb.Append(""""c)
          i += 1
        Else
          ' 囲み文字判定フラグの反転
          inQuotes = Not inQuotes
        End If
      ElseIf c = ","c AndAlso Not inQuotes Then
        result.Add(sb.ToString())
        sb.Length = 0
      Else
        sb.Append(c)
      End If
      i += 1
    End While

    result.Add(sb.ToString())

    Return result.ToArray()
  End Function

End Class
