﻿Public Class DataValidator

	Public Shared Function Validate(ByVal dt As DataTable) As Boolean
		For Each row As DataRow In dt.Rows
			For Each col As DataColumn In dt.Columns
				If col.DataType Is GetType(String) AndAlso row(col).ToString().Trim() = "" Then
					Return False
				End If
			Next
		Next
		Return True
	End Function

End Class
