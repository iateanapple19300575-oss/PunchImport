﻿Imports System.Data.SqlClient

''' <summary>
''' SQLServer用
''' </summary>
Public Class SqlServerStrategy
	Implements IDataSourceStrategy

	''' <summary>
	''' データロード
	''' </summary>
	''' <param name="sourcePath"></param>
	''' <returns></returns>
	Public Function LoadData(ByVal sourcePath As String) As System.Data.DataTable Implements IDataSourceStrategy.LoadData
		Dim dt As System.Data.DataTable = New System.Data.DataTable()
		Dim connStr As String = ""
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("SELECT ")
		sqlString.Append("  " & " * ")
		sqlString.Append("FROM ")
		sqlString.Append("WHERE 1=1 ")
		sqlString.Append("  " & " ")

		Try
			Using conn As New SqlConnection(sourcePath)
				conn.Open()
				Using cmd As New SqlCommand(sqlString.ToString(), conn)
					Using adapter As New SqlDataAdapter(cmd)
						adapter.Fill(dt)
					End Using
				End Using
			End Using

		Catch ex As Exception
			Throw
		Finally
		End Try

		Return dt
	End Function
End Class
