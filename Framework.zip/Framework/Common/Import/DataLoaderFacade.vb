﻿Imports System.Windows.Forms
Imports DataSourceFactory

Public Class DataLoaderFacade
  Private m_strategy As IDataSourceStrategy
  Private m_dt As DataTable

  Public Function LoadAndValidator(ByVal sourceType As DataSourceType, ByVal sourcePath As String)
    m_strategy = DataSourceFactory.CreateStrategy(sourceType)
    m_dt = m_strategy.LoadData(sourcePath)
    Return DataValidator.Validate(m_dt)
  End Function

  Public Sub BindToGrid(ByVal grid As DataGridView)
    Dim bs As New BindingSource()
    bs.DataSource = m_dt
    grid.DataSource = bs
  End Sub

  Public Function GetData() As DataTable
    Return m_dt
  End Function
End Class
