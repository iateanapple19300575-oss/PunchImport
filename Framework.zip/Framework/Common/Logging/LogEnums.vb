﻿''' <summary>
''' ログレベルEnum
''' </summary>
Public Enum LogLevels
    Info
    Warn
    [Error]
    Fatal
End Enum

''' <summary>
''' ログ出力先Enum
''' </summary>
Public Enum LogTargets
    File
    Database
End Enum

''' <summary>
''' ログローテーションEnum
''' </summary>
Public Enum RotationPolicy
    None
    Daily
    Monthly
    yearly
    Size
End Enum

''' <summary>
''' 未処理例外Enum
''' </summary>
Public Enum ErrorContext
    UiThread        ' UI スレッドの未処理例外
    NonUiThread     ' 非 UI スレッドの未処理例外
    Manual          ' 通常の例外
End Enum
