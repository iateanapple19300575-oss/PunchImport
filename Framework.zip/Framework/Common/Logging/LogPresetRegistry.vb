﻿''' <summary>
''' ログ設定のプリセット（名前付き LogAttribute）を登録・取得するためのレジストリ。
''' アプリケーション全体で共通のログ設定を再利用するために使用する。
''' </summary>

Public NotInheritable Class LogPresetRegistry
    ''' <summary>
    ''' プリセット名と LogAttribute のマッピングを保持する辞書。
    ''' </summary>
    Private Shared ReadOnly _presets As New Dictionary(Of String, LogAttribute)()

    ''' <summary>
    ''' 指定された名前でログプリセットを登録する。
    ''' 同名のプリセットが存在する場合は上書きされる。
    ''' </summary>
    ''' <param name="name">プリセット名</param>
    ''' <param name="settings">登録するログ設定(LogAttribute)</param>
    Public Shared Sub Register(name As String, settings As LogAttribute)
        _presets(name) = settings
    End Sub

    ''' <summary>
    ''' 指定されたプリセット名に対応する LogAttribute を取得する。
    ''' 見つからない場合は Nothing を返す。
    ''' </summary>
    ''' <param name="name">取得したいプリセット名</param>
    ''' <returns>対応する LogAttribute。存在しない場合は Nothing。</returns>
    Public Shared Function GetPreset(name As String) As LogAttribute
        Dim result As LogAttribute = Nothing
        If _presets.TryGetValue(name, result) Then
            Return result
        End If
        Return Nothing
    End Function
End Class
