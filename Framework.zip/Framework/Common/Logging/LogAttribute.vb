﻿''' <summary>
''' メソッドに付与してログ出力の設定を行うための属性。
''' ログレベル、テンプレート、イベントフィルタなどを細かく制御できる。
''' </summary>
''' <remarks>
''' メソッド単位でログ設定を上書きしたい場合に使用する。
''' LogDefaultsAttribute（クラス単位のデフォルト設定）よりも優先される。
''' </remarks>
<AttributeUsage(AttributeTargets.Method, AllowMultiple:=False)>
Public Class LogAttribute
    Inherits Attribute

    ''' <summary>
    ''' ログ名（任意）。ログ出力時の識別子として利用可能。
    ''' </summary>
    Public Property Name As String = ""

    ''' <summary>
    ''' 出力するログレベル。
    ''' 既定値は <see cref="LogLevels.Info"/>。
    ''' </summary>
    Public Property Level As LogLevels = LogLevels.Info

    ''' <summary>
    ''' ログメッセージのテンプレート。
    ''' プレースホルダを含めることで動的メッセージ生成が可能。
    ''' </summary>
    Public Property Template As String = ""

    ''' <summary>
    ''' このログに紐づけるエラーコード。
    ''' 例外分類と組み合わせて利用可能。
    ''' </summary>
    Public Property ErrorCode As String = ""

    ''' <summary>
    ''' ログの出力対象（UI、操作ログ、システムログなど）。
    ''' Enum により明示的に指定する。
    ''' </summary>
    Public Property Target As LogTargets

    ''' <summary>
    ''' 許可するイベント名のフィルタ。
    ''' 指定されたイベントのみログ対象とする。
    ''' </summary>
    Public Property AllowEvents As String()

    ''' <summary>
    ''' 許可する Control.Event のフィルタ。
    ''' ControlName + EventName の組み合わせで制御する用途。
    ''' </summary>
    Public Property AllowControlEvents As String()

    ''' <summary>
    ''' ログ対象のイベント名（任意）。
    ''' </summary>
    Public Property EvemtName As String = ""

    ''' <summary>
    ''' ログ対象のコントロール名（任意）。
    ''' </summary>
    Public Property ControlName As String = ""

    ''' <summary>
    ''' ログ対象のフォーム名（任意）。
    ''' </summary>
    Public Property FormName As String = ""

    ''' <summary>
    ''' メソッド実行時間を計測してログに含めるかどうか。
    ''' </summary>
    Public Property MeasureDuration As Boolean = False

    ''' <summary>
    ''' 既定のコンストラクタ。
    ''' </summary>
    Public Sub New()
    End Sub

    ''' <summary>
    ''' この属性インスタンスのディープコピーを作成する。
    ''' AllowEvents / AllowControlEvents も配列ごと複製される。
    ''' </summary>
    ''' <returns>複製された <see cref="LogAttribute"/> インスタンス。</returns>
    Public Function Clone() As LogAttribute
        Dim c As New LogAttribute()

        c.Name = Me.Name
        c.Level = Me.Level
        c.Template = Me.Template
        c.ErrorCode = Me.ErrorCode

        c.Target = Me.Target

        c.ControlName = Me.ControlName
        c.EvemtName = Me.EvemtName
        c.FormName = Me.FormName
        c.MeasureDuration = Me.MeasureDuration

        If Me.AllowEvents IsNot Nothing Then
            c.AllowEvents = CType(Me.AllowEvents.Clone(), String())
        End If

        ' AllowControlEvents のコピー（追加済み）
        If Me.AllowControlEvents IsNot Nothing Then
            c.AllowControlEvents = CType(Me.AllowControlEvents.Clone(), String())
        End If

        Return c
    End Function
End Class


''' <summary>
''' ログ対象から強制的に除外するための属性。
''' </summary>
''' <remarks>
''' LogAttribute よりも優先される「強制除外」指定。
''' 特定メソッドをログ対象から外したい場合に使用する。
''' </remarks>
<AttributeUsage(AttributeTargets.Method)>
Public Class LogExcludeAttribute
    Inherits Attribute
End Class


''' <summary>
''' クラス単位でログのデフォルト設定を与えるための属性。
''' </summary>
''' <remarks>
''' フォーム全体で許可する Control.Event をまとめて指定可能。
''' メソッド単位の LogAttribute が存在する場合はそちらが優先される。
''' </remarks>
<AttributeUsage(AttributeTargets.Class, AllowMultiple:=True)>
Public Class LogDefaultsAttribute
    Inherits Attribute

    ''' <summary>
    ''' クラス全体で許可する Control.Event の一覧。
    ''' </summary>
    Public Property AllowControlEvents As String() = Nothing

    ''' <summary>
    ''' 許可する Control.Event を指定して初期化する。
    ''' </summary>
    ''' <param name="allowEvents">許可するイベント名の配列。</param>
    Public Sub New(ParamArray allowEvents As String())
        Me.AllowControlEvents = allowEvents
    End Sub
End Class


''' <summary>
''' メソッドにログプリセット名を指定するための属性。
''' </summary>
''' <remarks>
''' プリセットは外部定義（設定ファイル・辞書など）で管理される。
''' メソッド毎にプリセットを適用することでログ設定を共通化できる。
''' </remarks>
<AttributeUsage(AttributeTargets.Method)>
Public Class LogPresetUseAttribute
    Inherits Attribute

    ''' <summary>
    ''' 使用するログプリセット名。
    ''' </summary>
    Public Property PresetName As String

    ''' <summary>
    ''' プリセット名を指定して初期化する。
    ''' </summary>
    ''' <param name="name">適用するプリセット名。</param>
    Public Sub New(name As String)
        Me.PresetName = name
    End Sub
End Class