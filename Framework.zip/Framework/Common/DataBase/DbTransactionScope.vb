﻿Imports System.Data.SqlClient

Public Class DbTransactionScope
    Implements IDisposable

    ''' <summary>
    ''' コネクションオブジェクト
    ''' </summary>
    Private _connection As SqlConnection

    ''' <summary>
    ''' トランザクションオブジェクト
    ''' </summary>
    Private _transaction As SqlTransaction

    ''' <summary>
    ''' DB接続文字列
    ''' </summary>
    ''' <returns></returns>
    Protected Property ConnectString As String = SqlDataBaseUtil.GetConnectionString()

    ''' <summary>
    ''' コミットフラグ
    ''' </summary>
    Private _completed As Boolean = False

    ''' <summary>
    ''' コネクションオブジェクト
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property Connection As SqlConnection
        Get
            Return _connection
        End Get
    End Property

    ''' <summary>
    ''' トランザクションオブジェクト
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property Transaction As SqlTransaction
        Get
            Return _transaction
        End Get
    End Property

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        _connection = New SqlConnection(ConnectString)
        _connection.Open()
        BeginTransaction()
    End Sub

    ''' <summary>
    ''' トランザクション開始
    ''' </summary>
    Private Sub BeginTransaction()
        If (_transaction Is Nothing) Then
            _transaction = _connection.BeginTransaction()
        End If
    End Sub

    ''' <summary>
    ''' トランザクション確定
    ''' </summary>
    Public Sub CommitTransaction()
        _transaction.Commit()
        _completed = True
    End Sub

    ''' <summary>
    ''' トランザクション破棄
    ''' </summary>
    Public Sub RollbackTransaction()
        _transaction.Rollback()
    End Sub

    ''' <summary>
    ''' メモリ解放
    ''' </summary>
    Public Sub Dispose() Implements IDisposable.Dispose
        If Not _completed Then
            Try
                RollbackTransaction()
            Catch ex As Exception

            End Try
        End If

        If Not _connection.State = ConnectionState.Closed Then
            _connection.Close()
        End If

        If (_transaction IsNot Nothing) Then
            _transaction.Dispose()
        End If

        If (_connection IsNot Nothing) Then
            _connection.Dispose()
        End If

        _connection = Nothing
        _transaction = Nothing
    End Sub

End Class
