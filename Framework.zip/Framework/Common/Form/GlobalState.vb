﻿
''' <summary>
''' アプリモード
''' </summary>
Public Enum UserPermission
	None
	Write
	[ReadOnly]
	Admin
	Develop
End Enum

''' <summary>
''' APPグルーバル情報
''' </summary>
Public NotInheritable Class GlobalState

	Public Const GS_APP_MODE As String = "AppMode"
	Public Const GS_APP_NAME As String = "ApplicationName"
	Public Const GS_PC_NAME As String = "CurrentPcName"
	Public Const GS_USER_NAME As String = "CurrentUserName"
	Public Const GS_LOCK_STATE As String = "LockStatus"
	Public Const GS_STATUS As String = "CurrentStatus"
	Public Const GS_YEAR_MONTH As String = "TargetYearMonth"
	Public Const GS_SQL_LOG As String = "SqlLogOutputMode"
	Public Const GS_OPE_LOG As String = "OperationLogOutputMode"
	Public Const GS_DBG_DATE As String = "DebugSystemDate"


	' シングルトンインスタンス
	Private Shared ReadOnly _instance As New GlobalState
	Public Shared ReadOnly Property Instance As GlobalState
		Get
			Return _instance
		End Get
	End Property

	''' <summary>
	''' スレッドセーフな読み書きを保証するための排他ロックオブジェクト。
	''' </summary>
	Private ReadOnly _lock As New Object()

	''' <summary>
	''' グローバル状態の値が変更された際に発生するイベント。
	''' </summary>
	''' <param name="key">変更されたプロパティ名</param>
	''' <param name="newValue">変更後の値</param>
	Public Delegate Sub StateChangedEventHandler(ByVal key As String, ByVal newValue As Object)

	''' <summary>
	''' 状態変更イベント。プロパティの値が変わったときに発火する。
	''' </summary>
	Public Event StateChanged As StateChangedEventHandler

	''' <summary>
	''' 外部からのインスタンス化を禁止するためのプライベートコンストラクタ。
	''' </summary>
	Private Sub New()
	End Sub


	''' <summary>
	''' アプリケーションの動作モード（Debug / Release）。
	''' </summary>
	Private _appMode As String
	Public Property AppMode As String
		Get
			SyncLock _lock
				Return _appMode
			End SyncLock
		End Get
		Set(value As String)
			Dim changed As Boolean = False
			SyncLock _lock
				If _appMode <> value Then
					_appMode = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_APP_MODE, value)
			End If
		End Set
	End Property

	''' <summary>
	''' アプリケーション名。
	''' </summary>
	Private _applicationName As String = "出講料計算"
	Public Property ApplicationName As String
		Get
			SyncLock _lock
				Return _applicationName
			End SyncLock
		End Get
		Set(value As String)
			Dim changed As Boolean = False
			SyncLock _lock
				If _applicationName <> value Then
					_applicationName = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_APP_NAME, value)
			End If
		End Set
	End Property

	''' <summary>
	''' 現在の PC 名（端末名）。
	''' </summary>
	Private _currentPcName As String = Environment.MachineName
	Public Property CurrentPcName As String
		Get
			SyncLock _lock
				Return _currentPcName
			End SyncLock
		End Get
		Set(value As String)
			Dim changed As Boolean = False
			SyncLock _lock
				If _currentPcName <> value Then
					_currentPcName = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_PC_NAME, value)
			End If
		End Set
	End Property

	''' <summary>
	''' 現在ログインしているユーザー名。
	''' </summary>
	Private _currentUserName As String = Environment.UserName
	Public Property CurrentUserName As String
		Get
			SyncLock _lock
				Return _currentUserName
			End SyncLock
		End Get
		Set(value As String)
			Dim changed As Boolean = False
			SyncLock _lock
				If _currentUserName <> value Then
					_currentUserName = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_USER_NAME, value)
			End If
		End Set
	End Property

	''' <summary>
	''' 年月度ロック状況。
	''' </summary>
	Private _lockStatus As Boolean = False
	Public Property LockStatus As Boolean
		Get
			SyncLock _lock
				Return _lockStatus
			End SyncLock
		End Get
		Set(value As Boolean)
			Dim changed As Boolean = False
			SyncLock _lock
				If _lockStatus <> value Then
					_lockStatus = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_LOCK_STATE, value)
			End If
		End Set
	End Property

	''' <summary>
	''' 状態。
	''' </summary>
	Private _currentStatus As String = ""
	Public Property CurrentStatus As String
		Get
			SyncLock _lock
				Return _currentStatus
			End SyncLock
		End Get
		Set(value As String)
			Dim changed As Boolean = False
			SyncLock _lock
				If _currentStatus <> value Then
					_currentStatus = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_STATUS, value)
			End If
		End Set
	End Property

	''' <summary>
	''' 現在の対象年月度。
	''' </summary>
	Private _targetYearMonth As Date
	Public Property TargetYearMonth As Date
		Get
			SyncLock _lock
				Return _targetYearMonth
			End SyncLock
		End Get
		Set(value As Date)
			Dim changed As Boolean = False
			SyncLock _lock
				If _targetYearMonth <> value Then
					_targetYearMonth = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_YEAR_MONTH, value)
			End If
		End Set
	End Property

	''' <summary>
	''' SQL ログ出力の有効／無効設定。
	''' </summary>
	Private _sqlLogOutputMode As Boolean = False
	Public Property SqlLogOutputMode As Boolean
		Get
			SyncLock _lock
				Return _sqlLogOutputMode
			End SyncLock
		End Get
		Set(value As Boolean)
			Dim changed As Boolean = False
			SyncLock _lock
				If _sqlLogOutputMode <> value Then
					_sqlLogOutputMode = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_SQL_LOG, value)
			End If
		End Set
	End Property

	''' <summary>
	''' 操作ログ出力の有効／無効設定。
	''' </summary>
	Private _operationLogOutputMode As Boolean = False
	Public Property OperationLogOutputMode As Boolean
		Get
			SyncLock _lock
				Return _operationLogOutputMode
			End SyncLock
		End Get
		Set(value As Boolean)
			Dim changed As Boolean = False
			SyncLock _lock
				If _operationLogOutputMode <> value Then
					_operationLogOutputMode = value
					changed = True
				End If
			End SyncLock
			If changed Then
				RaiseEvent StateChanged(GS_OPE_LOG, value)
			End If
		End Set
	End Property

	''' <summary>
	''' デバッグ用システム日付。
	''' </summary>
	Private _debugSystemDate As Date
	Public Property DebugSystemDate As Date
		Get
			SyncLock _lock
				Return _DebugSystemDate
			End SyncLock
		End Get
		Set(value As Date)
			'Dim changed As Boolean = False
			SyncLock _lock
				If _DebugSystemDate <> value Then
					_DebugSystemDate = value
					'changed = True
				End If
			End SyncLock
			'If changed Then
			'	RaiseEvent StateChanged(GS_DBG_DATE, value)
			'End If
		End Set
	End Property

	''' <summary>
	''' デバッグ用システム日付。
	''' </summary>
	Private _SystemDate As Date
	Public Property SystemDate As Date
		Get
			SyncLock _lock

#If DEBUG Then
				Return AppState.DebugSystemDate
#Else
				Return Now()
#End If

			End SyncLock
		End Get
		Set(value As Date)
			'Dim changed As Boolean = False
			SyncLock _lock
				If _SystemDate <> value Then
					_SystemDate = value
					'changed = True
				End If
			End SyncLock
			'If changed Then
			'	RaiseEvent StateChanged(GS_DBG_DATE, value)
			'End If
		End Set
	End Property

End Class
