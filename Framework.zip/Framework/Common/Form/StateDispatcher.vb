﻿Imports System.Threading

''' <summary>
''' GlobalState の StateChanged イベントを UI スレッドにマーシャリングするためのクラス。
''' </summary>
''' <remarks>
''' ・UI スレッドの SynchronizationContext を保持し、
'''   GlobalState のイベントを UI スレッドで発火させる。
''' ・FW3.5 互換のため、ラムダ式ではなくメソッドを使用している。
''' ・GlobalState 自体は UI を知らない純粋な状態管理クラスのまま維持できる。
''' </remarks>
Public NotInheritable Class StateDispatcher

	'---------------------------------------------
	' ▼ UI スレッドの SynchronizationContext
	'---------------------------------------------

	''' <summary>
	''' UI スレッドの SynchronizationContext。
	''' </summary>
	Private Shared _uiContext As SynchronizationContext

	'---------------------------------------------
	' ▼ UI スレッドで発火するイベント
	'---------------------------------------------

	''' <summary>
	''' UI スレッドで発火される StateChanged イベント。
	''' </summary>
	Public Shared Event UiStateChanged(ByVal key As String, ByVal newValue As Object)

	'---------------------------------------------
	' ▼ 初期化
	'---------------------------------------------

	''' <summary>
	''' UI スレッドの SynchronizationContext を登録する。
	''' 通常はアプリ起動時（メインフォームのロード時など）に呼び出す。
	''' </summary>
	Public Shared Sub InitializeForUIThread()
		_uiContext = SynchronizationContext.Current
	End Sub

	''' <summary>
	''' GlobalState の StateChanged を購読し、
	''' UI スレッドにマーシャリングして UiStateChanged を発火させる。
	''' </summary>
	Public Shared Sub Attach()
		AddHandler GlobalState.Instance.StateChanged, AddressOf OnStateChanged
	End Sub

	'---------------------------------------------
	' ▼ GlobalState → StateDispatcher の入口
	'---------------------------------------------

	''' <summary>
	''' GlobalState の StateChanged イベントを受け取り、
	''' 必要に応じて UI スレッドにマーシャリングする。
	''' </summary>
	''' <param name="key">変更されたプロパティ名</param>
	''' <param name="newValue">変更後の値</param>
	Private Shared Sub OnStateChanged(ByVal key As String, ByVal newValue As Object)

		' UI スレッドが未登録ならそのまま発火
		If _uiContext Is Nothing Then
			RaiseEvent UiStateChanged(key, newValue)
			Return
		End If

		' UI スレッドにマーシャリング
		Dim args As New UiStateChangedArgs(key, newValue)
		_uiContext.Post(AddressOf UiStateChangedCallback, args)

	End Sub

	'---------------------------------------------
	' ▼ UI スレッドで実行されるコールバック
	'---------------------------------------------

	''' <summary>
	''' UI スレッドで実行されるコールバックメソッド。
	''' </summary>
	''' <param name="state">UiStateChangedArgs オブジェクト</param>
	Private Shared Sub UiStateChangedCallback(ByVal state As Object)
		Dim args As UiStateChangedArgs = DirectCast(state, UiStateChangedArgs)
		RaiseEvent UiStateChanged(args.Key, args.Value)
	End Sub

	'---------------------------------------------
	' ▼ UI スレッドに渡すための引数クラス
	'---------------------------------------------

	''' <summary>
	''' UI スレッドに渡す StateChanged の引数を保持するクラス。
	''' </summary>
	Private NotInheritable Class UiStateChangedArgs

		''' <summary>変更されたプロパティ名</summary>
		Public ReadOnly Key As String

		''' <summary>変更後の値</summary>
		Public ReadOnly Value As Object

		''' <summary>
		''' 引数を初期化する。
		''' </summary>
		Public Sub New(ByVal key As String, ByVal value As Object)
			Me.Key = key
			Me.Value = value
		End Sub

	End Class

End Class