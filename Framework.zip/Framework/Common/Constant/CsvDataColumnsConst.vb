﻿
''' <summary>
''' 打刻データ
''' </summary>
Public Enum CsvColumnStamp
  日付
  姓
  名
  姓名
  スタッフコード
  出勤時刻
  退勤時刻
  出勤実時刻
  退勤実時刻
  打刻回数
  打刻修正数
End Enum

''' <summary>
''' 出講予定データ
''' </summary>
Public Enum CsvColumnPlan
  日付
  曜日
  コマ
  教室
  クラス
  科目
  担当
  出講名
  テキスト回
End Enum

''' <summary>
''' 業務依頼データ
''' </summary>
Public Enum CsvColumnRequest
  教室
  科目
  講師名
  日付
  業務名
  開始
  終了
  対象
  内容
  コード
  区分
  実時間
  単価＠
  乗数
  みなし回数
  金額
  担当者
  リーダー
  教務室
End Enum

''' <summary>
''' 打刻外業務依頼データ
''' </summary>
Public Enum CsvColumnRequestNoPunch
    講師コード
    勤務日
    業務名
    教室コード
    開始時間
    終了時間
    備考
    交通費支給対象
End Enum

Public Enum CsvColumnPinchActual
  日付
  曜日
  コマ
  教室
  クラス
  講師コード
  出講名
  科目
  テキスト回
  ピンチ区分
  入力日
End Enum


''' <summary>
''' 時間パターンCSV
''' </summary>
Public Enum CsvColumnTimePattern
  年度
  年月日
  曜日
  曜日区分
End Enum

''' <summary>
''' 教室時間割CSV
''' </summary>
Public Enum CsvColumnTimeTableSite
  年
  教室コード
  日程パターン
  コマ
  開始時間
  終了時間
End Enum

''' <summary>
''' 教室時間割CSV
''' </summary>
Public Enum CsvColumnTimeTableClass
  設定区分
  教室コード
  対象期間
  学年
  クラスコード
  コマ
  開始時間
  終了時間
  作成日
  作成者
  更新日
  更新者
End Enum

''' <summary>
''' 講師給与単価CSV
''' </summary>
Public Enum CsvColumnTeacherWage
  講師コード
  適用年月
  授業給コマ単価
  業務給単価
  作成日
  作成者
  更新日
  更新者
End Enum
