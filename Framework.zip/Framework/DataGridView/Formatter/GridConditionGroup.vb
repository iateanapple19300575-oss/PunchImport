﻿Imports System.Windows.Forms

''' <summary>
''' 条件グループの評価方法を表す列挙体。
''' 複数条件を AND または OR でまとめる際に使用する。
''' </summary>
Public Enum ConditionGroupType
	''' <summary>
	''' すべての条件が一致した場合に True となる（AND 条件）。
	''' </summary>
	AndGroup

	''' <summary>
	''' いずれかの条件が一致した場合に True となる（OR 条件）。
	''' </summary>
	OrGroup
End Enum


''' <summary>
''' 複数の <see cref="CellCondition"/> を AND / OR でまとめて評価するためのクラス。
''' 行単位の条件付き書式に使用され、行内の複数セルを対象に複合条件を構築できる。
''' </summary>
Public Class GridConditionGroup

	''' <summary>
	''' 条件グループの評価方法（AND / OR）。
	''' </summary>
	Public Property GroupType As ConditionGroupType

	''' <summary>
	''' 評価対象となるセル条件の一覧。
	''' </summary>
	Public Property Conditions As List(Of CellCondition)

	''' <summary>
	''' グループタイプを指定して新しい条件グループを作成する。
	''' </summary>
	''' <param name="groupType">AND または OR の評価方法。</param>
	Public Sub New(groupType As ConditionGroupType)
		Me.GroupType = groupType
		Me.Conditions = New List(Of CellCondition)()
	End Sub

	''' <summary>
	''' 条件グループに新しいセル条件を追加する。
	''' </summary>
	''' <param name="condition">追加する <see cref="CellCondition"/>。</param>
	Public Sub Add(condition As CellCondition)
		Conditions.Add(condition)
	End Sub

	''' <summary>
	''' 指定された行が、この条件グループに一致するかどうかを判定する。
	''' AND / OR の設定に応じて複数条件を評価する。
	''' </summary>
	''' <param name="row">評価対象の <see cref="DataGridViewRow"/>。</param>
	''' <returns>条件に一致する場合は True、それ以外は False。</returns>
	Public Function IsMatch(row As DataGridViewRow) As Boolean
		' 条件が1つも無い場合は一致しない
		If Conditions Is Nothing OrElse Conditions.Count = 0 Then
			Return False
		End If

		' AND 条件
		If GroupType = ConditionGroupType.AndGroup Then
			For Each c As CellCondition In Conditions
				' 列名が存在しない場合は不一致
				If Not row.DataGridView.Columns.Contains(c.ColumnName) Then
					Return False
				End If

				Dim cellValue As Object = row.Cells(c.ColumnName).Value
				If Not c.IsMatch(cellValue) Then
					Return False
				End If
			Next
			Return True

		Else
			' OR 条件
			For Each c As CellCondition In Conditions
				' 列名が存在しない場合はスキップ（不一致扱い）
				If Not row.DataGridView.Columns.Contains(c.ColumnName) Then
					Continue For
				End If

				Dim cellValue As Object = row.Cells(c.ColumnName).Value
				If c.IsMatch(cellValue) Then
					Return True
				End If
			Next
			Return False
		End If
	End Function

End Class