﻿Imports System.Windows.Forms
Imports System.Drawing

''' <summary>
''' DataGridView に対して条件付き書式（セル単位・行単位）を適用するクラス。
''' 書式ルールを登録し、CellFormatting イベントを通じて動的にスタイルを変更する。
''' </summary>
Public Class GridConditionalFormatter

	''' <summary>
	''' 行単位で適用する条件付き書式ルールの一覧。
	''' </summary>
	Private _rowRules As List(Of GridConditionFormatRule)

	''' <summary>
	''' セル単位で適用する条件付き書式ルールの一覧。
	''' </summary>
	Private _cellRules As List(Of CellFormatRule)

	''' <summary>
	''' 新しいインスタンスを初期化する。
	''' 行ルール・セルルールのリストを生成する。
	''' </summary>
	Public Sub New()
		_rowRules = New List(Of GridConditionFormatRule)()
		_cellRules = New List(Of CellFormatRule)()
	End Sub

	''' <summary>
	''' 行単位の条件付き書式ルールを追加する。
	''' </summary>
	''' <param name="rule">行に対する書式ルール。</param>
	Public Sub AddRowRule(rule As GridConditionFormatRule)
		_rowRules.Add(rule)
	End Sub

	''' <summary>
	''' セル単位の条件付き書式ルールを追加する。
	''' </summary>
	''' <param name="rule">セルに対する書式ルール。</param>
	Public Sub AddCellRule(rule As CellFormatRule)
		_cellRules.Add(rule)
	End Sub

	''' <summary>
	''' 指定した DataGridView に対して条件付き書式を有効化する。
	''' 必要なイベントハンドラを登録する。
	''' </summary>
	''' <param name="grid">対象の DataGridView。</param>
	Public Sub Apply(grid As DataGridView)
		AddHandler grid.CellFormatting, AddressOf OnCellFormatting
		AddHandler grid.CellMouseDown, AddressOf OnCellMouseDown
		AddHandler grid.SelectionChanged, AddressOf OnSelectionChanged
	End Sub

	''' <summary>
	''' セルの描画時に呼び出され、セル単位 → 行単位の順で条件付き書式を適用する。
	''' </summary>
	Private Sub OnCellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs)
		Dim grid As DataGridView = CType(sender, DataGridView)

		' 行外のセルは無視
		If e.RowIndex < 0 OrElse e.RowIndex >= grid.Rows.Count Then
			Return
		End If

		Dim row As DataGridViewRow = grid.Rows(e.RowIndex)
		Dim colName As String = grid.Columns(e.ColumnIndex).Name

		' --- ① セル単位の条件を先に評価 ---
		For Each rule As CellFormatRule In _cellRules
			If rule.ColumnName = colName Then
				Dim cellValue As Object = row.Cells(colName).Value
				If rule.Condition.IsMatch(cellValue) Then
					e.CellStyle.BackColor = rule.BackColor
					e.CellStyle.ForeColor = rule.ForeColor
					e.CellStyle.Font = New Font("游ゴシック", 10)   ' 太字抑制
					Exit Sub   ' セル単位が最優先
				End If
			End If
		Next

		' --- ② 行単位の条件を評価 ---
		For Each rule As GridConditionFormatRule In _rowRules
			If rule.ConditionGroup.IsMatch(row) Then
				e.CellStyle.BackColor = rule.BackColor
				e.CellStyle.ForeColor = rule.ForeColor
				e.CellStyle.Font = New Font("游ゴシック", 10)   ' 太字抑制
				Exit Sub
			End If
		Next

		' デフォルトフォント（太字抑制）
		e.CellStyle.Font = New Font("游ゴシック", 10)
	End Sub

	''' <summary>
	''' セルクリック時に選択状態をクリアする。
	''' 選択ハイライトを無効化したい場合に使用する。
	''' </summary>
	Private Sub OnCellMouseDown(sender As Object, e As DataGridViewCellMouseEventArgs)
		Dim grid As DataGridView = CType(sender, DataGridView)
		grid.ClearSelection()
	End Sub

	''' <summary>
	''' 選択変更時に選択状態をクリアする。
	''' 常に非選択状態を維持したい場合に使用する。
	''' </summary>
	Private Sub OnSelectionChanged(sender As Object, e As EventArgs)
		Dim grid As DataGridView = CType(sender, DataGridView)
		grid.ClearSelection()
	End Sub

End Class