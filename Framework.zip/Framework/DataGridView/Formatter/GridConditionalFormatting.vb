﻿''' <summary>
''' セル値の比較に使用する演算子を表す列挙体。
''' </summary>
Public Enum CompareOperator
    ''' <summary>値が等しい場合に一致とする。</summary>
    Equal

    ''' <summary>値が等しくない場合に一致とする。</summary>
    NotEqual

    ''' <summary>値が比較値より大きい場合に一致とする。</summary>
    Greater

    ''' <summary>値が比較値より小さい場合に一致とする。</summary>
    Less

    ''' <summary>値が比較値以上の場合に一致とする。</summary>
    GreaterOrEqual

    ''' <summary>値が比較値以下の場合に一致とする。</summary>
    LessOrEqual

    ''' <summary>値が比較値を部分的に含む場合に一致とする。</summary>
    Contains
End Enum


''' <summary>
''' 特定列に対するセル値の条件判定を表すクラス。
''' 列名・比較演算子・比較値を保持し、<see cref="IsMatch"/> により一致判定を行う。
''' </summary>
Public Class CellCondition

    ''' <summary>
    ''' 条件を適用する対象列の名前。
    ''' </summary>
    Public Property ColumnName As String

    ''' <summary>
    ''' 使用する比較演算子。
    ''' </summary>
    Public Property OperatorType As CompareOperator

    ''' <summary>
    ''' 比較対象となる値（文字列として保持）。
    ''' 数値比較の場合は <c>Val</c> により数値化される。
    ''' </summary>
    Public Property CompareValue As String

    ''' <summary>
    ''' 列名・演算子・比較値を指定して新しい条件を作成する。
    ''' </summary>
    ''' <param name="columnName">対象列名。</param>
    ''' <param name="op">比較演算子。</param>
    ''' <param name="value">比較値。</param>
    Public Sub New(columnName As String, op As CompareOperator, value As String)
        Me.ColumnName = columnName
        Me.OperatorType = op
        Me.CompareValue = value
    End Sub

    ''' <summary>
    ''' 指定されたセル値がこの条件に一致するかどうかを判定する。
    ''' </summary>
    ''' <param name="cellValue">セルの値。</param>
    ''' <returns>条件に一致する場合は <c>True</c>、それ以外は <c>False</c>。</returns>
    Public Function IsMatch(cellValue As Object) As Boolean
        If cellValue Is Nothing Then Return False

        Dim v As String = cellValue.ToString()

        Select Case OperatorType
            Case CompareOperator.Equal
                Return v = CompareValue

            Case CompareOperator.NotEqual
                Return v <> CompareValue

            Case CompareOperator.Greater
                Return Val(v) > Val(CompareValue)

            Case CompareOperator.Less
                Return Val(v) < Val(CompareValue)

            Case CompareOperator.GreaterOrEqual
                Return Val(v) >= Val(CompareValue)

            Case CompareOperator.LessOrEqual
                Return Val(v) <= Val(CompareValue)

            Case CompareOperator.Contains
                Return v.IndexOf(CompareValue) >= 0
        End Select

        Return False
    End Function

End Class