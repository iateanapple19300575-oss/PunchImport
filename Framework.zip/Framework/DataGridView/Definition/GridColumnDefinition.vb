﻿Imports System.Windows.Forms

''' <summary>
''' DataGridView の列設定を保持するための定義クラス。
''' 必須情報から将来拡張まで、列に関するあらゆるメタデータを集約する。
''' </summary>
Public Class GridColumnDefinition

	' ================================
	' 必須プロパティ
	' ================================

	''' <summary>
	''' 列の内部名。DataGridViewColumn.Name として使用される。
	''' </summary>
	Public Property Name As String

	''' <summary>
	''' 列ヘッダに表示する文字列。
	''' </summary>
	Public Property HeaderText As String

	''' <summary>
	''' 列幅（ピクセル単位）。
	''' </summary>
	Public Property Width As Integer

	''' <summary>
	''' セルの文字配置（アライメント）。
	''' </summary>
	Public Property Alignment As DataGridViewContentAlignment

  ''' <summary>
  ''' ヘッダーの文字配置（アライメント）。
  ''' </summary>
  Public Property HeaderAlignment As DataGridViewContentAlignment

  ''' <summary>
  ''' データバインド時に使用するプロパティ名。
  ''' </summary>
  Public Property DataPropertyName As String


	' ================================
	' 将来増える可能性のあるプロパティ
	' ================================

	''' <summary>
	''' 列を表示するかどうか。False の場合は非表示。
	''' </summary>
	Public Property Visible As Boolean = True

	''' <summary>
	''' セルを読み取り専用にするかどうか。
	''' </summary>
	Public Property CellReadOnly As Boolean = False

	''' <summary>
	''' セルの表示フォーマット（例: "N2", "yyyy/MM/dd"）。
	''' </summary>
	Public Property Format As String = Nothing

	''' <summary>
	''' 列のソートモード。デフォルトは NotSortable。
	''' </summary>
	Public Property SortMode As DataGridViewColumnSortMode = DataGridViewColumnSortMode.NotSortable

	''' <summary>
	''' セルに入力できる最大文字数。-1 の場合は制限なし。
	''' </summary>
	Public Property MaxInputLength As Integer = -1

	''' <summary>
	''' セルに表示するツールチップ文字列。
	''' </summary>
	Public Property ToolTipText As String = Nothing


	' ================================
	' さらに増えても OK（拡張用コメント）
	' ================================
	' Public Property BackColor As Color
	' Public Property ForeColor As Color
	' Public Property WrapMode As DataGridViewTriState
	' Public Property Frozen As Boolean
	' Public Property MinimumWidth As Integer
	' ...などなど

End Class