﻿Imports System.Windows.Forms

''' <summary>
''' <see cref="GridColumnDefinition"/> から実際の <see cref="DataGridViewColumn"/> を生成するためのファクトリクラス。
''' UI コントロールへの依存をこのクラスに集約し、定義クラスとの責務分離を実現する。
''' </summary>
Public Class GridColumnFactory

	''' <summary>
	''' 指定された列定義 (<see cref="GridColumnDefinition"/>) を基に
	''' <see cref="DataGridViewTextBoxColumn"/> を生成して返す。
	''' </summary>
	''' <param name="def">列のメタデータを保持する <see cref="GridColumnDefinition"/>。</param>
	''' <returns>構築された <see cref="DataGridViewColumn"/>。</returns>
	Public Shared Function Create(def As GridColumnDefinition) As DataGridViewColumn
		Dim col As New DataGridViewTextBoxColumn()

		' 基本プロパティの適用
		col.Name = def.Name
		col.HeaderText = def.HeaderText
		col.Width = def.Width
		col.DataPropertyName = def.DataPropertyName
		col.Visible = def.Visible
		col.ReadOnly = def.CellReadOnly
		col.SortMode = def.SortMode

		' セルスタイルの適用（アライメント）
		col.DefaultCellStyle = New DataGridViewCellStyle() With {
			.Alignment = def.Alignment
		}

    ' フォーマット指定
    If def.Format IsNot Nothing Then
			col.DefaultCellStyle.Format = def.Format
		End If

		' ツールチップ
		If def.ToolTipText IsNot Nothing Then
			col.ToolTipText = def.ToolTipText
		End If

		' 最大入力長
		If def.MaxInputLength > 0 Then
			col.MaxInputLength = def.MaxInputLength
		End If

		Return col
	End Function

End Class