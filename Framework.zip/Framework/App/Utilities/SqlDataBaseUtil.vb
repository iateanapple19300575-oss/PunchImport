﻿Public Class SqlDataBaseUtil

    Public Shared Function GetConnectionString() As String

        ' 旧開発環境(GH2000_DEV)
        'Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=GH2000_DEV;Integrated Security=True;"

        ' 開発環境(LECTPAY)
        'Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=LECTPAY;User ID=LECTUSER;Password=ntsLect0302_dev"

        ' 本番環境(LECTPAY)
        Return "Data Source=NTSSQLIR0.site.int.nichinoken.net;Initial Catalog=LECTPAY;User ID=LECTUSER;Password=ntsLect0311"


        'TODO:要注意ビルド注意
        '後日、#If...Thenディレクティブ
        '#If NTS_DEBUG Then
        '		'Return "Server=NTSSQLDE2.site.int.nichinoken.net;UID=GHMente;PWD=GHMente2008;DATABASE=GH2000_DEV;APP=XXTEST01"
        '		Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=GH2000_DEV;Integrated Security=True;"
        '#Else
        '    Return "Server=NTSSQLDE2.site.int.nichinoken.net;UID=GHMente;PWD=GHMente2008;DATABASE=GH2000;APP=XXTEST01"
        '#End If

    End Function


#If 0 Then
    Public Shared Function GetViewConnectionString() As String

        Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=LECTPAY;Integrated Security=True;"
        'TODO:要注意ビルド注意
        '#If NTS_DEBUG Then
        '		Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=LECTPAY;Integrated Security=True;"
        '#End If

    End Function
#End If
End Class
