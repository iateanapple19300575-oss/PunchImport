﻿Namespace Framework
  Public NotInheritable Class QueryBuilder


    Private Sub New()
    End Sub

    Public Shared Function BuildSelect(def As TableDefinition) As String
      Return "SELECT " & String.Join(", ", def.Columns.ToArray()) &
             " FROM " & def.TableName
    End Function

    Public Shared Function BuildInsert(def As TableDefinition) As String
      'Dim historyColumns() As String = {"Create_Date", "Create_User", "Update_Date", "Update_User"}
      'Dim colArray() As String = def.Columns.ToArray()
      'Dim mergedColumns(def.Columns.ToArray().Length + historyColumns.Length - 1) As String

      'Array.Copy(def.Columns.ToArray(), mergedColumns, def.Columns.ToArray().Length)
      'Array.Copy(historyColumns, 0, mergedColumns, def.Columns.ToArray().Length, historyColumns.Length)

      'Dim colList As String = String.Join(", ", mergedColumns)
      'Dim paramList As String = "@" & String.Join(", @", mergedColumns)

      Dim colList As String = String.Join(", ", def.Columns.ToArray())
      Dim paramList As String = "@" & String.Join(", @", def.Columns.ToArray())

      Return "INSERT INTO " & def.TableName &
             " (" & colList & ") VALUES (" & paramList & ")"
    End Function

    Public Shared Function BuildUpdate(def As TableDefinition) As String
      Dim setList As New List(Of String)

      For Each col In def.Columns
        If Not def.KeyColumns.Contains(col) Then
          setList.Add(col & "=@" & col)
        End If
      Next

      Dim whereList As New List(Of String)
      For Each key In def.KeyColumns
        whereList.Add(key & "=@" & key)
      Next
      whereList.Add("Update_Date" & "=@" & "Update_Date")
      whereList.Add("Update_User" & "=@" & "Update_User")

      Return "UPDATE " & def.TableName &
             " SET " & String.Join(", ", setList.ToArray()) &
             " WHERE " & String.Join(" AND ", whereList.ToArray())
    End Function

    Public Shared Function BuildDelete(def As TableDefinition) As String
      Dim whereList As New List(Of String)

      For Each key In def.KeyColumns
        whereList.Add(key & "=@" & key)
      Next

      Return "DELETE FROM " & def.TableName &
             " WHERE " & String.Join(" AND ", whereList.ToArray())
    End Function

  End Class
End Namespace
