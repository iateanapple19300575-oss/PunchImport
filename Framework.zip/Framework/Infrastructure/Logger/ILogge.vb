﻿''' <summary>
''' ロガーの基本インターフェースです。
''' </summary>
Public Interface ILogger
    Sub Debug(message As String)
    Sub Info(message As String)
    Sub Warn(message As String)
    Sub [Error](message As String, ex As Exception)
End Interface

''' <summary>
''' ログ出力の設定を保持します。
''' </summary>
Public Class LoggerConfig
    ''' <summary>出力する最小ログレベル。</summary>
    Public Property MinimumLevel As LogLevel
    ''' <summary>ログを書き込むファイルパス。</summary>
    Public Property FilePath As String
End Class

