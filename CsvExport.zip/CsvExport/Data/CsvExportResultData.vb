﻿''' <summary>
''' 処理結果情報クラス
''' </summary>
Public Class CsvResultData(Of T)
	Inherits ResultInfoData

	''' <summary>
	''' 返却データ：List型
	''' </summary>
	''' <returns></returns>
	Public Property CsvDataList As New List(Of T)

End Class
