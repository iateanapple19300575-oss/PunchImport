﻿Public Class SyainData

  ''' <summary>
  ''' 社員番号
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM1"), CsvOrderAttrbute(1)>
  Public Property MM1 As String

  ''' <summary>
  ''' カナ氏名
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM2"), CsvOrderAttrbute(2)>
  Public Property MM2 As String

  ''' <summary>
  '''氏名
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM3"), CsvOrderAttrbute(3)>
  Public Property MM3 As String

  ''' <summary>
  ''' 部門コード
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM4"), CsvOrderAttrbute(4)>
  Public Property MM4 As String

  ''' <summary>
  ''' 性別
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM6"), CsvOrderAttrbute(5)>
  Public Property MM6 As String

  ''' <summary>
  ''' 生年月日
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM7"), CsvOrderAttrbute(6)>
  Public Property MM7 As String

  ''' <summary>
  ''' 入社年月日
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM8"), CsvOrderAttrbute(7)>
  Public Property MM8 As String

  ''' <summary>
  ''' 退職年月日
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM9"), CsvOrderAttrbute(8)>
  Public Property MM9 As String

  ''' <summary>
  ''' 郵便番号
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM10"), CsvOrderAttrbute(9)>
  Public Property MM10 As String

  ''' <summary>
  ''' 住所１
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM11"), CsvOrderAttrbute(10)>
  Public Property MM11 As String

  ''' <summary>
  ''' 住所２
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM12"), CsvOrderAttrbute(11)>
  Public Property MM12 As String

  ''' <summary>
  ''' 電話番号
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM13"), CsvOrderAttrbute(12)>
  Public Property MM13 As String

  ''' <summary>
  ''' 課税区分
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MS1"), CsvOrderAttrbute(13)>
  Public Property MS1 As String

End Class
