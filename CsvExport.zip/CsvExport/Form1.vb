﻿Imports System.Text
Imports Freamwork.Common.Helper

Public Class Form1
  Private Sub btn入力03_Click(sender As Object, e As EventArgs) Handles btn入力03.Click
    '交通費件数確認

    MouseCursor.WaitCursor(Me)

    Dim tran As New CsvExportTran
    Dim result As New ResultData

    Try
      result = tran.SelectData("2024", "01")

    Catch ex As Exception
      result.Success = False

    Finally
      MouseCursor.DefaultCursor(Me)
      If Not result.Success Then
        MessageBox.Show(Me, MessageIdConst.MSGID_E2008)
      Else
        If result.DataCount > 0 Then
          MessageBox.Show(Me, result.DataCount & "件あります。")
        Else
          MessageBox.Show(Me, "格納されていません。")
        End If
      End If
    End Try

  End Sub

  ''' <summary>
  ''' 給与奉行用CSV作成（給与データ）
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub btnProc10_Click(sender As Object, e As EventArgs) Handles btnProc10.Click

    Dim csvOption As New CsvExportOptions With {
      .Encoding = Encoding.GetEncoding("Shift_JIS"),
      .WithBom = False,
      .IncludeHeader = True,
      .Demiliter = ",",
      .QuoteChar = """",
      .QuoteEmpty = True,
      .QuoteStringOnly = True,
      .QuoteDateTime = True,
      .QuoteNumeric = False,
      .NewLine = vbCrLf,
      .AppendMode = False
    }


    Dim tran As New CsvExportTran
    Dim result As New CsvResultData(Of KyuyoData)
    Dim csvData As New List(Of KyuyoData)

    Try
      result = tran.SelectKyuyoData()
      If result.Success Then
        CsvExporter.ExportToCsv(Of KyuyoData)(result.CsvDataList, "Kyuyo.CSV", csvOption)
      End If

    Catch ex As Exception
      result.Success = False

    Finally
      MouseCursor.DefaultCursor(Me)

      MessageBox.Show(Me, "奉行用CSV給与データ作成が終了しました")
    End Try

  End Sub

  ''' <summary>
  ''' 給与奉行用CSV作成（社員データ）
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub btnProc11_Click(sender As Object, e As EventArgs) Handles btnProc11.Click

    Dim csvOption As New CsvExportOptions With {
      .Encoding = Encoding.GetEncoding("Shift_JIS"),
      .WithBom = False,
      .IncludeHeader = True,
      .Demiliter = ",",
      .QuoteChar = """",
      .QuoteEmpty = True,
      .QuoteStringOnly = True,
      .QuoteDateTime = True,
      .QuoteNumeric = False,
      .NewLine = vbCrLf,
      .AppendMode = False
    }


    Dim tran As New CsvExportTran
    Dim result As New CsvResultData(Of SyainData)
    Dim csvData As New List(Of SyainData)

    Try
      result = tran.SelectSyainData()
      If result.Success Then
        CsvExporter.ExportToCsv(Of SyainData)(result.CsvDataList, "Syain.CSV", csvOption)
      End If

    Catch ex As Exception
      result.Success = False

    Finally
      MouseCursor.DefaultCursor(Me)

      MessageBox.Show(Me, "奉行用CSV社員データ作成が終了しました")
    End Try


  End Sub
End Class
