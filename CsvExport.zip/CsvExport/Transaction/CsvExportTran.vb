﻿Imports System.Data.SqlClient

''' <summary>
''' [システム環境設定データ]トランザクション
''' </summary>
Public Class CsvExportTran
	Inherits TranBase

	''' <summary>
	''' システム環境設定データを取得する。
	''' </summary>
	''' <returns></returns>
	Public Function SelectData(ByVal year As String, ByVal month As String) As ResultData
		Dim resultData As New ResultData
		Dim recData As New SystemEnvData
		Dim dic As New Dictionary(Of String, String)
		Dim sqlString As New System.Text.StringBuilder

		sqlString.Length = 0
		sqlString.Append("SELECT ")
		sqlString.Append("    COUNT(*) AS 件数 ")
		sqlString.Append("FROM ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_PAY_MONTH_CHOUSEI & " ")
		sqlString.Append("WHERE ")
		sqlString.Append("    1 = 1 ")
		sqlString.Append("    AND 年度 = @year ")
		sqlString.Append("    AND 月度 = @month ")
		sqlString.Append("    AND 手当コード = '30' ")
		sqlString.Append("; ")

		Try
			Using sqlConnection As New SqlConnection(ConnectString)
				sqlConnection.Open()

				Dim count As Integer = 0
				Using sqlCommand As New SqlCommand(sqlString.ToString(), sqlConnection)
					sqlCommand.Parameters.AddWithValue("@year", year)
					sqlCommand.Parameters.AddWithValue("@month", month)
					Using reader As SqlDataReader = sqlCommand.ExecuteReader()
						While reader.Read()
							resultData.DataCount = reader.GetValue(0)
							'count += 1
						End While
					End Using
				End Using
				resultData.Success = True
				'resultData.ResDataClass = recData
				'resultData.DataCount = count
			End Using

		Catch ex As SqlException
			resultData.Success = False
			resultData.ErrorCode = ex.Number
			Throw

		Catch ex As Exception
			resultData.Success = False

		Finally

		End Try

		Return resultData
	End Function


	Public Function SelectKyuyoData() As CsvResultData(Of KyuyoData)
		Dim resultData As New CsvResultData(Of KyuyoData)

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("SELECT ")
		sqlString.Append("    a.社員番号 AS MM1 ")
		sqlString.Append("    , a.本科 AS KS2 ")
		sqlString.Append("    , a.単科特別選 AS KS3 ")
		sqlString.Append("    , a.クラス手当 AS KS4 ")
		sqlString.Append("    , a.手当１ AS KS5 ")
		sqlString.Append("    , a.手当２ AS KS6 ")
		sqlString.Append("    , a.調整講師料 AS KS10 ")
		sqlString.Append("    , a.交通費 AS KS11 ")
		sqlString.Append("    , a.調整交通費 AS KS12 ")
		sqlString.Append("    , a.前渡金 AS KK11 ")
		sqlString.Append("FROM ")
		sqlString.Append("    (  ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_PAY_MONTH_BUGYO & " a ")
		sqlString.Append("        RIGHT JOIN YearControl b ")
		sqlString.Append("            ON ( ")
		sqlString.Append("                   a.年度 = b.現年度 ")
		sqlString.Append("               AND a.月度 = b.現月度 ")
		sqlString.Append("            ) ")
		sqlString.Append("    ) ")
		sqlString.Append("    LEFT JOIN " & DBTableConst.TABLE_NAME_PAY_MONTH_BUGYO_OMIT & " c ")
		sqlString.Append("        ON a.講師コード = c.講師コード ")
		sqlString.Append("WHERE ")
		sqlString.Append("    1 = 1 ")
		sqlString.Append("    AND c.講師コード IS NULL ")
		sqlString.Append("ORDER BY ")
		sqlString.Append("    a.社員番号 ")
		sqlString.Append("; ")

		Try
			Using sqlConnection As New SqlConnection(ConnectString)
				sqlConnection.Open()

				Dim csvDataList As New List(Of KyuyoData)
				Dim count As Integer = 0
				Using sqlCommand As New SqlCommand(sqlString.ToString(), sqlConnection)
					Using reader As SqlDataReader = sqlCommand.ExecuteReader()
						While reader.Read()
							Dim recData As New KyuyoData
							recData.MM1 = reader.GetValue(0)
							recData.KS2 = reader.GetValue(1)
							recData.KS3 = reader.GetValue(2)
							recData.KS4 = reader.GetValue(3)
							recData.KS5 = reader.GetValue(4)
							recData.KS6 = reader.GetValue(5)
							recData.KS10 = reader.GetValue(6)
							recData.KS11 = reader.GetValue(7)
							recData.KS12 = reader.GetValue(8)
							recData.KK11 = reader.GetValue(9)
							csvDataList.Add(recData)
							count += 1
						End While
					End Using
				End Using
				resultData.Success = True
				resultData.CsvDataList = csvDataList
				resultData.DataCount = count
			End Using

		Catch ex As SqlException
			resultData.Success = False
			resultData.ErrorCode = ex.Number
			Throw

		Catch ex As Exception
			resultData.Success = False

		Finally

		End Try

		Return resultData
	End Function



	Public Function SelectSyainData() As CsvResultData(Of SyainData)
		Dim resultData As New CsvResultData(Of SyainData)

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("SELECT ")
		sqlString.Append("    a.社員番号 AS MM1 ")
		sqlString.Append("    , b.カナ氏名 AS MM2 ")
		sqlString.Append("    , b.氏名 AS MM3 ")
		sqlString.Append("    , b.部門コード AS MM4 ")
		sqlString.Append("    , b.性別 AS MM6 ")
		sqlString.Append("    , b.生年月日 AS MM7 ")
		sqlString.Append("    , b.入社年月日 AS MM8 ")
		sqlString.Append("    , b.退職年月日 AS MM9 ")
		sqlString.Append("    , b.郵便番号 AS MM10 ")
		sqlString.Append("    , b.住所１ AS MM11 ")
		sqlString.Append("    , b.住所２ AS MM12 ")
		sqlString.Append("    , b.電話番号 AS MM13 ")
		sqlString.Append("    , b.課税区分 AS MS1 ")
		sqlString.Append("FROM ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_PAY_MONTH_SYAIN_TRAN & " a ")
		sqlString.Append("    INNER JOIN " & DBTableConst.TABLE_NAME_PAY_MONTH_SYAIN & " b ")
		sqlString.Append("        ON a.社員番号 = b.社員番号 ")
		sqlString.Append("ORDER BY ")
		sqlString.Append("    a.社員番号 ")
		sqlString.Append("; ")

		Try
			Using sqlConnection As New SqlConnection(ConnectString)
				sqlConnection.Open()

				Dim csvDataList As New List(Of SyainData)
				Dim count As Integer = 0
				Using sqlCommand As New SqlCommand(sqlString.ToString(), sqlConnection)
					Using reader As SqlDataReader = sqlCommand.ExecuteReader()
						While reader.Read()
							Dim recData As New SyainData
							recData.MM1 = SqlDataReaderUtil.GetValue(reader, 0)
							recData.MM2 = SqlDataReaderUtil.GetValue(reader, 1)
							recData.MM3 = SqlDataReaderUtil.GetValue(reader, 2)
							recData.MM4 = SqlDataReaderUtil.GetValue(reader, 3)
							recData.MM6 = SqlDataReaderUtil.GetValue(reader, 4)
							recData.MM7 = SqlDataReaderUtil.GetValue(reader, 5)
							recData.MM8 = SqlDataReaderUtil.GetValue(reader, 6)
							recData.MM9 = SqlDataReaderUtil.GetValue(reader, 7)
							recData.MM10 = SqlDataReaderUtil.GetValue(reader, 8)
							recData.MM11 = SqlDataReaderUtil.GetValue(reader, 9)
							recData.MM12 = SqlDataReaderUtil.GetValue(reader, 10)
							recData.MM13 = SqlDataReaderUtil.GetValue(reader, 11)
							recData.MS1 = SqlDataReaderUtil.GetValue(reader, 12)
							csvDataList.Add(recData)
							count += 1
						End While
					End Using
				End Using
				resultData.Success = True
				resultData.CsvDataList = csvDataList
				resultData.DataCount = count
			End Using

		Catch ex As SqlException
			resultData.Success = False
			resultData.ErrorCode = ex.Number
			Throw

		Catch ex As Exception
			resultData.Success = False

		Finally

		End Try

		Return resultData
	End Function

	Public Function SelectTimePatternData(ByVal targetDate As Date) As CsvResultData(Of TimePatternCsvData)
		Dim resultData As New CsvResultData(Of TimePatternCsvData)

		Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
		Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("SELECT" & " ")
    sqlString.Append("  Year" & " ")
    sqlString.Append("  , CONVERT(CHAR (10), Lecture_Date, 111) As Lecture_Date" & " ")
    sqlString.Append("  , Youbi As Youbi" & " ")
    sqlString.Append("  , Schedule_Pattern As Schedule_Pattern" & " ")
    sqlString.Append("FROM ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_TIME_PATTERN & " ")
		sqlString.Append("WHERE 1=1" & " ")
		If Not DateUtil.IsNullOrEmpty(targetDate) Then
      sqlString.Append("  AND Lecture_Date >= '" & firstDay & "' ")
      sqlString.Append("  AND Lecture_Date <= '" & lastDay & "' ")
    End If
		sqlString.Append("ORDER BY" & " ")
    sqlString.Append("  Lecture_Date ASC" & " ")
    sqlString.Append("; ")

		Try
			Using sqlConnection As New SqlConnection(ConnectString)
				sqlConnection.Open()

				Dim csvDataList As New List(Of TimePatternCsvData)
				Dim count As Integer = 0
				Using sqlCommand As New SqlCommand(sqlString.ToString(), sqlConnection)
					Using reader As SqlDataReader = sqlCommand.ExecuteReader()
						While reader.Read()
							Dim recData As New TimePatternCsvData
							recData.SchoolDay = SqlDataReaderUtil.GetValue(reader, 0)
							recData.DayOfWeek = SqlDataReaderUtil.GetValue(reader, 1)
							recData.PatternName = SqlDataReaderUtil.GetValue(reader, 2)
							csvDataList.Add(recData)
							count += 1
						End While
					End Using
				End Using
				resultData.Success = True
				resultData.CsvDataList = csvDataList
				resultData.DataCount = count
			End Using

		Catch ex As SqlException
			resultData.Success = False
			resultData.ErrorCode = ex.Number
			Throw

		Catch ex As Exception
			resultData.Success = False

		Finally

		End Try

		Return resultData
	End Function

	Public Function SelectTimetableSiteData(ByVal targetDate As Date) As CsvResultData(Of TimetableSiteCsvData)
		Dim resultData As New CsvResultData(Of TimetableSiteCsvData)

		Dim SqlQuery As New System.Text.StringBuilder
		SqlQuery.Length = 0
		SqlQuery.Append("SELECT").Append(" ")
		SqlQuery.Append("    MTS.").Append(M_Timetable_SiteEnum.年.Column).Append(" ")
		SqlQuery.Append("  , MTS.").Append(M_Timetable_SiteEnum.教室コード.Column).Append(" ")
		SqlQuery.Append("  , REPLACE(MAX(NS.").Append(ntb_SiteEnum.教室名.Column).Append("),'　','')").Append(" ")
		SqlQuery.Append("      As ").Append(ntb_SiteEnum.教室名.Column).Append(" ")
		SqlQuery.Append("  , MTS.").Append(M_Timetable_SiteEnum.日程パターン名.Column).Append(" ")

		For i As Integer = 1 To 9
			SqlQuery.Append(", CONVERT(VARCHAR(5), MAX(").Append(M_Timetable_SiteEnum.開始時間.Column).Append("_").Append(i.ToString()).Append("), 108) ")
			SqlQuery.Append("   As ").Append(M_Timetable_SiteEnum.開始時間.Column).Append("_").Append(i.ToString()).Append(" ")
			SqlQuery.Append(", CONVERT(VARCHAR(5), MAX(").Append(M_Timetable_SiteEnum.終了時間.Column).Append("_").Append(i.ToString()).Append("), 108) ")
			SqlQuery.Append("   As ").Append(M_Timetable_SiteEnum.終了時間.Column).Append("_").Append(i.ToString()).Append(" ")
		Next

		SqlQuery.Append("FROM").Append(" ")
		SqlQuery.Append("(").Append(" ")
		SqlQuery.Append("  SELECT").Append(" ")
		SqlQuery.Append("      ").Append(M_Timetable_SiteEnum.年.Column).Append(" ")
		SqlQuery.Append("    , ").Append(M_Timetable_SiteEnum.教室コード.Column).Append(" ")
		SqlQuery.Append("    , ").Append(M_Timetable_SiteEnum.日程パターン名.Column).Append(" ")

		For i As Integer = 1 To 9
			SqlQuery.Append("  , CASE WHEN ").Append(M_Timetable_SiteEnum.コマ.Column).Append(" = '").Append(i.ToString()).Append("' And")
			SqlQuery.Append("              ").Append(M_Timetable_SiteEnum.開始時間.Column).Append(" IS NOT NULL THEN").Append(" ")
			SqlQuery.Append("              ").Append(M_Timetable_SiteEnum.開始時間.Column).Append(" ELSE NULL END")
			SqlQuery.Append("           As ").Append(M_Timetable_SiteEnum.開始時間.Column).Append("_").Append(i.ToString()).Append(" ")
			SqlQuery.Append("  , CASE WHEN ").Append(M_Timetable_SiteEnum.コマ.Column).Append(" = '").Append(i.ToString()).Append("' And")
			SqlQuery.Append("              ").Append(M_Timetable_SiteEnum.終了時間.Column).Append(" IS NOT NULL THEN").Append(" ")
			SqlQuery.Append("              ").Append(M_Timetable_SiteEnum.終了時間.Column).Append(" ELSE NULL END")
			SqlQuery.Append("           As ").Append(M_Timetable_SiteEnum.終了時間.Column).Append("_").Append(i.ToString()).Append(" ")
		Next

		SqlQuery.Append("FROM").Append(" ")
		SqlQuery.Append("  ").Append(M_Timetable_SiteEnum.年.Table).Append(" ")
		SqlQuery.Append("  ").Append(") As MTS").Append(" ")

		SqlQuery.Append("LEFT JOIN ").Append(ntb_SiteEnum.教室コード.Table).Append(" NS").Append(" ")
		SqlQuery.Append("  ON (").Append(" ")
		SqlQuery.Append("      MTS.").Append(M_Timetable_SiteEnum.教室コード.Column).Append(" =").Append(" ")
		SqlQuery.Append("      NS.").Append(ntb_SiteEnum.教室コード.Column).Append(" COLLATE Japanese_CS_AS_KS_WS").Append(" ")
		SqlQuery.Append("    )").Append(" ")

		SqlQuery.Append("WHERE").Append(" ")
		SqlQuery.Append("  1=1").Append(" ")
		SqlQuery.Append("  AND ").Append(M_Timetable_SiteEnum.年.Column).Append(" = ").Append(M_Timetable_SiteEnum.年.Param).Append(" ")

		SqlQuery.Append("GROUP BY").Append(" ")
		SqlQuery.Append("    MTS.").Append(M_Timetable_SiteEnum.年.Column).Append(" ")
		SqlQuery.Append("  , MTS.").Append(M_Timetable_SiteEnum.教室コード.Column).Append(" ")
		SqlQuery.Append("  , MTS.").Append(M_Timetable_SiteEnum.日程パターン名.Column).Append(" ")

		Dim parameters As SqlParameter() = {
				New SqlParameter() With {.ParameterName = M_Timetable_SiteEnum.年.Param, .Value = targetDate.Year.ToString()}
			}

		Try
			Using sqlConnection As New SqlConnection(ConnectString)
				sqlConnection.Open()

				Dim csvDataList As New List(Of TimetableSiteCsvData)
				Dim count As Integer = 0
				Using sqlCommand As New SqlCommand(SqlQuery.ToString(), sqlConnection)
					If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
						sqlCommand.Parameters.AddRange(parameters)
					End If
          Debug.WriteLine(SqlUtil.GetCommandTextWithParameters(sqlCommand))
          Using reader As SqlDataReader = sqlCommand.ExecuteReader()
            While reader.Read()
              Dim recData As New TimetableSiteCsvData
              recData.Year = SqlDataReaderUtil.GetValue(reader, 0)
              recData.SiteCode = SqlDataReaderUtil.GetValue(reader, 1)
              recData.SiteName = SqlDataReaderUtil.GetValue(reader, 2)
              recData.PatternName = SqlDataReaderUtil.GetValue(reader, 3)
              recData.StartTime1 = SqlDataReaderUtil.GetValue(reader, 4)
              recData.EndTime1 = SqlDataReaderUtil.GetValue(reader, 5)
              recData.StartTime2 = SqlDataReaderUtil.GetValue(reader, 6)
              recData.EndTime2 = SqlDataReaderUtil.GetValue(reader, 7)
              recData.StartTime3 = SqlDataReaderUtil.GetValue(reader, 8)
              recData.EndTime3 = SqlDataReaderUtil.GetValue(reader, 9)
              recData.StartTime4 = SqlDataReaderUtil.GetValue(reader, 10)
              recData.EndTime4 = SqlDataReaderUtil.GetValue(reader, 11)
              recData.StartTime5 = SqlDataReaderUtil.GetValue(reader, 12)
              recData.EndTime5 = SqlDataReaderUtil.GetValue(reader, 13)
              recData.StartTime6 = SqlDataReaderUtil.GetValue(reader, 14)
              recData.EndTime6 = SqlDataReaderUtil.GetValue(reader, 15)
              recData.StartTime7 = SqlDataReaderUtil.GetValue(reader, 16)
              recData.EndTime7 = SqlDataReaderUtil.GetValue(reader, 17)
              recData.StartTime8 = SqlDataReaderUtil.GetValue(reader, 18)
              recData.EndTime8 = SqlDataReaderUtil.GetValue(reader, 19)
              recData.StartTime9 = SqlDataReaderUtil.GetValue(reader, 20)
              recData.EndTime9 = SqlDataReaderUtil.GetValue(reader, 21)
              csvDataList.Add(recData)
              count += 1
            End While
          End Using
        End Using
				resultData.Success = True
				resultData.CsvDataList = csvDataList
				resultData.DataCount = count
			End Using

		Catch ex As SqlException
			resultData.Success = False
			resultData.ErrorCode = ex.Number
			Throw

		Catch ex As Exception
			resultData.Success = False

		Finally

		End Try

		Return resultData
	End Function


	Public Function SelectTimetableClassData(ByVal targetDate As Date) As CsvResultData(Of TimetableSiteCsvData)
		Dim SqlQuery As New System.Text.StringBuilder
		SqlQuery.Length = 0
		SqlQuery.Append("SELECT").Append(" ")
		SqlQuery.Append("    MTC.").Append(M_Timetable_ClassEnum.設定区分.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.教室コード.Column).Append(" ")
		SqlQuery.Append("  , REPLACE(MAX(NS.").Append(ntb_SiteEnum.教室名.Column).Append("),'　','')").Append(" ")
		SqlQuery.Append("      As ").Append(ntb_SiteEnum.教室名.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.対象期間.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.学年.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.クラスコード.Column).Append(" ")

		For i As Integer = 1 To 9
			SqlQuery.Append(", CONVERT(VARCHAR(5), MAX(").Append(M_Timetable_ClassEnum.開始時間.Column).Append("_").Append(i.ToString()).Append("), 108) ")
			SqlQuery.Append("   AS ").Append(M_Timetable_ClassEnum.開始時間.Column).Append("_").Append(i.ToString()).Append(" ")
			SqlQuery.Append(", CONVERT(VARCHAR(5), MAX(").Append(M_Timetable_ClassEnum.終了時間.Column).Append("_").Append(i.ToString()).Append("), 108) ")
			SqlQuery.Append("   AS ").Append(M_Timetable_ClassEnum.終了時間.Column).Append("_").Append(i.ToString()).Append(" ")
		Next

		SqlQuery.Append("FROM").Append(" ")
		SqlQuery.Append("(").Append(" ")
		SqlQuery.Append("SELECT").Append(" ")
		SqlQuery.Append("  ").Append(M_Timetable_ClassEnum.設定区分.Column).Append(" ")
		SqlQuery.Append("  , ").Append(M_Timetable_ClassEnum.教室コード.Column).Append(" ")
		SqlQuery.Append("  , CONCAT(").Append(M_Timetable_ClassEnum.教室コード.Column & ",':××教室') As Site_Name").Append(" ")
		SqlQuery.Append("  , ").Append(M_Timetable_ClassEnum.対象期間.Column).Append(" ")
		SqlQuery.Append("  , ").Append(M_Timetable_ClassEnum.学年.Column).Append(" ")
		SqlQuery.Append("  , ").Append(M_Timetable_ClassEnum.クラスコード.Column).Append(" ")
		SqlQuery.Append("  , ").Append(M_Timetable_ClassEnum.コマ.Column).Append(" ")

		For i As Integer = 1 To 9
			SqlQuery.Append("  , CASE WHEN ").Append(M_Timetable_ClassEnum.コマ.Column).Append(" = '").Append(i.ToString()).Append("' And")
			SqlQuery.Append("              ").Append(M_Timetable_ClassEnum.開始時間.Column).Append(" IS NOT NULL THEN").Append(" ")
			SqlQuery.Append("              ").Append(M_Timetable_ClassEnum.開始時間.Column).Append(" ELSE NULL END")
			SqlQuery.Append("           As ").Append(M_Timetable_ClassEnum.開始時間.Column).Append("_").Append(i.ToString()).Append(" ")
			SqlQuery.Append("  , CASE WHEN ").Append(M_Timetable_ClassEnum.コマ.Column).Append(" = '").Append(i.ToString()).Append("' And")
			SqlQuery.Append("              ").Append(M_Timetable_ClassEnum.終了時間.Column).Append(" IS NOT NULL THEN").Append(" ")
			SqlQuery.Append("              ").Append(M_Timetable_ClassEnum.終了時間.Column).Append(" ELSE NULL END")
			SqlQuery.Append("           As ").Append(M_Timetable_ClassEnum.終了時間.Column).Append("_").Append(i.ToString()).Append(" ")
		Next

		SqlQuery.Append("FROM").Append(" ")
		SqlQuery.Append("  ").Append(M_Timetable_ClassEnum.設定区分.Table).Append(" ")
		SqlQuery.Append("  ").Append(") As MTC").Append(" ")

		SqlQuery.Append("LEFT JOIN ").Append(ntb_SiteEnum.教室コード.Table).Append(" NS").Append(" ")
		SqlQuery.Append("  ON (").Append(" ")
		SqlQuery.Append("      MTC.").Append(M_Timetable_SiteEnum.教室コード.Column).Append(" =").Append(" ")
		SqlQuery.Append("      NS.").Append(ntb_SiteEnum.教室コード.Column).Append(" COLLATE Japanese_CS_AS_KS_WS").Append(" ")
		SqlQuery.Append("    )").Append(" ")

		SqlQuery.Append("WHERE").Append(" ")
		SqlQuery.Append("  1=1").Append(" ")
		SqlQuery.Append("  AND (").Append(M_Timetable_ClassEnum.設定区分.Column).Append(" = '1' AND").Append(" ")
		SqlQuery.Append("       ").Append(M_Timetable_ClassEnum.対象期間.Column).Append(" = @対象期間1)").Append(" ")
		SqlQuery.Append("   OR (").Append(M_Timetable_ClassEnum.設定区分.Column).Append(" = '2' AND").Append(" ")
		SqlQuery.Append("       ").Append(M_Timetable_ClassEnum.対象期間.Column).Append(" = @対象期間2)").Append(" ")
		SqlQuery.Append("   OR (").Append(M_Timetable_ClassEnum.設定区分.Column).Append(" = '3' AND").Append(" ")
		SqlQuery.Append("       ").Append(M_Timetable_ClassEnum.対象期間.Column).Append(" = @対象期間3)").Append(" ")
		SqlQuery.Append("GROUP BY").Append(" ")
		SqlQuery.Append("    MTC.").Append(M_Timetable_ClassEnum.設定区分.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.教室コード.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.対象期間.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.学年.Column).Append(" ")
		SqlQuery.Append("  , MTC.").Append(M_Timetable_ClassEnum.クラスコード.Column).Append(" ")

		Dim parameters As SqlParameter() = {
				New SqlParameter() With {.ParameterName = "@対象期間1", .Value = targetDate.ToString("yyyy")},
				New SqlParameter() With {.ParameterName = "@対象期間2", .Value = targetDate.ToString("yyyyMM")},
				New SqlParameter() With {.ParameterName = "@対象期間3", .Value = targetDate.ToString("yyyyMMdd")}
			}

		Dim resultData As New CsvResultData(Of TimetableSiteCsvData)

		Try
			Using sqlConnection As New SqlConnection(ConnectString)
				sqlConnection.Open()

				Dim csvDataList As New List(Of TimetableSiteCsvData)
				Dim count As Integer = 0
				Using sqlCommand As New SqlCommand(SqlQuery.ToString(), sqlConnection)
					If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
						sqlCommand.Parameters.AddRange(parameters)
					End If
					Using reader As SqlDataReader = sqlCommand.ExecuteReader()
						While reader.Read()
							Dim recData As New TimetableSiteCsvData
							recData.Year = SqlDataReaderUtil.GetValue(reader, 0)
							recData.SiteCode = SqlDataReaderUtil.GetValue(reader, 1)
							recData.SiteName = SqlDataReaderUtil.GetValue(reader, 2)
							recData.PatternName = SqlDataReaderUtil.GetValue(reader, 3)
							recData.StartTime1 = SqlDataReaderUtil.GetValue(reader, 4)
							recData.EndTime1 = SqlDataReaderUtil.GetValue(reader, 5)
							recData.StartTime2 = SqlDataReaderUtil.GetValue(reader, 6)
							recData.EndTime2 = SqlDataReaderUtil.GetValue(reader, 7)
							recData.StartTime3 = SqlDataReaderUtil.GetValue(reader, 8)
							recData.EndTime3 = SqlDataReaderUtil.GetValue(reader, 9)
							recData.StartTime4 = SqlDataReaderUtil.GetValue(reader, 10)
							recData.EndTime4 = SqlDataReaderUtil.GetValue(reader, 11)
							recData.StartTime5 = SqlDataReaderUtil.GetValue(reader, 12)
							recData.EndTime5 = SqlDataReaderUtil.GetValue(reader, 13)
							recData.StartTime6 = SqlDataReaderUtil.GetValue(reader, 14)
							recData.EndTime6 = SqlDataReaderUtil.GetValue(reader, 15)
							recData.StartTime7 = SqlDataReaderUtil.GetValue(reader, 16)
							recData.EndTime7 = SqlDataReaderUtil.GetValue(reader, 17)
							recData.StartTime8 = SqlDataReaderUtil.GetValue(reader, 18)
							recData.EndTime8 = SqlDataReaderUtil.GetValue(reader, 19)
							recData.StartTime9 = SqlDataReaderUtil.GetValue(reader, 20)
							recData.EndTime9 = SqlDataReaderUtil.GetValue(reader, 21)
							csvDataList.Add(recData)
							count += 1
						End While
					End Using
				End Using
				resultData.Success = True
				resultData.CsvDataList = csvDataList
				resultData.DataCount = count
			End Using

		Catch ex As SqlException
			resultData.Success = False
			resultData.ErrorCode = ex.Number
			Throw

		Catch ex As Exception
			resultData.Success = False

		Finally

		End Try

		Return resultData
	End Function
End Class
